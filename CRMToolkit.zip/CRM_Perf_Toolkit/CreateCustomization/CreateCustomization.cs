
namespace CreateCustomization
{
	using System;
	using System.IO;
	using System.Xml;
	using System.Diagnostics;
	using Microsoft.Xrm.Sdk;
	using Microsoft.Xrm.Sdk.Client;
	using Microsoft.Xrm.Sdk.Metadata;
	using ServiceCreator;
	using System.Xml.Linq;
	using System.Collections.Generic;

	/// <summary>
	/// This class creates customization required for macro test cases.
	/// </summary>
	class CreateCustomization
	{
		public static void Main(string[] args)
		{
			try
			{
				System.Diagnostics.Debugger.Launch();
				CreateCustomization createCustomization = new CreateCustomization();
				string directoryName = Directory.GetCurrentDirectory();

				if (args.Length == 0 || args[0] == "/?")
				{
					Console.WriteLine("Arguments missing:");
					Console.WriteLine(" /customization:All/Rollup|Calculated etc");
					Console.WriteLine(" /orgname:[Name of Organization]");
					Console.WriteLine(" /domainname:[Name of Domain only if AD Authentication]");
					Console.WriteLine(" /username:[Name of DomainName or Passport Login]");
					Console.WriteLine(" /password:[Password]");
					Console.WriteLine(" /authentication:[AD or passport]");
					Console.WriteLine(" /discoveryserver:[Name of discovery service server]");
					Console.WriteLine(" /ssl:[true or false]");
					Console.WriteLine(" /organizationServiceUrl");
					Environment.Exit(1);
				}

				createCustomization.ParseCommandLineArguments(args);
				createCustomization.Run();
			}
			catch (Exception e)
			{
				Trace.WriteLine(e.ToString());
			}
		}

		private void Run()
		{
			try
			{
				Trace.WriteLine("Started Customization..");
				string customizationFile;
				if ((int)(action & CustomizationAction.AccountHierarchy) != 0)
				{
					CreateAccountHierarchyCustomization();
				}
				if ((int)(action & CustomizationAction.Rollup) != 0)
				{
					customizationFile = Path.Combine(Directory.GetCurrentDirectory(), @_rollupCustomizationFile);
					Console.WriteLine("Rollup Customization File: " + customizationFile);
					CreateRollupFieldRelatedCustomization(customizationFile);
				}
				if ((int)(action & CustomizationAction.Calculated) != 0)
				{
					customizationFile = Path.Combine(Directory.GetCurrentDirectory(), @_calculatedCustomizationFile);
					Console.WriteLine("Calculated Field Customization File: " + customizationFile);

					CreateCalculatedFieldRelatedCustomization(_calculatedCustomizationFile);

					AddCalculatedFieldCustomizationToSavedQueries();
				}
				Trace.WriteLine("Finished Customization..");
			}
			catch (Exception e)
			{
				Trace.WriteLine(e.ToString());
			}
		}

		/// <summary>
		/// It creates account hierarchy related customization
		/// </summary>
		private void CreateAccountHierarchyCustomization()
		{
			#region Custom Attribute

			CreateEntityOrAttribute.CreateStringAttribute("account", "new_hierarchynodelevel", new Label("Hierarchy Node Level", _languageCode), StringFormat.Text,
				noneRequiredLevelManagedProperty, 255, 0, null, _crmService,
				new Label("Custom attribute to identify account hierarchy for macro performance tests", _languageCode));

			#endregion
		}

		/// <summary>
		/// It creates rollup field related customizations.
		/// </summary>
		/// <param name="rollupCustomizationFile">Path of the file contais rollup field related formula XaML</param>
		private void CreateRollupFieldRelatedCustomization(string rollupCustomizationFile)
		{
			#region Custom Entity

			string customAccount = "new_customaccount";
			string customOpportunity = "new_customopportunity";
			string customActivity = "new_customactivity";
			string estimatedRevenue = "new_estimatedrevenue";
			string opportunityCount = "new_opportunitycount";
			string avgDealSize = "new_avgdealsize";
			string noOfActivities = "new_noofactivities";
			string newName = "new_name";
			string actualRevenue = "new_actualrevenue";
			string customAccountId = "new_customaccountid";
			StringAttributeMetadata primaryAttributeMetadata = null;

			primaryAttributeMetadata = new StringAttributeMetadata
			{
				SchemaName = newName,
				MaxLength = 100,
				RequiredLevel = noneRequiredLevelManagedProperty,
				FormatName = StringFormatName.Text,
				DisplayName = new Label("Name", _languageCode),
				Description = new Label("Custom Opportunity Name.", _languageCode)
			};
			CreateEntityOrAttribute.CreateCustomEntity(customOpportunity, new Label("Custom Opportunity", _languageCode), new Label("Custom Opportunities", _languageCode), new Label("", _languageCode), OwnershipTypes.UserOwned, _crmService, primaryAttributeMetadata);

			primaryAttributeMetadata = new StringAttributeMetadata
			{
				SchemaName = newName,
				MaxLength = 100,
				RequiredLevel = noneRequiredLevelManagedProperty,
				FormatName = StringFormatName.Text,
				DisplayName = new Label("Name", _languageCode),
				Description = new Label("Custom Activity Name.", _languageCode)
			};
			CreateEntityOrAttribute.CreateCustomActivity(customActivity, new Label("Custom Activity", _languageCode), new Label("Custom Activities", _languageCode), new Label("", _languageCode), OwnershipTypes.UserOwned, _crmService, primaryAttributeMetadata);

			primaryAttributeMetadata = new StringAttributeMetadata
			{
				SchemaName = newName,
				MaxLength = 100,
				RequiredLevel = noneRequiredLevelManagedProperty,
				FormatName = StringFormatName.Text,
				DisplayName = new Label("Name", _languageCode),
				Description = new Label("Custom Account Name.", _languageCode)
			};
			CreateEntityOrAttribute.CreateCustomEntity(customAccount, new Label("Custom Account", _languageCode), new Label("Custom Accounts", _languageCode), new Label("", _languageCode), OwnershipTypes.UserOwned, _crmService, primaryAttributeMetadata);

			

			#endregion
			#region Custom Attributes

			CreateEntityOrAttribute.CreateLookupAttribute(customOpportunity, "new_customerid", customAccount, "new_new_customaccount_new_customopportunities", customAccountId, new Label("Customer", _languageCode), applicationRequiredLevelManagedProperty, _crmService, false, new Label("Unique identifier for Custom Account associated with Custom Opportunity.", _languageCode));

			CreateEntityOrAttribute.CreateLookupAttribute(customAccount, "new_parentid", customAccount, "new_customaccount_child_customaccounts", customAccountId, new Label("Parent", _languageCode), applicationRequiredLevelManagedProperty, _crmService, true, new Label("Unique identifier for Custom Account associated with Custom Account.", _languageCode));

			CreateEntityOrAttribute.CreateLookupAttribute(customActivity, "new_regardingid", customAccount, "new_new_customaccount_new_customactivities", customAccountId, new Label("ActivityRegarding", _languageCode), applicationRequiredLevelManagedProperty, _crmService, false, new Label("Unique identifier for Custom Account associated with Custom Activity.", _languageCode));

			//CreateEntityOrAttribute.CreateLookupAttribute(customActivity, "new_indirectid", "activityparty", "new_customactivity_activity_parties", "activitypartyid", new Label("ActivityRegarding", _languageCode), applicationRequiredLevelManagedProperty, _crmService, false, new Label("Unique identifier for Custom Account associated with Custom Activity.", _languageCode));

			CreateEntityOrAttribute.CreateMoneyAttribute(customOpportunity, actualRevenue, new Label("Actual Revenue", _languageCode), noneRequiredLevelManagedProperty, null, 2, 0, _crmService);

			CreateEntityOrAttribute.CreateMoneyAttribute(customOpportunity, estimatedRevenue, new Label("Estimated Revenue", _languageCode), noneRequiredLevelManagedProperty, null, 2, 0, _crmService);

			CreateEntityOrAttribute.CreateMoneyAttribute(customAccount, actualRevenue, new Label("Actual Revenue", _languageCode), noneRequiredLevelManagedProperty, GetFormulaDefinition(rollupCustomizationFile, customAccount, actualRevenue), 2, 2, _crmService);

			CreateEntityOrAttribute.CreateMoneyAttribute(customAccount, estimatedRevenue, new Label("Estimated Revenue", _languageCode), noneRequiredLevelManagedProperty, GetFormulaDefinition(rollupCustomizationFile, customAccount, estimatedRevenue), 2, 2, _crmService);

			CreateEntityOrAttribute.CreateMoneyAttribute(customAccount, avgDealSize, new Label("Avg Deal Size", _languageCode), noneRequiredLevelManagedProperty, GetFormulaDefinition(rollupCustomizationFile, customAccount, avgDealSize), 2, 2, _crmService);

			CreateEntityOrAttribute.CreateIntAttribute(customAccount, "new_level", new Label("Level", _languageCode), noneRequiredLevelManagedProperty, null, 0, _crmService);

			CreateEntityOrAttribute.CreateIntAttribute(customAccount, opportunityCount, new Label("Opportunity Count", _languageCode), noneRequiredLevelManagedProperty, GetFormulaDefinition(rollupCustomizationFile, customAccount, opportunityCount), 2, _crmService);

			CreateEntityOrAttribute.CreateIntAttribute(customAccount, noOfActivities, new Label("No of Activities", _languageCode), noneRequiredLevelManagedProperty, GetFormulaDefinition(rollupCustomizationFile, customAccount, noOfActivities), 2, _crmService);

			#endregion
		}

		/// <summary>
		/// This method creates calculated field related customization.
		/// </summary>
		/// <param name="customizationFile">Path of the file contais calculated field related formula XaML</param>
		private void CreateCalculatedFieldRelatedCustomization(string customizationFile)
		{
			string invoice = "invoice";
			string opportunity = "opportunity";
			string lead = "lead";
			string weightedRevenue = "perf_weightedrevenue";
			string primaryContactNumber = "perf_primarycontactnumber";
			string estimatedSalesTax = "perf_estimatedsalestax";
			string perfScore = "perf_score";
			string perfDueDate = "perf_duedate";
			string dueDate = "Due Date";
			//Create Custom Fields
			#region Fields_On_Invoice
			CreateEntityOrAttribute.CreateDateTimeAttribute(invoice, perfDueDate, new Label(dueDate, _languageCode),
					DateTimeFormat.DateOnly, noneRequiredLevelManagedProperty,
					GetFormulaDefinition(customizationFile, invoice, perfDueDate), 1, _crmService);

			#endregion
			#region Fields_On_Lead
			OptionSetMetadata options = new OptionSetMetadata()
			{
				IsGlobal = false,
				OptionSetType = OptionSetType.Picklist,
				Options =
					{
						new OptionMetadata(new Label("Low", _languageCode), 908210000),
						new OptionMetadata(new Label("Medium", _languageCode), 908210001),
						new OptionMetadata(new Label("Hot", _languageCode), 908210002),
					},
			};
			CreateEntityOrAttribute.CreateOptionSetAttribute(lead, perfScore, noneRequiredLevelManagedProperty,
				new Label(dueDate, _languageCode), GetFormulaDefinition(customizationFile, lead, perfScore), 1, options, _crmService);

			#endregion
			#region Fields_On_Opportunity

			CreateEntityOrAttribute.CreateStringAttribute(opportunity, "new_cazd", new Label("cazd", _languageCode), StringFormat.Text,
				noneRequiredLevelManagedProperty, 200, 0, null, _crmService);

			CreateEntityOrAttribute.CreateMoneyAttribute(opportunity, estimatedSalesTax, new Label("Estimated Sales Tax", _languageCode), noneRequiredLevelManagedProperty, GetFormulaDefinition(customizationFile, opportunity, estimatedSalesTax), 2, 1, _crmService);

			CreateEntityOrAttribute.CreateMoneyAttribute(opportunity, weightedRevenue, new Label("Weighted Revenue", _languageCode), noneRequiredLevelManagedProperty, GetFormulaDefinition(customizationFile, opportunity, weightedRevenue), 2, 1, _crmService);

			CreateEntityOrAttribute.CreateStringAttribute(opportunity, primaryContactNumber, new Label("Primary Contact Number", _languageCode), StringFormat.Text, noneRequiredLevelManagedProperty, 4000, 1, GetFormulaDefinition(customizationFile, opportunity, primaryContactNumber), _crmService);

			#endregion
		}


		/// <summary>
		/// Add newly created customizations to SavedQueries
		/// </summary>
		private void AddCalculatedFieldCustomizationToSavedQueries()
		{
			var entitiesToUpdate = new List<string> {"invoice", "lead", "opportunity"};

			var invoiceAttributes = new List<string> {"perf_duedate"};
			var leadAttributes = new List<string> { "perf_score" };
			var opportunityAttributes = new List<string> {"new_cazd",  "perf_estimatedsalestax" , "perf_weightedrevenue", "perf_primarycontactnumber"};

			foreach (var entityToUpdate in entitiesToUpdate)
			{
				var savedQueries = _savedQueryHelper.RetrieveQueryList(entityToUpdate);

				foreach (var saveQueryEntity in savedQueries.Entities)
				{
					XElement layoutxml = XElement.Parse(saveQueryEntity.Attributes["layoutxml"].ToString());
					XElement fetchXml = XElement.Parse(saveQueryEntity.Attributes["fetchxml"].ToString());

					switch (entityToUpdate)
					{
						case "invoice":
							foreach (var invoiceAttribute in invoiceAttributes)
							{
								layoutxml = _savedQueryHelper.UpdateLayoutXmlAttribute(layoutxml, invoiceAttribute, "300");
								fetchXml = _savedQueryHelper.UpdateFetchXmlAttribute(fetchXml, invoiceAttribute);
							}
							break;
						case "lead":
							foreach (var leadAttribute in leadAttributes)
							{
								layoutxml = _savedQueryHelper.UpdateLayoutXmlAttribute(layoutxml, leadAttribute, "300");
								fetchXml = _savedQueryHelper.UpdateFetchXmlAttribute(fetchXml, leadAttribute);
							}
							break;
						case "opportunity":
							foreach (var opportunityAttribute in opportunityAttributes)
							{
								layoutxml = _savedQueryHelper.UpdateLayoutXmlAttribute(layoutxml, opportunityAttribute, "300");
								fetchXml = _savedQueryHelper.UpdateFetchXmlAttribute(fetchXml, opportunityAttribute);
							}
							break;
					}

					saveQueryEntity.Attributes["layoutxml"] = layoutxml.ToString();
					saveQueryEntity.Attributes["fetchxml"] = fetchXml.ToString();
					_crmService.Update(saveQueryEntity);
				}
			}
			
		}

		/// <summary>
		/// This method returns the formula definition from the xml file based on entity name and attribute name.
		/// </summary>
		/// <param name="customizationFile"></param>
		/// <param name="entityName"></param>
		/// <param name="attributeName"></param>
		/// <returns></returns>
		private string GetFormulaDefinition(string customizationFile, string entityName, string attributeName)
		{
			XmlDocument doc = new XmlDocument();
			doc.Load(customizationFile);
			XmlNode root = doc.DocumentElement;
			string formulaDefinition = root.SelectSingleNode("//attribute[EntityLogicalName=\"" + entityName + "\" and AttributeLogicalName=\"" + attributeName + "\"]/FormulaDefinition").InnerXml;
			return formulaDefinition;
		}

		private void ParseCommandLineArguments(string[] args)
		{
			bool foundUserName = false;
			bool foundPassword = false;
			bool foundOrganizationServiceUrl = false;
			bool foundCommand = false;
			for (int i = 0; i < args.Length; i++)
			{
				if (args[i].Contains("/username:"))
				{
					_userName = args[i].Substring(args[i].IndexOf(':') + 1);
					foundUserName = true;
				}
				else if (args[i].Contains("/password:"))
				{
					_password = args[i].Substring(args[i].IndexOf(':') + 1);
					foundPassword = true;
				}
				else if (args[i].ToLower().Contains("/organizationserviceurl:"))
				{
					_organizationServiceUrl = args[i].Substring(args[i].IndexOf(':') + 1);
					foundOrganizationServiceUrl = true;
				}
				else if (args[i].Contains("/authentication:"))
				{
					if (Enum.IsDefined(typeof(AuthenticationProviderType), args[i].Substring(args[i].IndexOf(':') + 1)))
					{
						_authentication = (AuthenticationProviderType)Enum.Parse(typeof(AuthenticationProviderType), args[i].Substring(args[i].IndexOf(':') + 1), true);
					}
				}
				else if (args[i].Contains("/ssl:"))
				{
					_ssl = bool.Parse(args[i].Substring(args[i].IndexOf(':') + 1));
				}
				else if (args[i].Contains("/customization:"))
				{
					if (args[i].ToLowerInvariant().Contains("rollup"))
					{
						foundCommand = true;
						action |= CustomizationAction.Rollup;
					}
					if (args[i].ToLowerInvariant().Contains("calculated"))
					{
						foundCommand = true;
						action |= CustomizationAction.Calculated;
					}
					if (args[i].ToLowerInvariant().Contains("accounthierarchy"))
					{
						foundCommand = true;
						action |= CustomizationAction.AccountHierarchy;
					}
					if (args[i].ToLowerInvariant().Contains("all"))
					{
						foundCommand = true;
						action |= CustomizationAction.Rollup | CustomizationAction.Calculated | CustomizationAction.AccountHierarchy;
					}
					//Add any other action if required.
				}
			}
			
			if (!(foundOrganizationServiceUrl && foundUserName && foundPassword && foundCommand))
			{
				Console.WriteLine("Arguments missing:");
				Console.WriteLine("1. /customization:All/Rollup|Calculated etc");
				Console.WriteLine("5. /username: [Name of User]");
				Console.WriteLine("6. /password: [Password]");
				Console.WriteLine("8. /organizationserviceurl");
				Environment.Exit(1);
			}
			
			_crmService = XrmServiceCreator.CreateOrganizationService(_organizationServiceUrl, _userName, _password);
			_savedQueryHelper = new SavedQueryHelper(_crmService);
		}


		public CreateCustomization()
		{
			_calculatedCustomizationFile = "ImportCustomization\\CalculatedFieldRelatedFormulaDefinitions.xml";
			_rollupCustomizationFile = "ImportCustomization\\RollupRelatedFormulaDefinitions.xml";
		}

		~CreateCustomization()
		{
		}

		private SavedQueryHelper _savedQueryHelper;
		private IOrganizationService _crmService;
		private string _calculatedCustomizationFile;
		private string _rollupCustomizationFile;
		private string _userName;
		private string _password;
		private string _organizationServiceUrl;
		private AuthenticationProviderType _authentication = AuthenticationProviderType.ActiveDirectory;
		private bool _ssl = false;
		AttributeRequiredLevelManagedProperty applicationRequiredLevelManagedProperty = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.ApplicationRequired);
		AttributeRequiredLevelManagedProperty noneRequiredLevelManagedProperty = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None);
		private int _languageCode = 1033;//Microsoft.Crm.QA.Utils.LocalizationUtils.LanguageCode();
		/// <summary>
		/// Add other flags to add another customizations.
		/// </summary>
		[Flags]
		private enum CustomizationAction
		{
			None = 0,
			Rollup = 1,
			Calculated = 2,
			AccountHierarchy = 4
			//Add more customization action if required.
		}

		private CustomizationAction action = CustomizationAction.None;
	}
}