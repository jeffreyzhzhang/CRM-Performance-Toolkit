﻿
namespace CreateCustomization
{
	using System;
	using System.Xml.Linq;
	using Microsoft.Xrm.Sdk;
	using Microsoft.Xrm.Sdk.Messages;
	using Microsoft.Xrm.Sdk.Query;

	/// <summary>
	/// Helper class to retrieve and update SavedQueries
	/// </summary>
	public class SavedQueryHelper
	{
		private IOrganizationService _crmService;

		public SavedQueryHelper(IOrganizationService crmService)
		{
			_crmService = crmService;
		}

		/// <summary>
		/// Retrieve Saved queries for specific entities
		/// Select sq.name, sq.* from savedquery sq
		/// join MetadataSchema.Entity e on sq.ReturnedTypeCode = e.ObjectTypeCode
		/// where e.name = 'opportunity' and sq.QueryType = 0
		/// </summary>
		/// <param name="entityName"></param>
		/// <returns>SavedQueries for entity</returns>
		public EntityCollection RetrieveQueryList(string entityName)
		{
			EntityCollection savedQueries = null;

			var savedQuery = new QueryExpression { EntityName = "savedquery", ColumnSet = { AllColumns = false } };
			savedQuery.ColumnSet.AddColumn("name");
			savedQuery.ColumnSet.AddColumn("savedqueryid");
			savedQuery.ColumnSet.AddColumn("layoutxml");
			savedQuery.ColumnSet.AddColumn("fetchxml");

			// There are some queries with FatchXml = NULL so Ignore them
			var checkFetchXmlNotNull = new ConditionExpression { AttributeName = "fetchxml", Operator = ConditionOperator.NotNull };
			var checkReturnedTypeCode = new ConditionExpression { AttributeName = "returnedtypecode", Operator = ConditionOperator.Equal };
			var checkQueryType = new ConditionExpression { AttributeName = "querytype", Operator = ConditionOperator.Equal };

			var entityRequest = new RetrieveEntityRequest { LogicalName = entityName.ToLower() };
			var entityResponse = (RetrieveEntityResponse)_crmService.Execute(entityRequest);

			checkReturnedTypeCode.Values.Add(entityResponse.EntityMetadata.ObjectTypeCode.Value);
			checkQueryType.Values.Add(0);

			var filter = new FilterExpression { FilterOperator = LogicalOperator.And };

			filter.Conditions.Add(checkFetchXmlNotNull);
			filter.Conditions.Add(checkReturnedTypeCode);
			filter.Conditions.Add(checkQueryType);

			var order = new OrderExpression { AttributeName = "name", OrderType = OrderType.Ascending };

			savedQuery.Criteria = filter;
			savedQuery.Orders.Add(order);

			try
			{
				savedQueries = _crmService.RetrieveMultiple(savedQuery);
			}
			catch (Exception ex)
			{
				string err = string.Format("{0}\r\n", ex.ToString());
				err = err + string.Format("Fault Exception Detail: {0}\r\n", ex.Message);
				Console.WriteLine(err);
			}
			return savedQueries;
		}

		/// <summary>
		/// Update LayoutXml XElement with new attributes
		/// </summary>
		/// <param name="layoutXml"></param>
		/// <param name="attributeName"></param>
		/// <returns>updated layoutXml</returns>
		public  XElement UpdateLayoutXmlAttribute(XElement layoutXml, string attributeName, string attributeValue)
		{
			bool hasField = false;

			foreach (XElement existingElement in layoutXml.Descendants("cell"))
			{
				if (existingElement.Attribute("name").Value == attributeName)
				{
					hasField = true;
					break;
				}
			}

			if (!hasField)
			{
				var newElement = new XElement("cell");
				newElement.SetAttributeValue("name", attributeName);
				newElement.SetAttributeValue("width", attributeValue);

				foreach (var xElement in layoutXml.Descendants("row"))
				{
					xElement.Add((newElement));
				}
			}
			return layoutXml;
		}

		/// <summary>
		/// Update fetchXml XElement with new attributes
		/// </summary>
		/// <param name="fetchXml"></param>
		/// <param name="attributeName"></param>
		/// <returns>updated fetchXml</returns>
		public XElement UpdateFetchXmlAttribute(XElement fetchXml, string attributeName)
		{
			bool hasField = false;

			foreach (XElement existingElement in fetchXml.Descendants("attribute"))
			{
				if (existingElement.Attribute("name").Value == attributeName)
				{
					hasField = true;
					break;
				}
			}

			if (!hasField)
			{
				var newElement = new XElement("attribute");
				newElement.SetAttributeValue("name", attributeName);

				foreach (var xElement in fetchXml.Descendants("entity"))
				{
					xElement.Add((newElement));
				}
			}
			return fetchXml;
		}
	}
}
