﻿namespace CreateCustomization
{
	using System;
	using System.Diagnostics;
	using Microsoft.Xrm.Sdk;
	using Microsoft.Xrm.Sdk.Messages;
	using Microsoft.Xrm.Sdk.Metadata;

	public class CreateEntityOrAttribute
	{
		/// <summary>
		/// Creates DateTime Attribute
		/// </summary>
		internal static void CreateDateTimeAttribute(string entityName, string attributeName, Label displayLabel, DateTimeFormat dateTimeFormat, AttributeRequiredLevelManagedProperty attributeRequiredLevel, string formulaDefinition, int sourceType, IOrganizationService crmService, Label description = null)
		{
			try
			{
				CreateAttributeRequest createPerfDueDateDateRequest = new CreateAttributeRequest
				{
					EntityName = entityName,
					Attribute = new DateTimeAttributeMetadata
					{
						SchemaName = attributeName,
						RequiredLevel = attributeRequiredLevel,
						Format = dateTimeFormat,
						DisplayName = displayLabel,
						Description = description,
						FormulaDefinition = formulaDefinition,
						SourceType = sourceType
					}
				};
				crmService.Execute(createPerfDueDateDateRequest);
				Trace.WriteLine(attributeName + " attribute is created on " + entityName + "  entity");
			}
			catch (Exception e)
			{
				ReportError(e);
			}
		}

		/// <summary>
		/// Creates option set attribute.
		/// </summary>
		internal static void CreateOptionSetAttribute(string entityName, string attributeName, AttributeRequiredLevelManagedProperty attributeRequiredLevel, Label displayLabel, string formulaDefinition, int sourceType, OptionSetMetadata options, IOrganizationService crmService, Label description = null)
		{
			try
			{
				CreateAttributeRequest createPerfScoreOnLeadRequest = new CreateAttributeRequest
				{
					EntityName = entityName,
					Attribute = new PicklistAttributeMetadata
					{
						SchemaName = attributeName,
						RequiredLevel = attributeRequiredLevel,
						OptionSet = options,
						DisplayName = displayLabel,
						Description = description,
						FormulaDefinition = formulaDefinition,
						SourceType = sourceType
					}
				};
				crmService.Execute(createPerfScoreOnLeadRequest);
				Trace.WriteLine(attributeName + " attribute is created on " + entityName + " entity");
			}
			catch (Exception e)
			{
				ReportError(e);
			}
		}

		/// <summary>
		/// Creates string attribute.
		/// </summary>
		internal static void CreateStringAttribute(string entityName, string attributeName, Label displayLabel, StringFormat stringFormat, AttributeRequiredLevelManagedProperty attributeRequiredLevel, int maxLength, int sourceType, string formulaDefinition, IOrganizationService crmService, Label description = null)
		{
			try
			{
				CreateAttributeRequest createCazdRequest = new CreateAttributeRequest
					{
						EntityName = entityName,
						Attribute = new StringAttributeMetadata()
						{
							SchemaName = attributeName,
							RequiredLevel = attributeRequiredLevel,
							Format = stringFormat,
							DisplayName = displayLabel,
							Description = description,
							MaxLength = maxLength,
							SourceType = sourceType
						}
					};
				crmService.Execute(createCazdRequest);
				Trace.WriteLine(attributeName + " attribute is created on " + entityName + " entity");
			}
			catch (Exception e)
			{
				ReportError(e);
			}
		}

		/// <summary>
		/// Creates money attribute.
		/// </summary>
		internal static void CreateMoneyAttribute(string entityName, string attributeName, Label displayLabel, AttributeRequiredLevelManagedProperty attributeRequiredLevel, string formulaDefinition, int precision, int sourceType, IOrganizationService crmService, Label description = null)
		{
			try
			{
				CreateAttributeRequest createAttributeRequest = new CreateAttributeRequest
				{
					EntityName = entityName,
					Attribute = new MoneyAttributeMetadata()
					{
						SchemaName = attributeName,
						RequiredLevel = attributeRequiredLevel,
						Description = description,
						Precision = precision,
						DisplayName = displayLabel,
						FormulaDefinition = formulaDefinition,
						SourceType = sourceType
					}
				};
				crmService.Execute(createAttributeRequest);
				Trace.WriteLine(attributeName + " attribute is created on " + entityName + " entity");
			}
			catch (Exception e)
			{
				ReportError(e);
			}
		}

		/// <summary>
		/// Creates custom entity.
		/// </summary>
		internal static void CreateCustomActivity(string entityName, Label displayLabel, Label collectionName, Label description, OwnershipTypes ownershipTypes, IOrganizationService crmService, StringAttributeMetadata primaryAttributeMetadata)
		{
			try
			{
				CreateEntityRequest createrequest = new CreateEntityRequest
				{
					HasNotes = true,
					HasActivities = false,

					//Define the entity
					Entity = new EntityMetadata
					{
						SchemaName = entityName,
						DisplayName = displayLabel,
						DisplayCollectionName = collectionName,
						Description = description,
						OwnershipType = ownershipTypes,
						IsActivity = true,
						IsAvailableOffline = true
					},

					PrimaryAttribute = new StringAttributeMetadata
					{
						SchemaName = "Subject",
						RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
						MaxLength = 100,
						DisplayName = new Label("Subject", 1033)
					}
				};
				crmService.Execute(createrequest);
				Trace.WriteLine("The " + entityName + " entity is created.");
			}
			catch (Exception e)
			{
				ReportError(e);
			}
		}

		/// <summary>
		/// Creates custom entity.
		/// </summary>
		internal static void CreateCustomEntity(string entityName, Label displayLabel, Label collectionName, Label description, OwnershipTypes ownershipTypes, IOrganizationService crmService, StringAttributeMetadata primaryAttributeMetadata)
		{
			try
			{
				CreateEntityRequest createrequest = new CreateEntityRequest
				{
					//Define the entity
					Entity = new EntityMetadata
					{
						SchemaName = entityName,
						DisplayName = displayLabel,
						DisplayCollectionName = collectionName,
						Description = description,
						OwnershipType = ownershipTypes
					},
					// Define the primary attribute for the entity
					PrimaryAttribute = primaryAttributeMetadata
				};
				crmService.Execute(createrequest);
				Trace.WriteLine("The " + entityName + " entity is created.");
			}
			catch (Exception e)
			{
				ReportError(e);
			}
		}


	




		/// <summary>
		/// Creates integer attribute.
		/// </summary>
		internal static void CreateIntAttribute(string entityName, string attributeName, Label displayLabel, AttributeRequiredLevelManagedProperty attributeRequiredLevel, string formulaDefinition, int sourceType, IOrganizationService crmService, Label description = null)
		{
			try
			{
				CreateAttributeRequest createAttributeRequest = new CreateAttributeRequest
				{
					EntityName = entityName,
					Attribute = new IntegerAttributeMetadata()
					{
						SchemaName = attributeName,
						RequiredLevel = attributeRequiredLevel,
						DisplayName = displayLabel,
						Description = description,
						FormulaDefinition = formulaDefinition,
						SourceType = sourceType
					}
				};
				crmService.Execute(createAttributeRequest);
				Trace.WriteLine(attributeName + " attribute is created on " + entityName + " entity");
			}
			catch (Exception e)
			{
				ReportError(e);
			}
		}

		/// <summary>
		/// Creates lookup attribute field.
		/// </summary>
		internal static void CreateLookupAttribute(string entityName, string attributeName, string relatedEntityLogicalName, string relationshipName, string referencedAttribute, Label dispalyName, AttributeRequiredLevelManagedProperty attributeRequiredLevel, 
			IOrganizationService crmService,  bool isHierarchical = false, Label description = null)
		{
			try
			{
				CreateOneToManyRequest attributeCreateRequest = new CreateOneToManyRequest()
				{
					Lookup = new LookupAttributeMetadata()
					{
						Description = description,
						DisplayName = dispalyName,
						SchemaName = attributeName,
						RequiredLevel = attributeRequiredLevel
					},
					OneToManyRelationship = new OneToManyRelationshipMetadata()
					{
						AssociatedMenuConfiguration = new AssociatedMenuConfiguration()
						{
							Behavior = AssociatedMenuBehavior.UseCollectionName,
							Group = AssociatedMenuGroup.Details,
							Order = 10000
						},
						CascadeConfiguration = new CascadeConfiguration()
						{
							Assign = CascadeType.Cascade,
							Delete = CascadeType.Cascade,
							Merge = CascadeType.Cascade,
							Reparent = CascadeType.Cascade,
							Share = CascadeType.Cascade,
							Unshare = CascadeType.Cascade
						},
						ReferencedEntity = relatedEntityLogicalName,
						ReferencedAttribute = referencedAttribute,
						ReferencingEntity = entityName,
						IsHierarchical = isHierarchical,
						SchemaName = relationshipName
					}
				};
				crmService.Execute(attributeCreateRequest);
				Trace.WriteLine(attributeName + " attribute is created on " + entityName + " entity");
			}
			catch (Exception e)
			{
				ReportError(e);
			}
		}

		private static void ReportError(Exception e)
		{
			Trace.WriteLine("Customization Error:" + e.ToString());
		}
	}
}
