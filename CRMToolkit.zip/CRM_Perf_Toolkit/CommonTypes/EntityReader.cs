﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using System.Diagnostics;
using ServiceCreator;
using System.Collections;
using System.Runtime.Serialization;

namespace CommonTypes
{
	public enum EntityType
	{
		Normal = 0,
		Special = 1
	}

	public static class EntityReader
	{
		private static readonly string ORGANIZATION_ID_NAME = "organizationid";
		private static readonly string EntityManagerID = "ID";
		private static readonly int BitShift = 25;
		[ThreadStaticAttribute]
		private static int _retryCount = 0;
		private static Dictionary<string, EntityMetadata> mapEntityMetadata = null;
		private static Guid organizationId = Guid.Empty;
		private static object _lock = new object();

		public static uint ReadEntityFromTable(IOrganizationService proxy, string emdbSqlConnStr, string entityName, string[] props, FilterExpression where, string strORDERBY, int? topRows, Guid orgId, Dictionary<Guid, Hashtable> owners, string inEntityName = "", EntityType entityType = EntityType.Normal)
		{
			if (mapEntityMetadata == null || !organizationId.Equals(orgId))
			{
				lock (_lock)
				{
					if (mapEntityMetadata == null || !organizationId.Equals(orgId))
					{
						mapEntityMetadata = LoadEntityMatadata(proxy).ToDictionary(s => s.LogicalName, s => s);
						organizationId = orgId;
					}
				}
			}

			//If the Entity has a hierarchy field, then add a property to retrieve the data into.
			if (CheckHierarchyFieldExistance(entityName, proxy))
			{
				Array.Resize(ref props, props.Length + 1);
				props[props.Length - 1] = "new_HierarchyNodeLevel";
			}

			string insertentityName = entityName;
			if (inEntityName != "")
			{
				insertentityName = inEntityName;
			}

			//Build the INSERT statement with the requested props
			string InsertCommand = BuildInsertCommand(insertentityName, props, entityType);

			// Counter of entities read.
			uint totalRecordsProcessed = 0;
			using (SqlConnection emdbSqlConn = new SqlConnection(emdbSqlConnStr))
			{
				emdbSqlConn.Open();
				using (SqlTransaction Tran = emdbSqlConn.BeginTransaction())
				{
					string ORDERBY = null;
					if (null != strORDERBY)
						ORDERBY = strORDERBY.ToLower();

					SqlCommand EMCmd = new SqlCommand();
					EMCmd.Connection = emdbSqlConn;
					EMCmd.Transaction = Tran;
					EMCmd.CommandTimeout = 0;
					QueryExpression query;

					bool expectedException = false;
					do
					{
						if (expectedException)
						{
							System.Threading.Thread.Sleep((int)Math.Pow(10,_retryCount) * 100);
						}

						expectedException = false;
						try
						{
							//SDK call to get data from org db
							EntityCollection results = null;
							bool getmorerows = true;
							query = BuildQueryExpression(entityType, entityName, props, where, ORDERBY);

							while (getmorerows)
							{
								results = proxy.RetrieveMultiple(query);
								query.PageInfo.PageNumber++;
								query.PageInfo.PagingCookie = results.PagingCookie;
								getmorerows = results.MoreRecords;

								for (int k = 0; k < results.Entities.Count; k++)
								{
									Entity en = results[k];
									EMCmd.Parameters.Clear();
									string Values = "VALUES (";

									//First need to determine the owner's number.
									Hashtable Owner = null;
									Guid OwnerId = Guid.Empty;

									if (entityType == EntityType.Normal)
									{
										if (null == props[0])
										{
											//to support multi server scenario, we are going to have a fake org
											//it the first property is null => we are reading orgs
											Guid fakeguid = new Guid("19007b7e-d9a3-da11-b5fc-001143d30bf2");
											Owner = owners[fakeguid];
											OwnerId = fakeguid;
										}
										else
										{
											//if the owner is an Organization, then we do not get the ownerid
											//we get the new owner id if the owner is a user
											if (en.Attributes[props[0].ToLower()] is EntityReference)
											{
												EntityReference er = (EntityReference)en.Attributes[props[0].ToLower()];
												if (string.Compare(props[0], ORGANIZATION_ID_NAME, true) == 0)
												{
													OwnerId = (Guid)er.Id;
												}
												else
												{
													OwnerId = (Guid)GetOwnerGuid(er.Id, orgId);
												}
											}
											else
											{
												if (string.Compare(props[0], ORGANIZATION_ID_NAME, true) == 0)
												{
													OwnerId = (Guid)en.Attributes[props[0].ToLower()];
												}
												else
												{
													OwnerId = GetOwnerGuid((Guid)en.Attributes[props[0].ToLower()], orgId);
												}
											}

											if (!owners.ContainsKey(OwnerId))
											{
												Trace.TraceError(string.Format("Owner '{0}' for one of the '{1}' entities was not found.", OwnerId, entityName));
												totalRecordsProcessed++;

												Trace.WriteLineIf(0 == (totalRecordsProcessed % 1000), "Read " + totalRecordsProcessed + " " + entityName + " (More to Come)");

												if (topRows.HasValue && totalRecordsProcessed >= topRows)
												{
													getmorerows = false;
													break;
												}
												continue;
											}
											Owner = owners[OwnerId];
										}
									}
									else
									{
										Owner = owners[orgId];
									}

									System.Int64 NextID = GetNextId(Owner, entityName);

									Values += "@" + EntityManagerID + ",";
									EMCmd.Parameters.AddWithValue(EntityManagerID, NextID);
									if (entityType == EntityType.Normal)
									{
										Values += "@" + "EntityManagerOwningUser ,";
										EMCmd.Parameters.AddWithValue("EntityManagerOwningUser", OwnerId);
									}

									foreach (string Prop in props)
									{
										if (Prop != null)
										{
											Values += "@" + Prop + ",";

											if (Prop == "OrganizationId" && entityType == EntityType.Special)
											{
												EMCmd.Parameters.AddWithValue("OrganizationId", orgId);
											}
											else if (Prop == "EntityManagerOwningUser" && entityType == EntityType.Special)
											{
												EMCmd.Parameters.AddWithValue("EntityManagerOwningUser", orgId);
											}
											else if (Prop == "RegardingObjectTypeCode" && entityName == "Phonecall")
											{
												if (!en.Attributes.ContainsKey("regardingobjectid"))
												{
													EMCmd.Parameters.AddWithValue(Prop, DBNull.Value);
												}
												else
												{
													EntityReference er = (EntityReference)en.Attributes["regardingobjectid"];
													int objectcodetype = mapEntityMetadata[er.LogicalName].ObjectTypeCode.Value;
													EMCmd.Parameters.AddWithValue(Prop, objectcodetype);
												}
											}
											else if (!en.Attributes.ContainsKey(Prop.ToLower()))
											{
											if (Prop.Equals("customeridname", StringComparison.InvariantCultureIgnoreCase))
											{
												EntityReference er = (EntityReference)en.Attributes["customerid"];
												EMCmd.Parameters.AddWithValue(Prop, er.Name);
											}
											else if (Prop.Equals("customeridtype", StringComparison.InvariantCultureIgnoreCase))
											{
												EntityReference er = (EntityReference)en.Attributes["customerid"];
												int objectcodetype = mapEntityMetadata[er.LogicalName].ObjectTypeCode.Value;
												EMCmd.Parameters.AddWithValue(Prop, objectcodetype);
											}
											else if (Prop.Equals("organizationidname", StringComparison.InvariantCultureIgnoreCase))
											{
												EntityReference er = (EntityReference)en.Attributes["organizationid"];
												EMCmd.Parameters.AddWithValue(Prop, er.Name);
											}
											else if (Prop.Equals("businessunitidname", StringComparison.InvariantCultureIgnoreCase))
											{
												EntityReference er = (EntityReference)en.Attributes["businessunitid"];
												EMCmd.Parameters.AddWithValue(Prop, er.Name);
											}
											else
											{
												//this loop get added because ReportNameOnSRS field contain null data
												EMCmd.Parameters.AddWithValue(Prop, DBNull.Value);
											}
											}
											else if (Prop.ToLower().Equals("objecttypecode") || Prop.ToLower().Equals("primaryentitytypecode") || Prop.ToLower().Equals("primaryentity"))
											{
												string strLogicalName = en.Attributes[Prop.ToLower()].ToString();
												int objectcodetype = mapEntityMetadata[strLogicalName].ObjectTypeCode.Value;
												EMCmd.Parameters.AddWithValue(Prop, objectcodetype);
											}
											else if (en.Attributes[Prop.ToLower()].GetType().ToString().Equals("System.Boolean", StringComparison.InvariantCultureIgnoreCase))
											{
												bool b = bool.Parse(en.Attributes[Prop.ToLower()].ToString());
												if (true == b)
													EMCmd.Parameters.AddWithValue(Prop, 1);
												else
													EMCmd.Parameters.AddWithValue(Prop, 0);
											}
											else if (en.Attributes[Prop.ToLower()] is EntityReference)
											{
												EntityReference er = (EntityReference)en.Attributes[Prop.ToLower()];
												EMCmd.Parameters.AddWithValue(Prop, er.Id);
											}
											else if (en.Attributes[Prop.ToLower()] is OptionSetValue)
											{
												OptionSetValue op = (OptionSetValue)en.Attributes[Prop.ToLower()];
												EMCmd.Parameters.AddWithValue(Prop, op.Value);
											}
											else
											{
												EMCmd.Parameters.AddWithValue(Prop, en.Attributes[Prop.ToLower()].ToString());
											}
										}
									}
									Values = Values.Remove(Values.Length - 1);
									Values += ")";

									//Insert the row.
									EMCmd.CommandText = InsertCommand + Values;
									if (1 != EMCmd.ExecuteNonQuery())
									{
										Trace.Write("Didn't effect 1 row");
									}

									totalRecordsProcessed++;

									Trace.WriteLineIf(0 == (totalRecordsProcessed % 1000), "Read " + totalRecordsProcessed + " " + entityName + " (More to Come)");

									if (topRows.HasValue && totalRecordsProcessed >= topRows)
									{
										getmorerows = false;
										break;
									}
								}
							}
							Tran.Commit();
						}
						catch (TimeoutException e0)
						{
							Trace.WriteLine("Exception:\n" + e0.ToString());
							Trace.WriteLine("SQL " + EMCmd.CommandText);

							_retryCount++;
							expectedException = true;
						}
						catch (SqlException e1)
						{
							Trace.WriteLine("Exception:\n" + e1.ToString());
							Trace.WriteLine("SQL " + EMCmd.CommandText);

							_retryCount++;
							expectedException = true;
						}
						catch (System.Exception e)
						{
							Trace.WriteLine("Exception:\n" + e.ToString());
							Trace.WriteLine("SQL " + EMCmd.CommandText);

							if (!string.IsNullOrEmpty(e.Message) && e.Message.Contains("SQL timeout expired"))
							{
								_retryCount++;
								expectedException = true;
							}
							else
							{
								Trace.WriteLine("Exception:\n" + e.ToString());
								Trace.WriteLine("SQL " + EMCmd.CommandText);
								throw;
							}
						}
					}
					while (expectedException && _retryCount < 3);
				}
			}
			return totalRecordsProcessed;
		}

		/// <summary>
		/// Used for gererating insert sta
		/// </summary>
		/// <param name="strInsertCommand"></param>
		/// <param name="props"></param>
		/// <returns></returns>
		private static string BuildInsertCommand(string entityName, string[] props, EntityType entityType)
		{
			string strInsertCommand = string.Format("INSERT INTO {0} ({1}, ", entityName, EntityManagerID);
			if (entityType.Equals(EntityType.Normal))
			{
				strInsertCommand += " EntityManagerOwningUser ,";
			}

			foreach (string Prop in props)
			{
				if (Prop != null)
				{
					strInsertCommand += Prop + ",";
				}
			}

			//Remove the last ",
			strInsertCommand = strInsertCommand.Remove(strInsertCommand.Length - 1);
			strInsertCommand += ") ";
			return strInsertCommand;
		}


		/// <summary>
		/// Build Query Expression based on Entity Name
		/// </summary>
		/// <param name="enEntityType">EntityType (Normal, Special)</param>
		/// <param name="entityName">Entiry Name</param>
		/// <param name="props">Array of column name user want to retrive</param>
		/// <param name="where">Filter Condition</param>
		/// <param name="OrderBy">Order by column</param>
		/// <returns>Return QueryExpression based on above parameter</returns>
		public static QueryExpression BuildQueryExpression(EntityType enEntityType, string entityName, string[] props, FilterExpression where, string OrderBy)
		{
			QueryExpression query = new QueryExpression(entityName.ToLower());
			query.PageInfo.Count = 5000;
			query.PageInfo.PageNumber = 1;
			if (props == null)
			{
				query.ColumnSet.AllColumns = true;
			}
			else
			{
				for (int i = 0; i < props.Length; i++)
				{
					if (props[i] != null && ((enEntityType == EntityType.Normal && props[i].ToLower() != "customeridname" && props[i].ToLower() != "organizationidname" && props[i].ToLower() != "businessunitidname") || (enEntityType == EntityType.Special && props[i] != "OrganizationId" && props[i] != "EntityManagerOwningUser")))
					{
						query.ColumnSet.AddColumn(props[i].ToLower());
					}
				}
				if (entityName == "Phonecall")
				{
					query.ColumnSet.AddColumn("regardingobjectid");
				}
			}

			if (OrderBy != null)
			{
				query.AddOrder(OrderBy, OrderType.Ascending);
			}
			if (where != null)
			{
				query.Criteria = where;
			}
			return query;
		}


		private static EntityMetadata[] LoadEntityMatadata(IOrganizationService proxy)
		{
			RetrieveAllEntitiesRequest request = new RetrieveAllEntitiesRequest();
			RetrieveAllEntitiesResponse response = (RetrieveAllEntitiesResponse)proxy.Execute(request);
			var entityMetadata = response.Results["EntityMetadata"];
			return entityMetadata as EntityMetadata[];
		}

		public static Guid GetOwnerGuid(Guid user, Guid Org)
		{
			Byte[] b1 = user.ToByteArray();
			Byte[] b2 = Org.ToByteArray();
			Byte[] b3 = new byte[16];

			for (int i = 0; i < 16; i++)
				b3[i] = (byte)((int)b1[i] + (int)b2[i]);

			Guid g = new Guid(b3);
			return g;
		}

		private static Int64 GetNextId(Hashtable htOwner, string strentityName)
		{
			if (false == htOwner.ContainsKey(strentityName))
			{
				htOwner.Add(strentityName, (System.Int64)0);
			}

			System.Int64 BaseVal = System.Int64.Parse(htOwner[EntityManagerID].ToString());
			BaseVal = BaseVal << BitShift;

			System.Int64 NextID = (System.Int64)htOwner[strentityName];
			NextID++;

			if (System.Int64.MaxValue == NextID)
			{
				throw new Exception("Attempt to use reserved const of Int64.MaxValue");
			}

			htOwner[strentityName] = NextID;
			NextID += BaseVal;

			return NextID;
		}

		private static bool CheckHierarchyFieldExistance(string entityName, IOrganizationService proxy)
		{
			bool existHierarchy = false;
			QueryExpression query = new QueryExpression();
			EntityCollection results = null;

			query.EntityName = entityName.ToLower();
			query.ColumnSet.AddColumn("new_hierarchynodelevel");
			try
			{
				results = proxy.RetrieveMultiple(query);
				existHierarchy = true;
			}
			catch (Exception e)
			{
				if (e.Message.Contains("new_HierarchyNodeLevel"))
				{
					Trace.WriteLine("Column new_HierarchyNodeLevel does not exist in " + entityName);
				}
			}

			return existHierarchy;
		}


	}
}
