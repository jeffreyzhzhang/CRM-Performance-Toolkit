﻿namespace CRM_Perf_BenchMark.OrionWebTests.MobileClientTests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;

	public abstract class MobileClientOpenEntityWebTestBase : MobileClientEntityWebTestBase
	{
		public MobileClientOpenEntityWebTestBase(string entityName, string entityId)
			: base(entityName, entityId)
		{
		}

		public override string Operation
		{
			get { return "Open"; }
		}
	}
}
