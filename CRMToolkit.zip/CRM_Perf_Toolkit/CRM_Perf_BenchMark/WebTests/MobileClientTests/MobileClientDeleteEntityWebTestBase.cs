﻿namespace CRM_Perf_BenchMark.OrionWebTests.MobileClientTests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using Microsoft.VisualStudio.TestTools.WebTesting;

	public abstract class MobileClientDeleteEntityWebTestBase : MobileClientEntityWebTestBase
	{
		public MobileClientDeleteEntityWebTestBase(string entityName, string entityId)
			: base(entityName, entityId)
		{
			this.PostWebTest += new EventHandler<PostWebTestEventArgs>(this.MobileClientDeleteEntityWebTestBase_PostWebTest);
		}

		public override string Operation
		{
			get { return "Delete"; }
		}

		/// <summary>
		/// Delete opportunity
		/// </summary>
		/// <returns>Return list of web testRequest.</returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumeratorInternal()
		{
			yield return this.PrepareRequest(new _grid_cmds_dlg_delete_aspx(user)
			{
				client_type = "MobileClient",
				iObjType = this.EntityEtc,
				iTotal = 1,
				sSubTypes = this.EntityEtc.ToString(),
				user_lcid = 1033,
				dType = 2
			});

			yield return this.PrepareRequest(new _grid_cmds_dlg_delete_aspx(user)
			{
				iId = this.EntityId,
				iObjType = this.EntityEtc,
				iTotal = 1,
				iIndex = 0
			});
		}

		private void MobileClientDeleteEntityWebTestBase_PostWebTest(object sender, PostWebTestEventArgs e)
		{
			if (this.EntityRecord != null)
			{
				EntityManager.Instance.DeleteEntity(this.EntityRecord);
			}
		}
	}
}
