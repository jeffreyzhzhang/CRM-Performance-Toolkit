﻿namespace CRM_Perf_BenchMark.OrionWebTests.MobileClientTests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using CRM_Perf_BenchMark.CrmRequests;
	using Microsoft.VisualStudio.TestTools.WebTesting;

	public abstract class MobileClientDeleteNoteOnEntityWebTestBase : MobileClientEntityWebTestBase
	{
		public MobileClientDeleteNoteOnEntityWebTestBase(string entityName, string entityId)
			: base(entityName, entityId)
		{
		}

		public override string Operation
		{
			get { return "DeleteNoteOn"; }
		}

		/// <summary>
		/// Delete Note On Entity
		/// </summary>
		/// <returns>Return list of WebTestRequests</returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumeratorInternal()
		{
			// Create the note first
			var newNoteWebTest = new MobileClientCreateNoteOnEntityWebTestBase(this.EntityName, this.EntityId) 
			{ 
				SearchString = this.SearchString, 
				ParentWebTest = this 
			};

			var createNoteRequests = newNoteWebTest.GetRequestEnumeratorInternal();
			while (createNoteRequests.MoveNext())
			{
				yield return createNoteRequests.Current;
			}

			if (String.IsNullOrEmpty(newNoteWebTest.NoteId))
			{
				throw new Exception("Note Id is not defined.");
			}

			// Delete the note
			string basePath = "\\CrmRequests\\MobileClientRequests\\MoCA_DeleteNoteOnEntity\\";
			var deleteNoteRequest = new OrganizationServiceDeleteRequest(user, basePath + "MoCA_DeleteNoteOnEntity", new Dictionary<string, string>
			{
				{"NOTE_ID", newNoteWebTest.NoteId},
			});

			yield return this.PrepareRequest(deleteNoteRequest);
		}
	}
}
