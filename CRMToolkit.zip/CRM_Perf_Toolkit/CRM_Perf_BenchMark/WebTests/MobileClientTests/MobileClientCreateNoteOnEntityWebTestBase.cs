﻿namespace CRM_Perf_BenchMark.OrionWebTests.MobileClientTests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using CRM_Perf_BenchMark.CrmRequests;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Xml.Linq;

	public class MobileClientCreateNoteOnEntityWebTestBase : MobileClientEntityWebTestBase
	{
		public MobileClientCreateNoteOnEntityWebTestBase(string entityName, string entityId)
			: base(entityName, entityId)
		{
		}

		public override string Operation
		{
			get { return "CreateNoteOn"; }
		}

		public string NoteId { get; set; }

		/// <summary>
		/// Create Note On Entity
		/// </summary>
		/// <returns>Return list of WebTestRequests</returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumeratorInternal()
		{
			string basePath = "\\CrmRequests\\MobileClientRequests\\MoCA_CreateNewNoteForEntity\\";
			var templateParams = new Dictionary<string, string> 
			{
				{"ENTITY_ID", this.EntityId},
				{"ENTITY_NAME", this.EntityName.ToLowerInvariant()},
				{"ENTITY_ID_NAME", this.EntityIdName.ToLowerInvariant()}
			};

			var resourceNames = OrganizationServiceRequest.GetResourceNames(OrganizationServiceRequest.GetResourceNameFromTemplateName(basePath));
			foreach (var resourceName in resourceNames)
			{
				var request = new OrganizationServiceExecuteRequest(user, resourceName, templateParams);
				yield return PrepareRequest(request);

				if (resourceName.Contains("CreateRequest"))
				{
					XDocument document = XDocument.Parse(request.lastResponse.BodyString);
					this.NoteId = document.Descendants("{http://schemas.datacontract.org/2004/07/System.Collections.Generic}value").SingleOrDefault().Value;

					// Add the note id to the subsequent requests
					templateParams.Add("NOTE_ID", this.NoteId);
				}
			}
		}
	}
}
