﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM_Perf_Benchmark;

namespace CRM_Perf_BenchMark
{
	public class me_LeadDeleteEntity : WebService_DeleteRecord
	{
		public me_LeadDeleteEntity()
			: base(EntityNames.Leads, 4)
		{
		}
	}
}
