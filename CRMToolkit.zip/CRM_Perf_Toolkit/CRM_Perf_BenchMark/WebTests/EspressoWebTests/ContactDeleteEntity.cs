﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM_Perf_Benchmark;

namespace CRM_Perf_BenchMark
{
	public class me_ContactDeleteEntity : WebService_DeleteRecord
	{
		public me_ContactDeleteEntity()
			: base(EntityNames.Contacts, 2)
		{
		}
	}
}
