﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM_Perf_BenchMark;
using CRM_Perf_BenchMark.Espresso;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace CRM_Perf_Benchmark
{
	public class WebService_MarkAsComplete : EspressoWebServiceTestBase
	{
		public WebService_MarkAsComplete()
			: base()
		{

		}

		protected override void EspressoWebServiceTest_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			var entityRequest = new EntityRequest[] 
			{ 
				new EntityRequest()
				{
					Type = EntityNames.Tasks,
					ParentID = Guid.NewGuid(),
					ReturnAs = EntityNames.Tasks,
				}
			};

			Hashtable entities = WebTestBase_PreWebTest(sender, e, entityRequest, EntityNames.Tasks);
			if (entities != null)
			{
				task = entities[EntityNames.Tasks] as CRMEntity;
			}
		}

		protected override void EspressoWebServiceTest_PostWebTest(object sender, PostWebTestEventArgs e)
		{
			EntityManager.Instance.DeleteEntity(task);
			base.EspressoWebServiceTest_PostWebTest(sender, e);
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			string recordId = task[EntityIDNames.Task];
			this.BeginTransaction(EspressoTransactionNames.WebService_MarkAsComplete);
			yield return base.Execute(() => new MobileExpressWebService().MarkActivityAsComplete(recordId, 4212));
			this.EndTransaction(EspressoTransactionNames.WebService_MarkAsComplete);
		}

		protected override void ResponseValidator(object sender, ValidationEventArgs e)
		{
			// HTTP Status code is checked by default validator, no need for any more validation in this call.
		}

		private CRMEntity task;
	}
}
