﻿using System;
using System.Web;

namespace CRM_Perf_BenchMark
{
	public class me_AccountEditEntity : me_EditEntity
	{
		private const string CommandXmlTemplate = @"
			<Input>
				<id>{0}</id>
				<name>account</name>
				<formId>20ec3318-e87e-4623-afe5-cac39cd090de</formId>
				<dataxml>
					<account>
					<name>{1}</name>
					</account>
				</dataxml>
				<associations/>
			</Input>";

		public me_AccountEditEntity()
			: base(EntityNames.Accounts)
		{
		}

		public override string GetCommandXml(Guid editEntity)
		{
			var data = string.Format(CommandXmlTemplate, editEntity.ToString("B"), Utils.GetRandomString(5, 10));
			data = HttpUtility.HtmlEncode(data);
			return data;
		}
	}
}
