﻿using System;
using System.Web;

namespace CRM_Perf_BenchMark
{
	public class me_AccountCreateEntity : me_CreateEntity
	{
		private const string CommandXmlTemplate = @"
			<Input>
				<id>{0}</id>
				<name>account</name>
				<formId>8448b78f-8f42-454e-8e2a-f8196b0419af</formId>
				<dataxml>{1}</dataxml>
				<associations/>
			</Input>";

		public me_AccountCreateEntity()
			: base(EntityNames.Accounts)
		{
		}

		public override string GetCommandXml()
		{
			var currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
			string data = EntityXmlHelper.GetCreateAccountXml(new Guid(user[EntityIDNames.User]), 8, Utils.GetRandomString(5, 30), currency);
			data = HttpUtility.HtmlEncode(data);
			return string.Format(CommandXmlTemplate, Guid.Empty, data);
		}

	}
}
