﻿namespace CRM_Perf_BenchMark
{
	public class me_ContactReadForm : me_ReadForm
	{
		public me_ContactReadForm()
			: base(EntityNames.Contacts)
		{

		}
	}
}
