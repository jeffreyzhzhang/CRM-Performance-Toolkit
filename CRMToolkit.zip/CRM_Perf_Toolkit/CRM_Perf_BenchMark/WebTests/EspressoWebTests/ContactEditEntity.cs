﻿using System;
using System.Web;

namespace CRM_Perf_BenchMark
{
	public class me_ContactEditEntity : me_EditEntity
	{
		private const string CommandXmlTemplate =
			@"<Input>
				<id>{0}</id>
				<name>contact</name>
				<formId>cc3bc004-1fd7-41e0-80d9-a2af399a42fa</formId>
				<dataxml>
					<contact>
						<jobtitle>{1}</jobtitle>
					</contact>
				</dataxml>
				<associations/>
			</Input>";

		public me_ContactEditEntity()
			: base(EntityNames.Contacts)
		{
		}

		public override string GetCommandXml(Guid editEntity)
		{
			var data = string.Format(CommandXmlTemplate, editEntity.ToString("B"), Utils.GetRandomString(5, 10));
			data = HttpUtility.HtmlEncode(data);
			return data;
		}
	}
}
