﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM_Perf_Benchmark;

namespace CRM_Perf_BenchMark
{
	public class me_AccountDeleteEntity : WebService_DeleteRecord
	{
		public me_AccountDeleteEntity() 
			: base(EntityNames.Accounts, 1)
		{
		}
	}
}
