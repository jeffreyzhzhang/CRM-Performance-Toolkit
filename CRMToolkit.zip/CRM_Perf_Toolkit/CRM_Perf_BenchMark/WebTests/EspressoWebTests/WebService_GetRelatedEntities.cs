﻿using System.Collections.Generic;
using CRM_Perf_BenchMark;
using CRM_Perf_BenchMark.Espresso;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace CRM_Perf_Benchmark
{
	public class WebService_GetRelatedEntities : EspressoWebServiceTestBase
	{
		public WebService_GetRelatedEntities()
			: base()
		{
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			int objectTypeCode = 1;
			this.BeginTransaction(EspressoTransactionNames.WebService_GetRelatedEntities);
			yield return base.Execute(() => new MobileExpressWebService().GetRelatedEntities(objectTypeCode));
			this.EndTransaction(EspressoTransactionNames.WebService_GetRelatedEntities);
		}

		protected override void ResponseValidator(object sender, ValidationEventArgs e)
		{
			// HTTP Status code is checked by default validator, no need for any more validation in this call.
		}
	}
}
