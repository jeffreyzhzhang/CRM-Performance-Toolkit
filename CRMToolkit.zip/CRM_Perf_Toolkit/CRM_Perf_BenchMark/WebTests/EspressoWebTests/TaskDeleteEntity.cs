﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM_Perf_Benchmark;

namespace CRM_Perf_BenchMark
{
	public class me_TaskDeleteEntity : WebService_DeleteRecord
	{
		public me_TaskDeleteEntity()
			: base(EntityNames.Tasks, 4212)
		{
		}
	}
}
