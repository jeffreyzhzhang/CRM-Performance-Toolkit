﻿namespace CRM_Perf_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using Espresso;

	/// <summary>
	/// 1. Hits the Espresso home page  (/m/default.aspx)
	/// </summary>
	public class me_Homepage : EspressoPageTestBase
	{
		public me_Homepage()
			: base()
		{
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction(EspressoTransactionNames.HomePage);

			_m_default_aspx hp = new _m_default_aspx(user);
			yield return (hp);

			this.EndTransaction(EspressoTransactionNames.HomePage);
		}
	}
}
