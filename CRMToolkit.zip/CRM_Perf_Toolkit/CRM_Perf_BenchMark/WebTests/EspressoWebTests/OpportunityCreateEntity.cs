﻿using System;
using System.Web;

namespace CRM_Perf_BenchMark
{
	public class me_OpportunityCreateEntity : me_CreateEntity
	{
		private const string CommandXmlTemplate = @"
			<Input>
				<id>{0}</id>
				<name>opportunity</name>
				<formId>a837e4a7-01b8-4f82-a475-be9abd67e667</formId>
				<dataxml>{1}</dataxml>
				<associations/>
			</Input>";

		public me_OpportunityCreateEntity()
			: base(EntityNames.Opportunities)
		{
		}

		public override string GetCommandXml()
		{
			var currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
			string data = EntityXmlHelper.GetCreateOpportunityXml(new Guid(user[EntityIDNames.User]), 8, Utils.GetRandomString(5, 30), new Guid(user[EntityIDNames.User]), 1, currency);
			data = HttpUtility.HtmlEncode(data);
			return string.Format(CommandXmlTemplate, Guid.Empty, data);

		}
	}
}
