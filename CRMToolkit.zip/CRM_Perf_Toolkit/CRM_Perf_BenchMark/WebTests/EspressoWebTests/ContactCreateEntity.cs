﻿using System;
using System.Web;

namespace CRM_Perf_BenchMark
{
	public class me_ContactCreateEntity : me_CreateEntity
	{
		private const string CommandXmlTemplate = @"
			<Input>
				<id>{0}</id>
				<name>contact</name>
				<formId>1fed44d1-ae68-4a41-bd2b-f13acac4acfa</formId>
				<dataxml>{1}</dataxml>
				<associations/>
			</Input>";

		public me_ContactCreateEntity()
			: base(EntityNames.Contacts)
		{
		}

		public override string GetCommandXml()
		{
			var currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
			string data = EntityXmlHelper.GetCreateLeadXml(new Guid(user[EntityIDNames.User]), 8, Utils.GetRandomString(5, 30), Utils.GetRandomString(5, 30), currency);
			data = HttpUtility.HtmlEncode(data);
			return string.Format(CommandXmlTemplate, Guid.Empty, data);

		}
	}
}
