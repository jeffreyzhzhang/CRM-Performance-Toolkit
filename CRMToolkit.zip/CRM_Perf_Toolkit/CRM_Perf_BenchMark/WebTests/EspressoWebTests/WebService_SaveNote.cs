﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM_Perf_BenchMark;
using CRM_Perf_BenchMark.Espresso;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace CRM_Perf_Benchmark
{
	public class WebService_SaveNote : EspressoWebServiceTestBase
	{
		public WebService_SaveNote()
			: base()
		{
		}

		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			var account = RetrieveTestEntity(user, EntityNames.Accounts);
			string parentEntityId = account[EntityIDNames.Account];
			string parentEntityOtc = "1";
			string noteSubject = "Note Subject";
			string noteText = "Note Text";
			string noteId = string.Empty;
			this.BeginTransaction(EspressoTransactionNames.WebService_SaveNote);
			yield return base.Execute(() => new MobileExpressWebService().SaveNote(noteSubject, noteText, parentEntityId, parentEntityOtc, noteId));
			this.EndTransaction(EspressoTransactionNames.WebService_SaveNote);
		}

		protected override void ResponseValidator(object sender, ValidationEventArgs e)
		{
			// HTTP Status code is checked by default validator, no need for any more validation in this call.
		}
	}
}
