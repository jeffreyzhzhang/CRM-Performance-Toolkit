namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;

	/// <summary>
	/// 1.  Start at Workplace homepage
	/// 2.	Select Activities
	/// 3.	Select a Campaign Response view
	/// 4.	Click right button at bottom till last page
	/// </summary>

	public class RefreshGridCampaignResponse : RefreshGridTmplate
	{
		#region Pre WebTest
		/// <summary>
		/// Pre WebTest
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">PreWebTestEventArgs</param>
		public void RefreshGridCampaignResponse_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			WebTestBase_PreWebTest(sender, e);
		}
		#endregion

		#region Class constructor
		/// <summary>
		/// Class constructor
		/// Initialization of the test assets
		/// </summary>
		public RefreshGridCampaignResponse()
		{
			Random numGen = new Random();
			randomNum = numGen.Next(2);
			PreWebTest += new EventHandler<PreWebTestEventArgs>(RefreshGridCampaignResponse_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(WebTestBase_PostWebTest);
		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Simuate web requests 
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			return base.GetRequestEnumerator();
		}
		#endregion


		protected override string entityName
		{
			get
			{
				return EntityNames.Campaigns;
			}
		}

		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.MarketingSiteMapPath[EntityNames.Campaigns];
			}
		}

		protected override string viewName
		{
			get { return viewNames[randomNum]; }
		}

		protected override string viewId
		{
			get { return viewIds[randomNum]; }
		}

		protected override string resetGridXml
		{
			get
			{
				string xml = WebTestHelp.ResetGridXmls[EntityViewNames.MyCampaignsResponses];
				xml = WebTestHelp.gridXmlhelp(xml, -1, viewId, null); //set the expected view Id
				return xml;
			}

		}

		private string[] viewNames = new string[] { EntityViewNames.AllCampaignResponses,EntityViewNames.MyCampaignsResponses,EntityViewNames.OpenCampaignResponses};
		private string[] viewIds = new string[] { "1100BB7A-76D2-4F59-AD7D-F03D9DF8A99F", "7A683A37-D63C-453D-9507-3B7628B29E27", "3A663F7B-409A-4585-9516-4AA8645663CF" };
		private int randomNum;
	}
}