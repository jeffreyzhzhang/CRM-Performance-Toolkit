namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;

	/// <summary>
	/// All Tests are written from a warm perspective(meaning that each page has been visited recently so that it is not an initial (cold) load)
	/// 1. Start at Marketing Tab
	/// 2. Select Marketing Lists 
	/// 3. Select new button
	/// 4. Enter data in form (name, member type list)
	/// 5. Save & close
	/// </summary>

	public class CreateNewList : CreateNewEntityTemplate
	{
		#region Constructor
		/// <summary>
		/// default constructor
		/// </summary>
		/// 
		public CreateNewList()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(CreateNewList_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(CreateNewList_PostWebTest);
		}
		#endregion

		#region Pre WebTest
		public void CreateNewList_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			WebTestBase_PreWebTest(sender, e);
			//get test entities, we need to specify currency info for the new list
			currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
		}
		#endregion

		#region Post WebTest
		/// <summary>
		/// Need to add the newly created entity to EMDB to make EMDB in sync with production DB
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">PostWebTestEvent</param>
		public void CreateNewList_PostWebTest(object sender, PostWebTestEventArgs e)
		{
			try
			{
				if (newEntityId != null)
				{
					Guid g = EntityManager.GetOwnerGuid(new Guid(user[EntityIDNames.User]), new Guid(user["OrganizationId"]));
					EntityManager.Instance.AddEntity(EntityNames.Lists, g, new string[] { "OwnerId", "ListID", "EntityManagerOwningUser" }, new string[] { user["systemuserid"], newEntityId, g.ToString() });
				}
			}
			finally
			{
				WebTestBase_PostWebTest(sender, e);
			}
		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			//create an list
			return base.GetRequestEnumerator();
		}
		#endregion

		protected override string entityName
		{
			get
			{
				return EntityNames.Lists;
			}
		}

		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.MarketingSiteMapPath[EntityNames.Lists];
			}
		}
		protected override string formId
		{
			get
			{
				return "6e77626b-e693-44f0-a1c7-359b1a7a9a4c";
			}
		}
		//command xml needed for entity creation operation
		protected override string commandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, entityName.ToLower(), formId);
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateListXml(new Guid(user["systemuserid"]), 8, currency);
				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}

		protected override int commandCode
		{
			get { return 1; }
		}

		//A certain number of refreshes will happen after creating the entity
		protected override string[] gridXmls
		{
			get
			{
				return new string[3]
				{
					WebTestHelp.RefreshGridXmls[EntityViewNames.LeadAssociated],
					WebTestHelp.RefreshGridXmls[EntityViewNames.MyQuickCampaigns],
					WebTestHelp.RefreshGridXmls[EntityViewNames.ListCampaigns] 
				};

			}
		}

		private CRMEntity currency;
	}
}