namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;

	/// <summary>
	/// 1.	Start at Marketing homepage
	/// 2.  Select Marketing Lists
	/// 3.	Click on �New�
	/// 4.	Input information and click �Save and Close�
	/// 5.	Open the created List
	/// 6.	Click on �Marketing List Members�
	/// 7.	Click �Manage Members�
	/// 8.	Select �Use Lookup to add members�
	/// 9.	Click Find
	/// 10.	Select a list (double click) and click OK
	/// 11.	Click on �Manage Members� again
	/// 12.	Click on �Use Advanced Find to Remove Members�
	/// 13.	Click on Find button
	/// 14.	Select an Account and click �Remove from List�
	/// 15.	Click Save and Close
	/// </summary>

	public class RemoveMembersFromList : AddMembersToList
	{

		#region Class constructor
		/// <summary>
		/// Default class constructor
		/// </summary>
		public RemoveMembersFromList()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(RemoveMembersFromList_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(WebTestBase_PostWebTest);
		}
		#endregion

		#region Pre WebTest
		/// <summary>
		/// Pre WebTest
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void RemoveMembersFromList_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			//get test entities owned by the test user
			account = RetrieveTestEntity(user, EntityNames.Accounts);
			currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			
			IEnumerator<WebTestRequest> requests = base.GetRequestEnumerator();
			while (requests.MoveNext())
			{

				yield return requests.Current;

			}

			this.BeginTransaction("RemoveMemberFromList");
			_grid_cmds_dlg_delete_aspx delDlg = new _grid_cmds_dlg_delete_aspx(user)
			{
				dType = 1,
				iObjType = 1,
				iTotal = 1,
			};
			yield return delDlg;

			//refresh accout list view
			string gridXml = "&lt;grid&gt;&lt;sortColumns&gt;fullname&amp;#58;1&lt;/sortColumns&gt;&lt;pageNum&gt;1&lt;/pageNum&gt;&lt;recsPerPage&gt;14&lt;/recsPerPage&gt;&lt;dataProvider&gt;Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder&lt;/dataProvider&gt;&lt;uiProvider&gt;Microsoft.Crm.Application.Controls.GridUIProvider&lt;/uiProvider&gt;&lt;cols/&gt;&lt;max&gt;1&lt;/max&gt;&lt;refreshAsync&gt;True&lt;/refreshAsync&gt;&lt;pagingCookie/&gt;&lt;enableMultiSort&gt;true&lt;/enableMultiSort&gt;&lt;enablePagingWhenOnePage&gt;true&lt;/enablePagingWhenOnePage&gt;&lt;refreshCalledFromRefreshButton&gt;1&lt;/refreshCalledFromRefreshButton&gt;&lt;totalrecordcount&gt;1&lt;/totalrecordcount&gt;&lt;allrecordscounted&gt;true&lt;/allrecordscounted&gt;&lt;returntotalrecordcount&gt;true&lt;/returntotalrecordcount&gt;&lt;getParameters&gt;&lt;/getParameters&gt;&lt;parameters&gt;&lt;viewid&gt;&amp;#123;58FB20FF-D5BE-406F-908E-C777E9DEDF5F&amp;#125;&lt;/viewid&gt;&lt;RenderAsync&gt;0&lt;/RenderAsync&gt;&lt;LoadOnDemand&gt;0&lt;/LoadOnDemand&gt;&lt;deleteAction&gt;contact&amp;#124;NoRelationship&amp;#124;SubGridStandard&amp;#124;Mscrm.DeleteSelectedRecord&lt;/deleteAction&gt;&lt;autorefresh&gt;1&lt;/autorefresh&gt;&lt;LayoutStyle&gt;LiteGridList&lt;/LayoutStyle&gt;&lt;maxselectableitems&gt;1&lt;/maxselectableitems&gt;&lt;isGridFilteringEnabled&gt;1&lt;/isGridFilteringEnabled&gt;&lt;viewtype&gt;1039&lt;/viewtype&gt;&lt;viewts&gt;295556&lt;/viewts&gt;&lt;RecordsPerPage&gt;14&lt;/RecordsPerPage&gt;&lt;viewTitle&gt;Contact List Members View&lt;/viewTitle&gt;&lt;layoutXml&gt;&amp;#60;grid name&amp;#61;&amp;#34;contacts&amp;#34; object&amp;#61;&amp;#34;2&amp;#34; jump&amp;#61;&amp;#34;lastname&amp;#34; select&amp;#61;&amp;#34;1&amp;#34; icon&amp;#61;&amp;#34;1&amp;#34; preview&amp;#61;&amp;#34;1&amp;#34;&amp;#62;&amp;#60;row name&amp;#61;&amp;#34;contact&amp;#34; id&amp;#61;&amp;#34;contactid&amp;#34;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;fullname&amp;#34; width&amp;#61;&amp;#34;300&amp;#34; &amp;#47;&amp;#62;&amp;#60;cell name&amp;#61;&amp;#34;telephone1&amp;#34; width&amp;#61;&amp;#34;125&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;row&amp;#62;&amp;#60;&amp;#47;grid&amp;#62;&lt;/layoutXml&gt;&lt;otc&gt;2&lt;/otc&gt;&lt;otn&gt;contact&lt;/otn&gt;&lt;entitydisplayname&gt;Contact&lt;/entitydisplayname&gt;&lt;titleformat&gt;&amp;#123;0&amp;#125; &amp;#123;1&amp;#125;&lt;/titleformat&gt;&lt;entitypluraldisplayname&gt;Contacts&lt;/entitypluraldisplayname&gt;&lt;expandable&gt;1&lt;/expandable&gt;&lt;showjumpbar&gt;0&lt;/showjumpbar&gt;&lt;maxrowsbeforescroll&gt;1&lt;/maxrowsbeforescroll&gt;&lt;tabindex&gt;1130&lt;/tabindex&gt;&lt;refreshasynchronous&gt;1&lt;/refreshasynchronous&gt;&lt;subgridAutoExpand&gt;0&lt;/subgridAutoExpand&gt;&lt;relName&gt;&lt;/relName&gt;&lt;roleOrd&gt;1&lt;/roleOrd&gt;&lt;relationshipType&gt;0&lt;/relationshipType&gt;&lt;ribbonContext&gt;SubGridStandard&lt;/ribbonContext&gt;&lt;GridType&gt;SubGrid&lt;/GridType&gt;&lt;teamTemplateId&gt;&lt;/teamTemplateId&gt;&lt;isWorkflowSupported&gt;true&lt;/isWorkflowSupported&gt;&lt;enableFilters&gt;&lt;/enableFilters&gt;&lt;InnerGridDisabled&gt;0&lt;/InnerGridDisabled&gt;&lt;oId&gt;&amp;#123;B187C9C3-43FD-E211-860C-E83935B7520E&amp;#125;&lt;/oId&gt;&lt;oType&gt;4300&lt;/oType&gt;&lt;effectiveFetchXml&gt;&amp;#60;fetch distinct&amp;#61;&amp;#34;false&amp;#34; no-lock&amp;#61;&amp;#34;true&amp;#34; mapping&amp;#61;&amp;#34;logical&amp;#34; page&amp;#61;&amp;#34;1&amp;#34; count&amp;#61;&amp;#34;14&amp;#34; returntotalrecordcount&amp;#61;&amp;#34;true&amp;#34;&amp;#62;&amp;#60;entity name&amp;#61;&amp;#34;contact&amp;#34;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;contactid&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;fullname&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;telephone1&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;fullname&amp;#34; &amp;#47;&amp;#62;&amp;#60;attribute name&amp;#61;&amp;#34;telephone1&amp;#34; &amp;#47;&amp;#62;&amp;#60;order attribute&amp;#61;&amp;#34;fullname&amp;#34; descending&amp;#61;&amp;#34;false&amp;#34; &amp;#47;&amp;#62;&amp;#60;link-entity name&amp;#61;&amp;#34;listmember&amp;#34; to&amp;#61;&amp;#34;contactid&amp;#34; from&amp;#61;&amp;#34;entityid&amp;#34; link-type&amp;#61;&amp;#34;inner&amp;#34;&amp;#62;&amp;#60;filter type&amp;#61;&amp;#34;and&amp;#34;&amp;#62;&amp;#60;condition attribute&amp;#61;&amp;#34;listid&amp;#34; operator&amp;#61;&amp;#34;eq&amp;#34; value&amp;#61;&amp;#34;&amp;#123;B187C9C3-43FD-E211-860C-E83935B7520E&amp;#125;&amp;#34; &amp;#47;&amp;#62;&amp;#60;&amp;#47;filter&amp;#62;&amp;#60;&amp;#47;link-entity&amp;#62;&amp;#60;&amp;#47;entity&amp;#62;&amp;#60;&amp;#47;fetch&amp;#62;&lt;/effectiveFetchXml&gt;&lt;isFetchXmlNotFinal&gt;False&lt;/isFetchXmlNotFinal&gt;&lt;fetchXmlForFilters&gt;&lt;/fetchXmlForFilters&gt;&lt;/parameters&gt;&lt;columns&gt;&lt;column width=&quot;300&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Full&amp;#32;Name&quot; fieldname=&quot;fullname&quot; entityname=&quot;contact&quot; renderertype=&quot;Crm.PrimaryField&quot;&gt;fullname&lt;/column&gt;&lt;column width=&quot;125&quot; isHidden=&quot;false&quot; isMetadataBound=&quot;true&quot; isSortable=&quot;true&quot; label=&quot;Business&amp;#32;Phone&quot; fieldname=&quot;telephone1&quot; entityname=&quot;contact&quot;&gt;telephone1&lt;/column&gt;&lt;/columns&gt;&lt;/grid&gt;" ;
			string marker = "oId&gt;&amp;#123;";
			int startIndex = gridXml.IndexOf(marker);
			startIndex += marker.Length;
			gridXml = gridXml.Remove(startIndex, 36);
			gridXml = gridXml.Insert(startIndex, newEntityId);
			gridXml = System.Web.HttpUtility.HtmlDecode(gridXml);
			yield return AppGridWebServiceRefresh(gridXml, referer);

			_grid_cmds_dlg_delete_aspx delDlg2 = new _grid_cmds_dlg_delete_aspx(user)
			{
				iId = newEntityId,
				iIndex = 0,
				iObjType = 1,
				iTotal = 1,
			};
			yield return delDlg2;

			yield return AppGridWebServiceRefresh(gridXml, referer);

			this.EndTransaction("RemoveMemberFromList");

		}
		#endregion

		protected override string entityName
		{
			get
			{
				return EntityNames.Lists;
			}
		}

		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.MarketingSiteMapPath[EntityNames.Lists];
			}
		}


		#region Validate Repsonse
		/// <summary>
		/// Validate response
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">ValidationEvent</param>
		private void NewEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			newEntityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				newEntityId = new Guid(newEntityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}
		#endregion

		private CRMEntity currency, account;
	}
}