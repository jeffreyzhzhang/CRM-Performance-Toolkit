namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;

	/// <summary>
	/// All Tests are written from a warm perspective(meaning that each page has been visited recently so that it is not an initial (cold) load)
	/// 1. Start at marketing tab
	/// 2. Select campaigns 
	/// 3. Select new campaign button
	/// 4. Add relevant data (name)
	/// 5. Click Save and close
	/// </summary>

	public class CreateNewCampaign : CreateNewEntityTemplate
	{
		#region Constructor
		/// <summary>
		/// default constructor
		/// </summary>
		/// 
		public CreateNewCampaign()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(CreateNewCampaign_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(CreateNewCampaign_PostWebTest);
		}
		#endregion

		#region Pre WebTest
		public void CreateNewCampaign_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			WebTestBase_PreWebTest(sender, e);
			//get test entities, we need to specify currency info for the new campaign
			currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
		}
		#endregion

		#region Post WebTest
		/// <summary>
		/// Need to add the newly created entity to EMDB to make EMDB in sync with production DB
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">PostWebTestEvent</param>
		public void CreateNewCampaign_PostWebTest(object sender, PostWebTestEventArgs e)
		{
			try
			{
				if (newEntityId != null)
				{
					Guid g = EntityManager.GetOwnerGuid(new Guid(user[EntityIDNames.User]), new Guid(user["OrganizationId"]));
					EntityManager.Instance.AddEntity(EntityNames.Campaigns,
						g,
						 new string[] { "OwnerId", "CampaignID", "EntityManagerOwningUser" },
						 new string[] { user["systemuserid"], newEntityId.ToString(), g.ToString() });
				}
			}
			finally
			{
				WebTestBase_PostWebTest(sender, e);
			}
		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			//create campaign
			return base.GetRequestEnumerator();
		}
		#endregion

		protected override string entityName
		{
			get
			{
				return EntityNames.Campaigns;
			}
		}

		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.MarketingSiteMapPath[EntityNames.Campaigns];
			}
		}
		protected override string formId
		{
			get
			{
				return "6356ff2a-bbbe-49fb-9da2-160b08865688";
			}
		}
		//command xml needed for entity creation operation
		protected override string commandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, entityName.ToLower(),formId );
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateCampaignXml(new Guid(user[EntityIDNames.User]), 8);
				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}

		protected override int commandCode
		{
			get { return 1; }
		}

		//A certain number of refreshes will happen after creating the entity
		//in the case of creating an campaign, there are 3 refreshes after the campaign is created. Please refer to the Fiddler traces
		protected override string[] gridXmls
		{
			get
			{
				return new string[4]
				{
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignActivities],
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignLeads],
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignResponses] ,
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignMarketingLists]
				};

			}
		}

		private CRMEntity currency;

	}
}