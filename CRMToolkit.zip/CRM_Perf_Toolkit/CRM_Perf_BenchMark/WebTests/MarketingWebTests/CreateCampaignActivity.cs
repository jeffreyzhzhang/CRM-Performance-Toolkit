namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;

	/// <summary>
	/// All Tests are written from a warm perspective(meaning that each page has been visited recently so that it is not an initial (cold) load)
	/// 1.	Start at Marketing homepage
	/// 2.  Open Campaign homepage
	/// 3.	Click on "New"
	/// 4.	Fill data and click "Save"
	/// 5.	Click on "Campaign Activities" 
	/// 6.	Click on "New"
	/// 7.	Fill Channel, subject and description and click "Save and Close"
	/// </summary>

	public class CreateCampaignActivity : WebTestBase
	{
		#region Constructor
		/// <summary>
		/// default constructor
		/// </summary>
		/// 
		public CreateCampaignActivity()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(CreateCampaignActivity_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(CreateCampaignActivity_PostWebTest);
		}
		#endregion

		#region Pre WebTest
		public void CreateCampaignActivity_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			WebTestBase_PreWebTest(sender, e);
			//get test entities, we need to specify currency info for the new campaign
			currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
		}
		#endregion

		#region Post WebTest
		/// <summary>
		/// Need to add the newly created entity to EMDB to make EMDB in sync with production DB
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">PostWebTestEvent</param>
		public void CreateCampaignActivity_PostWebTest(object sender, PostWebTestEventArgs e)
		{
			try
			{
				if (newEntityId != null)
				{
					Guid g = EntityManager.GetOwnerGuid(new Guid(user[EntityIDNames.User]), new Guid(user["OrganizationId"]));
					EntityManager.Instance.AddEntity(EntityNames.Campaigns, g, new string[] { "OwnerId", "CampaignID", "EntityManagerOwningUser" }, new string[] { user["systemuserid"], newEntityId.ToString(), g.ToString() });
				}
			}
			finally
			{
				WebTestBase_PostWebTest(sender, e);
			}
		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			//Navigate to the account homepage from sales home
			this.BeginTransaction(string.Format("{0}HomepageNavigation", entityName));
			yield return HomePageNavigation(entityName, siteMapPath);
			this.EndTransaction(string.Format("{0}HomepageNavigation", entityName));

			this.BeginTransaction(string.Format("Create{0}", entityName));
			main_aspx mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[entityName],
				extraqs = "etc=" + WebTestHelp.EntityEtc[entityName],
				pagetype = "entityrecord",
				pagemode = "iframe",

			};
			yield return mainPage;

			//create new entity
			string referer = mainPage.lastResponse.ResponseUri.ToString();

			InlineEditHelper inlineEdit = new InlineEditHelper(commandXml, user);
			CrmRequest createEntity = inlineEdit.getInlineEditWTR(referer, commandCode) as CrmRequest;
			createEntity.ValidateResponse += this.NewEntity_ValidateResponse;
			yield return createEntity;

			this.BeginTransaction("AppGridRefreshAfterCreation");

			foreach (string gridXml in gridXmls)
			{
				yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(gridXml), referer);
			}
			this.EndTransaction("AppGridRefreshAfterCreation");

			Ribbon.RibbonWebService ribbon = new Ribbon.RibbonWebService();
			CrmRequest wtr = null;
			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtr);

			this.EndTransaction(string.Format("Create{0}", entityName));

			this.BeginTransaction("AddActivityToCampaign");

			mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[AssosiatedEntityName],
				extraqs = "?_CreateFromId=%7b" + newEntityId + "%7d&_CreateFromType=" + WebTestHelp.EntityEtc[entityName] + "&etc=" + WebTestHelp.EntityEtc[AssosiatedEntityName],
				pagetype = "entityrecord",
				pagemode = "iframe",
			};
			yield return mainPage;

			inlineEdit = new InlineEditHelper(AssosiatedEntityCommandXml, user);
			createEntity = inlineEdit.getInlineEditWTR(referer, 1) as CrmRequest;
			yield return createEntity;

			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtr);
			this.EndTransaction("AddActivityToCampaign");
		}
		#endregion


		#region Validate Repsonse
		/// <summary>
		/// Validate response
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">ValidationEvent</param>
		private void NewEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			newEntityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				newEntityId = new Guid(newEntityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}
		#endregion

		protected string[] gridXmls
		{
			get
			{
				return new string[4]
				{
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignActivities],
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignLeads],
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignResponses] ,
					WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignMarketingLists] 
				};

			}
		}
		protected string formId
		{
			get
			{
				return "6356ff2a-bbbe-49fb-9da2-160b08865688";
			}
		}
		protected override string entityName
		{
			get
			{
				return EntityNames.Campaigns;
			}
		}
		protected string AssosiatedEntityName
		{
			get
			{
				return EntityNames.CampaignActivities;
			}
		}
		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.MarketingSiteMapPath[EntityNames.Campaigns];
			}
		}

		//command xml needed for entity creation operation
		protected string commandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, entityName.ToLower(), formId);
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateCampaignXml(new Guid(user[EntityIDNames.User]), 8);

				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}

		protected string AssosiatedEntityCommandXml
		{
			get
			{
				string command = null;
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, AssosiatedEntityName.ToLower(), "30b5a041-afe1-4ced-91c5-86c7554df10c");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				if (newEntityId != null)
				{
					string dataXml = EntityXmlHelper.GetCreateCampaignActivityXml(new Guid(user[EntityIDNames.User]), 8, new Guid(newEntityId), 4400, 5, currency);
					//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
					dataXml = dataXml.Replace("<", "&#60;");
					dataXml = dataXml.Replace(">", "&#62;");
					dataXml = dataXml.Replace("</", "&#60;&#47;");
					dataXml = dataXml.Replace("=", "&#61;");
					dataXml = dataXml.Replace("\"", "&#34;");
					sb.Append(dataXml);
					sb.Append(commandXml_post);
					command = sb.ToString();
				}
				return command;
			}
		}
		protected int commandCode
		{
			get { return 1; }
		}


		private CRMEntity currency;
		protected string newEntityId;
		protected readonly string newIdMarker = "\"Id\":\"{";
	}
}