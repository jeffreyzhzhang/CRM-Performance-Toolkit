namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;

	/// <summary>
	/// 1. Start at Marketing homepage
	/// 2. Select Marketing Lists
	/// 3. Click On New List
	/// 4. Enter Data and Click �Save and Close�
	/// 5. Reopen List (double click)
	/// 6. Click Marketing List Members
	/// 7. Click Manage Members
	/// 8. Select �Use Lookup to add members�
	/// 9. Click on Create Quick Campaign
	/// 10. Fill the name of Quick Campaign
	/// 11. Select type �Fax�
	/// 12. Fill appropriate data
	/// 13. Click �Save and Close�
	/// </summary>

	public class ListQuickCampaign : WebTestBase
	{

		#region Class constructor
		/// <summary>
		/// Default class constructor
		/// </summary>
		public ListQuickCampaign()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(ListQuickCampaign_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(WebTestBase_PostWebTest);
		}
		#endregion

		#region Pre WebTest
		/// <summary>
		/// Pre WebTest
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void ListQuickCampaign_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			//get test user
			WebTestBase_PreWebTest(sender, e);
			CRMEntity test = RetrieveSetupUserEntity();
			setupuserid = test["systemuserid"];
			//get test entities owned by the test user
			currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
			GetSecondUser(new Guid(user["organizationid"]));
			account = RetrieveTestEntity(user, EntityNames.Accounts);
		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction("CreateNewLists");

			this.BeginTransaction(string.Format("{0}HomePageNavigation", entityName));
			CrmRequest homePage = HomePageNavigation(entityName, siteMapPath);
			yield return homePage;
			this.EndTransaction(string.Format("{0}HomePageNavigation", entityName));

			string referer = homePage.lastResponse.ResponseUri.ToString();

			this.BeginTransaction(string.Format("Create{0}", entityName));
			main_aspx mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[entityName],
				extraqs = "etc=" + WebTestHelp.EntityEtc[entityName],
				pagetype = "entityrecord",
				pagemode = "iframe",

			};
			yield return mainPage;

			//create new entity
			referer = mainPage.lastResponse.ResponseUri.ToString();

			string modifiedQueryXml = null;
			if (queryXml.Contains("SYSTEM_USERID"))
			{
				modifiedQueryXml = queryXml.Replace("SYSTEM_USERID", user[EntityIDNames.User]);
			}
			yield return RetrieveMultiple(modifiedQueryXml);

			InlineEditHelper inlineEdit = new InlineEditHelper(commandXml, user);
			CrmRequest createEntity = inlineEdit.getInlineEditWTR(referer, 1) as CrmRequest;
			createEntity.ValidateResponse += this.NewEntity_ValidateResponse;
			yield return createEntity;
			this.EndTransaction(string.Format("Create{0}", entityName));

			string AccountLookup = WebTestHelp.RefreshGridXmls[EntityViewNames.AccountLookup];
			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(AccountLookup), referer);
			foreach (string gridXml in gridXmls)
			{
				yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(gridXml), referer);
			}

			Ribbon.RibbonWebService ribbon = new Ribbon.RibbonWebService();
			CrmRequest wtr = null;
			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(WebTestHelp.RefreshGridXmls[EntityViewNames.MyActiveMarketingList]), referer);

			yield return (wtr);

			this.EndTransaction("CreateNewLists");

			this.BeginTransaction("AddMembersToList");

			MarketingAutomation.MarketingAutomationWebService mws = new MarketingAutomation.MarketingAutomationWebService();
			try
			{
				mws.RetrieveList(new Guid(newEntityId), new string[] { " " });
			}
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}

			_controls_lookup_lookupinfo_aspx lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo.objecttypes = "1";
			lookupInfo.browse = 0;
			lookupInfo.LookupStyle = "multi";
			yield return (lookupInfo);

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(AccountLookup), referer);

			_grid_cmds_dlg_addtolist_aspx addlist = new _grid_cmds_dlg_addtolist_aspx(user);
			addlist.itemObjectId = new Guid(newEntityId);
			addlist.iObjType = 1;
			addlist.iTotal = 1;
			addlist.autoTrigger = 1;
			yield return addlist;

			_grid_cmds_dlg_addtolist_aspx addtoList = new _grid_cmds_dlg_addtolist_aspx(user);
			addtoList.iId = new Guid(account[EntityIDNames.Account]);
			addtoList.iObjType = 1;
			addtoList.iTotal = 1;
			addtoList.itemObjectId = new Guid(newEntityId);
			yield return addtoList;

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(AccountLookup), referer);

			this.EndTransaction("AddMembersToList");

			this.BeginTransaction("ListQuickCampaign");

			MA_MiniCampaign_MiniCampaign_aspx miniCampgn = new MA_MiniCampaign_MiniCampaign_aspx(user);
			yield return (miniCampgn);

			MarketingAutomation.MarketingAutomationWebService maws = new MarketingAutomation.MarketingAutomationWebService();
			CrmRequest wtrCRMReq = null;
			string activityString = string.Format(@"<fax><subject>{0}</subject><description>{1}</description></fax>", Utils.GetRandomString(10, 20), Utils.GetRandomString(10, 20));
			string miniCampaignName = Utils.GetRandomString(5, 10);
			try { maws.CreateMiniCampaign(4300, "", 1, new Guid(newEntityId).ToString("B"), "", "4204", 2, activityString, miniCampaignName, true, 8, new Guid(user["systemuserid"]).ToString("B"), false, String.Empty); }
			catch (crmException x)
			{
				wtrCRMReq = ProcessCRMExceptionFromWebServiceCall(x.wtr);

			}
			yield return (wtrCRMReq);

			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(WebTestHelp.RefreshGridXmls[EntityViewNames.MyQuickCampaigns]), referer);

			this.EndTransaction("ListQuickCampaign");

		}
		#endregion

		protected override string entityName
		{
			get
			{
				return EntityNames.Lists;
			}
		}

		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.MarketingSiteMapPath[EntityNames.Lists];
			}
		}

		//command xml needed for entity creation operation
		protected string commandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, entityName.ToLower(), "6e77626b-e693-44f0-a1c7-359b1a7a9a4c");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateListXml(new Guid(user["systemuserid"]), 8, currency);
				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}
		protected string formId
		{
			get
			{
				return "6e77626b-e693-44f0-a1c7-359b1a7a9a4c";
			}
		}
		protected string[] gridXmls
		{
			get
			{
				return new string[3]
				{
					WebTestHelp.RefreshGridXmls[EntityViewNames.LeadListMembers],
					WebTestHelp.RefreshGridXmls[EntityViewNames.ListCampaigns],
					WebTestHelp.RefreshGridXmls[EntityViewNames.MyQuickCampaigns] 
				};

			}
		}

		protected string queryXml
		{
			get
			{
				return WebTestHelp.QueryXmls["SystemUserQuery"];
			}
		}

		protected string SetupUserId
		{
			get
			{
				return setupuserid;
			}
		}
		#region Validate Repsonse
		/// <summary>
		/// Validate response
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">ValidationEvent</param>
		private void NewEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			newEntityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				newEntityId = new Guid(newEntityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}
		#endregion

		private string setupuserid;
		private CRMEntity currency, account;
		protected string newEntityId;
		protected readonly string newIdMarker = "\"Id\":\"{";
	}
}