namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;
	using System.Web;

	/// <summary>
	/// All Tests are written from a warm perspective(meaning that each page has been visited recently so that it is not an initial (cold) load)
	/// 1. Start at Marketing homepage
	/// 2. Select Marketing Lists
	/// 3. Click On New List
	/// 4. Enter Data and Click �Save�
	/// 5. Click Marketing List Members
	/// 6. Click Manage Members
	/// 7. Select �Use Lookup to add members�
	/// 8. Open Campaign HomePage
	/// 9. Click on New Campaign
	/// 10. Input information and Click �Save�
	/// 11. Click �Target Marketing List�
	/// 12. Add Marketing List created earlier
	/// 13. Click on �Campaign Activities� and click "New"
	/// 14. Select �Fax�
	/// 15. Fill data and click �Save�
	/// 16. Click on �Distribute Campaign Activity�
	/// 17. Fill data and click "Distribute"
	/// 18. Refresh Campaign Activity Grid till it changes to complete
	/// </summary>


	public class DistributeCampaignActivityDynamicList : WebTestBase
	{

		#region Class constructor
		/// <summary>
		/// Default class constructor
		/// </summary>
		public DistributeCampaignActivityDynamicList()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(DistributeCampaignActivityDynamicList_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(WebTestBase_PostWebTest);
		}
		#endregion

		#region Pre WebTest
		/// <summary>
		/// Pre WebTest
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void DistributeCampaignActivityDynamicList_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			//get test user
			WebTestBase_PreWebTest(sender, e);
			//get test entities owned by the test user
			currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);

			listMarketingListView = GridXmlHelper.MarketingListGridForEntityView(-1, listMarketingListViewId, null);

			campaign = RetrieveTestEntity(user, EntityNames.Campaigns);
			campaignentityId = campaign[EntityIDNames.Campaign];

		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction("CreateNewLists");

			this.BeginTransaction(string.Format("{0}HomePageNavigation", entityName));
			CrmRequest homePage = HomePageNavigation(entityName, siteMapPath);
			yield return homePage;
			this.EndTransaction(string.Format("{0}HomePageNavigation", entityName));

			string referer = homePage.lastResponse.ResponseUri.ToString();

			this.BeginTransaction(string.Format("Create{0}", entityName));
			main_aspx mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[entityName],
				extraqs = "etc=" + WebTestHelp.EntityEtc[entityName],
				pagetype = "entityrecord",
				pagemode = "iframe",

			};
			yield return mainPage;

			//create new entity
			referer = mainPage.lastResponse.ResponseUri.ToString();

			_controls_lookup_lookupinfo_aspx lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo.objecttypes = "8";
			lookupInfo.browse = 0;
			lookupInfo.LookupStyle = "single";
			lookupInfo.ShowNewButton = 1;
			lookupInfo.ShowPropButton = 1;
			lookupInfo.DefaultType = 0;
			yield return (lookupInfo);

			InlineEditHelper inlineEdit = new InlineEditHelper(commandXml, user);
			CrmRequest createEntity = inlineEdit.getInlineEditWTR(referer, 1) as CrmRequest;
			createEntity.ValidateResponse += this.NewEntity_ValidateResponse;
			yield return createEntity;
			this.EndTransaction(string.Format("Create{0}", entityName));

			Ribbon.RibbonWebService ribbon = new Ribbon.RibbonWebService();
			CrmRequest wtr = null;
			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}

			this.EndTransaction("CreateNewLists");


			this.BeginTransaction("AddMembersToList");

			MA_lists_ListQualificationDlg_dlg_query_build_aspx listQualifications = new MA_lists_ListQualificationDlg_dlg_query_build_aspx(user);
			listQualifications.InvokeType = "lqUseQuery";
			listQualifications.ListId = new Guid(newEntityId);
			listQualifications.ListMemberType = 1;

			yield return (listQualifications);

			AdvancedFind.AdvancedFind af = new AdvancedFind.AdvancedFind();

			af = new AdvancedFind.AdvancedFind();
			wtr = null;

			try { af.GetQueryList("account", 0, true, true, false); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr, referer);
			}
			yield return (wtr);

			try { af.GetSystemQuery("{00000000-0000-0000-00AA-000000666000}"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr, referer);
			}
			yield return (wtr);

			try { af.GetDefaultAdvancedFindView(entityName.ToLower(), false); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr, referer);
			}
			yield return (wtr);

			try { af.GetEntityFieldList("account".ToLower()); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr, referer);
			}
			yield return (wtr);

			try { af.GetLinkedEntityList("account".ToLower()); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr, referer);
			}
			yield return (wtr);

			try { af.GetDefaultAdvancedFindView("account".ToLower(), false); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr, referer);
			}
			yield return (wtr);

			yield return AppGridWebServiceReset(System.Web.HttpUtility.HtmlDecode("<grid><sortColumns>name&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>50</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>-1</max><refreshAsync>False</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><parameters><autorefresh>1</autorefresh><disableDblClick>0</disableDblClick><viewid>&#123;E62FC2B4-D7C3-410E-ADAA-BB65FBF6F926&#125;</viewid><viewtype>1039</viewtype><RecordsPerPage>50</RecordsPerPage><viewTitle>Active Saved Views</viewTitle><otc>4230</otc><otn>userquery</otn><entitydisplayname>Saved View</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Saved Views</entitypluraldisplayname><isWorkflowSupported>false</isWorkflowSupported><fetchXmlForFilters>&#60;fetch version&#61;&#34;1.0&#34; output-format&#61;&#34;xml-platform&#34; mapping&#61;&#34;logical&#34;&#62;&#60;entity name&#61;&#34;userquery&#34;&#62;&#60;attribute name&#61;&#34;name&#34; &#47;&#62;&#60;filter type&#61;&#34;and&#34;&#62;&#60;condition attribute&#61;&#34;statecode&#34; operator&#61;&#34;eq&#34; value&#61;&#34;0&#34; &#47;&#62;&#60;condition attribute&#61;&#34;querytype&#34; operator&#61;&#34;eq&#34; value&#61;&#34;0&#34; &#47;&#62;&#60;&#47;filter&#62;&#60;order attribute&#61;&#34;name&#34; descending&#61;&#34;false&#34; &#47;&#62;&#60;attribute name&#61;&#34;ownerid&#34; &#47;&#62;&#60;attribute name&#61;&#34;modifiedon&#34; &#47;&#62;&#60;attribute name&#61;&#34;userqueryid&#34; &#47;&#62;&#60;&#47;entity&#62;&#60;&#47;fetch&#62;</fetchXmlForFilters><isFetchXmlNotFinal>False</isFetchXmlNotFinal><effectiveFetchXml>&#60;fetch distinct&#61;&#34;false&#34; no-lock&#61;&#34;false&#34; mapping&#61;&#34;logical&#34; page&#61;&#34;1&#34; count&#61;&#34;50&#34; returntotalrecordcount&#61;&#34;true&#34;&#62;&#60;entity name&#61;&#34;userquery&#34;&#62;&#60;attribute name&#61;&#34;name&#34; &#47;&#62;&#60;attribute name&#61;&#34;ownerid&#34; &#47;&#62;&#60;attribute name&#61;&#34;modifiedon&#34; &#47;&#62;&#60;attribute name&#61;&#34;userqueryid&#34; &#47;&#62;&#60;attribute name&#61;&#34;name&#34; &#47;&#62;&#60;attribute name&#61;&#34;ownerid&#34; &#47;&#62;&#60;attribute name&#61;&#34;modifiedon&#34; &#47;&#62;&#60;attribute name&#61;&#34;returnedtypecode&#34; &#47;&#62;&#60;filter type&#61;&#34;and&#34;&#62;&#60;condition attribute&#61;&#34;statecode&#34; operator&#61;&#34;eq&#34; value&#61;&#34;0&#34; &#47;&#62;&#60;condition attribute&#61;&#34;querytype&#34; operator&#61;&#34;eq&#34; value&#61;&#34;0&#34; &#47;&#62;&#60;&#47;filter&#62;&#60;order attribute&#61;&#34;name&#34; descending&#61;&#34;false&#34; &#47;&#62;&#60;&#47;entity&#62;&#60;&#47;fetch&#62;</effectiveFetchXml><LayoutStyle>GridList</LayoutStyle><enableFilters>1</enableFilters><returnedtypecode>1</returnedtypecode><customquery>FilterByObjectType</customquery></parameters></grid>"), referer);

			MA_Lists_ListQualificationDlg_dlg_DynamicList_query_aspx listQuery = new MA_Lists_ListQualificationDlg_dlg_DynamicList_query_aspx(user);
			listQuery.itemObjectId = new Guid(newEntityId);
			StringHttpBody listqueryBody = new StringHttpBody();
			listqueryBody.BodyString = "<root><fetch version=\"1.0\" output-format=\"xml-platform\" mapping=\"logical\" distinct=\"false\"><entity name=\"account\"><attribute name=\"name\"/><attribute name=\"address1_city\"/><attribute name=\"primarycontactid\"/><attribute name=\"telephone1\"/><attribute name=\"accountid\"/><order attribute=\"name\" descending=\"false\"/><filter type=\"and\"><condition attribute=\"ownerid\" operator=\"eq-userid\"/><condition attribute=\"statecode\" operator=\"eq\" value=\"0\"/></filter><link-entity name=\"contact\" from=\"contactid\" to=\"primarycontactid\" visible=\"false\" link-type=\"outer\" alias=\"accountprimarycontactidcontactcontactid\"><attribute name=\"emailaddress1\"/></link-entity></entity></fetch><Ids></Ids></root>";
			listqueryBody.ContentType = "text/xml";
			listQuery.Body = listqueryBody;
			rpcInfo = Utils.GenerateWRPCToken();


			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCTokenTimeStamp";
			headerItem.Value = rpcInfo.timeStamp.ToString();
			listQuery.Headers.Add(headerItem);
			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCToken";
			headerItem.Value = rpcInfo.token;
			listQuery.Headers.Add(headerItem);
			listQuery.Method = "Post";

			yield return (listQuery);

			this.EndTransaction("AddMembersToList");


			this.BeginTransaction(string.Format("{0}HomepageNavigation", EntityNames.Campaigns));
			yield return HomePageNavigation(EntityNames.Campaigns, siteMapPath);
			this.EndTransaction(string.Format("{0}HomepageNavigation", EntityNames.Campaigns));

			this.BeginTransaction(string.Format("Create{0}", EntityNames.Campaigns));
			mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[EntityNames.Campaigns],
				extraqs = "etc=" + WebTestHelp.EntityEtc[EntityNames.Campaigns],
				pagetype = "entityrecord",
				pagemode = "iframe",

			};
			yield return mainPage;

			referer = mainPage.lastResponse.ResponseUri.ToString();

			inlineEdit = new InlineEditHelper(campaigncommandXml, user);
			createEntity = inlineEdit.getInlineEditWTR(referer, 1) as CrmRequest;
			createEntity.ValidateResponse += this.NewCampaignEntity_ValidateResponse;
			yield return createEntity;

			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", "6356ff2a-bbbe-49fb-9da2-160b08865688", referer, campaignentityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}

			this.EndTransaction(string.Format("Create{0}", EntityNames.Campaigns));


			//open an entity
			this.BeginTransaction(string.Format("Open{0}", EntityNames.Campaigns));
			CrmRequest openEntity = OpenEntity(EntityNames.Campaigns, WebTestHelp.EntityEtc[EntityNames.Campaigns], WebTestHelp.EntityEtc[EntityNames.Campaigns], new Guid(campaignentityId));
			yield return openEntity;
			this.EndTransaction(string.Format("Open{0}", EntityNames.Campaigns));


			this.BeginTransaction("AddListToCampaign");


			lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo.Class = "";
			lookupInfo.objecttypes = "4300";
			lookupInfo.browse = 0;
			lookupInfo.LookupStyle = "multi";
			yield return (lookupInfo);

			ActivitiesWebService.ActivitiesWebService actws = new ActivitiesWebService.ActivitiesWebService();
			wtr = null;
			try { actws.GetQueryListForLookup("4300", 0); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtr);

			yield return AppGridWebServiceReset(System.Web.HttpUtility.HtmlDecode(listMarketingListView), referer);


			_grid_cmds_dlg_listcaassociation_aspx lassoc = new _grid_cmds_dlg_listcaassociation_aspx(user);
			lassoc.iObjType = 4300;
			yield return (lassoc);

			AssociateRecords.AssociateRecords ar = new AssociateRecords.AssociateRecords();
			WebTestRequest wtrRefresh = null;
			try { ar.Associate(4300, 4400, new Guid(newEntityId), new Guid(campaignentityId), "targetListsaddtoCA", "campaignlist_association"); }
			catch (crmException x)
			{
				wtrRefresh = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtrRefresh);

			_grid_cmds_dlg_listcaassociation_aspx lassoc2 = new _grid_cmds_dlg_listcaassociation_aspx(user);
			lassoc2.iObjType = 4300;
			yield return (lassoc2);

			// Make the list Grid for members
			yield return AppGridWebServiceReset(System.Web.HttpUtility.HtmlDecode(WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignMarketingLists]), referer);

			this.EndTransaction("AddListToCampaign");

			this.BeginTransaction("CreateCampaignActivity");
			mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[EntityNames.CampaignActivities],
				extraqs = string.Format("?_CreateFromId=%7b{0}%7d&_CreateFromType={1}&etc={2}", campaignentityId, WebTestHelp.EntityEtc[EntityNames.Campaigns].ToString(), WebTestHelp.EntityEtc[EntityNames.CampaignActivities].ToString()),
				pagetype = "entityrecord",
			};
			yield return mainPage;

			this.BeginTransaction(string.Format("CreateAssosiatedEntity{0}", EntityNames.CampaignActivities));
			InlineEditHelper inlineEditHelper = new InlineEditHelper(AssosiatedEntityCommandXml, user);
			CrmRequest createAssosiateEntity = inlineEditHelper.getInlineEditWTR(referer, 1) as CrmRequest;
			yield return createAssosiateEntity;
			this.EndTransaction(string.Format("CreateAssosiatedEntity{0}", EntityNames.CampaignActivities));
			int idIdx = createAssosiateEntity.lastResponse.BodyString.IndexOf(newIdMarker);
			string campaignActivityId = createAssosiateEntity.lastResponse.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			campaignActivityId = new Guid(campaignActivityId).ToString();

			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			this.EndTransaction("CreateCampaignActivity");

			this.BeginTransaction("PropogateCampaignActivity");

			MarketingAutomation.MarketingAutomationWebService maws = new MarketingAutomation.MarketingAutomationWebService();
			try { maws.GetTargetListAssociated(new Guid(campaignActivityId)); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtr);

			_grid_cmds_dlg_listfax_aspx listFax = new _grid_cmds_dlg_listfax_aspx(user);
			listFax.iObjType = 4402;
			listFax.iTotal = 1;
			listFax.sIds = HttpUtility.UrlEncode(new Guid(campaignActivityId).ToString("B").ToUpper());
			yield return (listFax);

			referer = listFax.lastResponse.ResponseUri.AbsoluteUri;

			MA_CampaignActivity_Dialogs_confirm_propagation_aspx propConfirm = new MA_CampaignActivity_Dialogs_confirm_propagation_aspx(user);
			propConfirm.EntityTypeCode = 4204;
			yield return (propConfirm);

			listFax = new _grid_cmds_dlg_listfax_aspx(user);
			listFax.iObjType = 4402;
			listFax.iTotal = 1;
			listFax.iIndex = 0;
			listFax.SendEmail = false;
			listFax.ownerType = 8;
			listFax.OwnerOption = 3;
			listFax.iId = new Guid(campaignActivityId);


			StringHttpBody httpBody = new StringHttpBody();
			string faxXml = "<fax><directioncode>1</directioncode><subject>" + Utils.GetRandomString(10, 15) + "</subject><description>" + Utils.GetRandomString(100, 120) + "</description><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode></fax>";
			httpBody.BodyString = faxXml;
			httpBody.ContentType = "text/xml";
			listFax.Body = httpBody;

			rpcInfo = Utils.GenerateWRPCToken();

			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCTokenTimeStamp";
			headerItem.Value = rpcInfo.timeStamp.ToString();
			listFax.Headers.Add(headerItem);
			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCToken";
			headerItem.Value = rpcInfo.token;
			listFax.Headers.Add(headerItem);
			listFax.Method = "Post";
			yield return (listFax);

			this.EndTransaction("PropogateCampaignActivity");
		}

		#endregion

		protected override string entityName
		{
			get
			{
				return EntityNames.Lists;
			}
		}
		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.MarketingSiteMapPath[EntityNames.Lists];
			}
		}
		protected string formId
		{
			get
			{
				return "6e77626b-e693-44f0-a1c7-359b1a7a9a4c";
			}
		}
		//command xml needed for entity creation operation
		protected string commandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, entityName.ToLower(), "6e77626b-e693-44f0-a1c7-359b1a7a9a4c");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateListXml(new Guid(user["systemuserid"]), 8, currency);
				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}

		protected string AssosiatedEntityCommandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, EntityNames.CampaignActivities.ToLower(), "30b5a041-afe1-4ced-91c5-86c7554df10c");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				if (newEntityId != null)
				{
					string dataXml = EntityXmlHelper.GetCreateCampaignActivityXml(new Guid(user[EntityIDNames.User]), 8, new Guid(campaignentityId), 4400, 5, currency);

					//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
					dataXml = dataXml.Replace("<", "&#60;");
					dataXml = dataXml.Replace(">", "&#62;");
					dataXml = dataXml.Replace("</", "&#60;&#47;");
					dataXml = dataXml.Replace("=", "&#61;");
					dataXml = dataXml.Replace("\"", "&#34;");
					sb.Append(dataXml);
					sb.Append(commandXml_post);


				}
				return sb.ToString(); ;
			}
		}

		protected string campaigncommandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, EntityNames.Campaigns.ToLower(), "6356ff2a-bbbe-49fb-9da2-160b08865688");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateCampaignXml(new Guid(user[EntityIDNames.User]), 8);
				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}

		#region Validate Repsonse
		/// <summary>
		/// Validate response
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">ValidationEvent</param>
		private void NewEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			newEntityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				newEntityId = new Guid(newEntityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}

		private void NewCampaignEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			campaignentityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				newEntityId = new Guid(newEntityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}
		#endregion
		private CRMEntity currency, campaign;
		protected string newEntityId, campaignentityId;
		protected readonly string newIdMarker = "\"Id\":\"{";
		private static string listMarketingListViewId = "F500D0FA-A21E-47FB-B0C6-7BE373175895";
		private string listMarketingListView;
	}
}