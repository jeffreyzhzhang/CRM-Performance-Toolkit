namespace CRM_Perf_BenchMark
{
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System;
	using System.Collections.Generic;

	/// <summary>
	/// 1. Starts at Workplace homepage
	/// 2. Click on Dashboards
	/// 3. Select Customer Service Performance Dashboard
	/// </summary>

	public class MarketingDashboard : WebTestBase
	{
		#region Pre Webtest
		public void MarketingDashboard_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			WebTestBase_PreWebTest(sender, e);
		}
		#endregion

		#region Class constructor
		public MarketingDashboard()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(MarketingDashboard_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(WebTestBase_PostWebTest);
		}
		#endregion

		#region Web test simulation
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			#region Dashboard home page navigation
			this.BeginTransaction("NavDashboardHomePage");
			// Get the home page
			workplace_home_dashboards_aspx hp = new workplace_home_dashboards_aspx(user);
			hp.pagemode = "iframe";
			hp.sitemappath = "Workplace|MyWork|nav_dashboards";
			yield return (hp);
			this.EndTransaction("NavDashboardHomePage");

			this.BeginTransaction("MarketingDashboard");

			this.BeginTransaction("MarketingDashboard-Dashboardaspx");
			dashboards_dashboard_aspx marketingDashboardPage = new dashboards_dashboard_aspx(user);
			marketingDashboardPage.dashboardId = new Guid("{9DE6D9A5-7863-DF11-AE90-00155D2E3002}"); // marketing
			marketingDashboardPage.dashboardType = 1030;
			marketingDashboardPage.pagemode = "iframe";

			yield return (marketingDashboardPage);
			this.EndTransaction("MarketingDashboard-Dashboardaspx");
			#endregion

			referer = marketingDashboardPage.lastResponse.ResponseUri.AbsoluteUri;

			#region Display campaignBudgetvsActualCostsByFiscalChart
			this.BeginTransaction("MarketingDashboard - campaignBudgetvsActualCostsByFiscalChart");
			visualization_visualization_aspx campaignBudgetvsActualCostsByFiscalChart = new visualization_visualization_aspx(user)
			{
				uniqueId = Utils.GetRandomDouble().ToString() + uniqueId_campaignBudgetvsActualCostsByFiscalChart,
				vizXml = WebTestHelp.VizXml[ChartNames.CampaignBudgetvsActualCostsByFiscalChart]
			};
			yield return (campaignBudgetvsActualCostsByFiscalChart);
			this.EndTransaction("MarketingDashboard - campaignBudgetvsActualCostsByFiscalChart");
			#endregion

			#region Display campaignBudgetvsActualCostsByFiscalChart
			this.BeginTransaction("MarketingDashboard - leadsbySourceCampaignChart");
			visualization_visualization_aspx leadsbySourceCampaignChart = new visualization_visualization_aspx(user)
			{
				uniqueId = Utils.GetRandomDouble().ToString() + uniqueId_leadsbySourceCampaignChart,
				vizXml = WebTestHelp.VizXml[ChartNames.LeadsbySourceCampaignChart]
			};
			yield return (leadsbySourceCampaignChart);
			this.EndTransaction("MarketingDashboard - leadsbySourceCampaignChart");
			#endregion

			#region Display revenueGeneratedbyCampaignChart
			this.BeginTransaction("MarketingDashboard - revenueGeneratedbyCampaignChart");
			visualization_visualization_aspx revenueGeneratedbyCampaignChart = new visualization_visualization_aspx(user)
			{
				uniqueId = Utils.GetRandomDouble().ToString() + uniqueId_revenueGeneratedbyCampaignChart,
				vizXml = WebTestHelp.VizXml[ChartNames.RevenueGeneratedbyCampaignChart]
			};
			yield return (revenueGeneratedbyCampaignChart);
			this.EndTransaction("MarketingDashboard - revenueGeneratedbyCampaignChart");
			#endregion

			#region Display campaignTypeMixChart
			this.BeginTransaction("MarketingDashboard - campaignTypeMixChart");
			visualization_visualization_aspx campaignTypeMixChart = new visualization_visualization_aspx(user)
			{
				uniqueId = Utils.GetRandomDouble().ToString() + uniqueId_campaignTypeMixChart,
				vizXml = WebTestHelp.VizXml[ChartNames.CampaignTypeMixChart]
			};
			yield return (campaignTypeMixChart);
			this.EndTransaction("MarketingDashboard - campaignTypeMixChart");
			#endregion

			this.EndTransaction("MarketingDashboard");

		}
		#endregion

		protected override string entityName
		{
			get
			{
				return "";
			}
		}

		protected override string siteMapPath
		{
			get
			{
				return "Workplace|MyWork|nav_dashboards";
			}
		}

		private string referer;
		private string uniqueId_campaignBudgetvsActualCostsByFiscalChart = "{587523F8-D186-DE11-9FF3-00155DA3B012}";
		private string uniqueId_leadsbySourceCampaignChart = "{3ED18B7C-5693-DE11-97D4-00155DA3B01E}";
		private string uniqueId_revenueGeneratedbyCampaignChart = "{ABD3696C-A982-DE11-9FF3-00155DA3B012}";
		private string uniqueId_campaignTypeMixChart = "{8BCEA361-2582-DE11-9FF3-00155DA3B012}";

	}
}