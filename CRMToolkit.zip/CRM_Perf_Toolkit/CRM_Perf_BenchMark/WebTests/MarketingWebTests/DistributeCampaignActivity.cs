namespace CRM_Performance_BenchMark
{
	using System;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Net;
	using System.Text;
	using System.Xml;
	using CRM_Perf_BenchMark;
	using Microsoft.Crm;
	using System.Web;


	/// <summary>
	/// All Tests are written from a warm perspective(meaning that each page has been visited recently so that it is not an initial (cold) load)
	/// 1. Start at Marketing homepage
	/// 2. Select Marketing Lists
	/// 3. Click On New List
	/// 4. Enter Data and Click �Save�
	/// 5. Click Add Icon on Members
	/// 6. Select �Use Lookup to add members�
	/// 7. Open Campaign HomePage
	/// 8. Click on New Campaign
	/// 9. Input information and Click �Save�
	/// 10. Click �Target Marketing List�
	/// 11. Add Marketing List created earlier
	/// 12. Click on �Campaign Activities� and click "New"
	/// 13. Select �task�
	/// 14. Fill data and click �Save�
	/// 15. Click on �Distribute Campaign Activity�
	/// 16. Fill data and click "Distribute"
	/// 17. Refresh Campaign Activity Grid till it changes to complete
	/// </summary>


	public class DistributeCampaignActivity : WebTestBase
	{

		#region Class constructor
		/// <summary>
		/// Default class constructor
		/// </summary>
		public DistributeCampaignActivity()
		{
			PreWebTest += new EventHandler<PreWebTestEventArgs>(DistributeCampaignActivity_PreWebTest);
			PostWebTest += new EventHandler<PostWebTestEventArgs>(WebTestBase_PostWebTest);
		}
		#endregion

		#region Pre WebTest
		/// <summary>
		/// Pre WebTest
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		public void DistributeCampaignActivity_PreWebTest(object sender, PreWebTestEventArgs e)
		{
			//get test user
			WebTestBase_PreWebTest(sender, e);
			//get test entities owned by the test user
			currency = RetrieveTestEntity(new Guid(user["organizationid"]), EntityNames.TransactionCurrency);
			GetSecondUser(new Guid(user["organizationid"]));
			listMarketingListView = GridXmlHelper.MarketingListGridForEntityView(-1, listMarketingListViewId, null);
			account = RetrieveTestEntity(user, EntityNames.Accounts);
			campaign = RetrieveTestEntity(user, EntityNames.Campaigns);
			campaignentityId = campaign[EntityIDNames.Campaign];

		}
		#endregion

		#region Web request simulation
		/// <summary>
		/// Web request simulation
		/// </summary>
		/// <returns></returns>
		public override IEnumerator<WebTestRequest> GetRequestEnumerator()
		{
			this.BeginTransaction("CreateNewLists");

			this.BeginTransaction(string.Format("{0}HomePageNavigation", entityName));
			CrmRequest homePage = HomePageNavigation(entityName, siteMapPath);
			yield return homePage;
			this.EndTransaction(string.Format("{0}HomePageNavigation", entityName));

			string referer = homePage.lastResponse.ResponseUri.ToString();

			this.BeginTransaction(string.Format("Create{0}", entityName));
			main_aspx mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[entityName],
				extraqs = "etc=" + WebTestHelp.EntityEtc[entityName],
				pagetype = "entityrecord",
				pagemode = "iframe",

			};
			yield return mainPage;

			//create new entity
			referer = mainPage.lastResponse.ResponseUri.ToString();

			_controls_lookup_lookupinfo_aspx lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo.objecttypes = "8";
			lookupInfo.browse = 0;
			lookupInfo.LookupStyle = "single";
			lookupInfo.ShowNewButton = 1;
			lookupInfo.ShowPropButton = 1;
			lookupInfo.DefaultType = 0;
			yield return (lookupInfo);

			InlineEditHelper inlineEdit = new InlineEditHelper(commandXml, user);
			CrmRequest createEntity = inlineEdit.getInlineEditWTR(referer, 1) as CrmRequest;
			createEntity.ValidateResponse += this.NewEntity_ValidateResponse;
			yield return createEntity;
			this.EndTransaction(string.Format("Create{0}", entityName));

			Ribbon.RibbonWebService ribbon = new Ribbon.RibbonWebService();
			CrmRequest wtr = null;
			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}

			this.EndTransaction("CreateNewLists");


			this.BeginTransaction("AddMembersToList");

			lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo.objecttypes = "1";
			lookupInfo.browse = 0;
			lookupInfo.LookupStyle = "multi";
			yield return (lookupInfo);

			string AccountLookup = WebTestHelp.RefreshGridXmls[EntityViewNames.AccountLookup];
			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(AccountLookup), referer);

			_grid_cmds_dlg_addtolist_aspx addtoList = new _grid_cmds_dlg_addtolist_aspx(user);
			addtoList.iId = new Guid(account[EntityIDNames.Account]);
			addtoList.iObjType = 1;
			addtoList.iTotal = 1;
			addtoList.itemObjectId = new Guid(newEntityId);

			yield return addtoList;


			yield return AppGridWebServiceRefresh(System.Web.HttpUtility.HtmlDecode(AccountLookup), referer);


			this.EndTransaction("AddMembersToList");

			this.BeginTransaction(string.Format("{0}HomepageNavigation", EntityNames.Campaigns));
			yield return HomePageNavigation(EntityNames.Campaigns, siteMapPath);
			this.EndTransaction(string.Format("{0}HomepageNavigation", EntityNames.Campaigns));

			this.BeginTransaction(string.Format("Create{0}", EntityNames.Campaigns));
			mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[EntityNames.Campaigns],
				extraqs = "etc=" + WebTestHelp.EntityEtc[EntityNames.Campaigns],
				pagetype = "entityrecord",
				pagemode = "iframe",

			};
			yield return mainPage;

			referer = mainPage.lastResponse.ResponseUri.ToString();

			inlineEdit = new InlineEditHelper(campaigncommandXml, user);
			createEntity = inlineEdit.getInlineEditWTR(referer, 1) as CrmRequest;
			createEntity.ValidateResponse += this.NewCampaignEntity_ValidateResponse;
			yield return createEntity;
			this.EndTransaction(string.Format("Create{0}", EntityNames.Campaigns));

			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}


			//open an entity
			mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[EntityNames.Campaigns],
				extraqs = "etc=" + WebTestHelp.EntityEtc[EntityNames.Campaigns],
				pagetype = "entityrecord",
				pagemode = "iframe",

			};
			yield return mainPage;

			this.BeginTransaction(string.Format("Open{0}", EntityNames.Campaigns));
			CrmRequest openEntity = OpenEntity(EntityNames.Campaigns, WebTestHelp.EntityEtc[EntityNames.Campaigns], WebTestHelp.EntityEtc[EntityNames.Campaigns], new Guid(campaignentityId));
			yield return openEntity;
			this.EndTransaction(string.Format("Open{0}", EntityNames.Campaigns));


			this.BeginTransaction("AddListToCampaign");


			lookupInfo = new _controls_lookup_lookupinfo_aspx(user);
			lookupInfo.Class = "";
			lookupInfo.objecttypes = "4300";
			lookupInfo.browse = 0;
			lookupInfo.LookupStyle = "multi";
			yield return (lookupInfo);

			yield return AppGridWebServiceReset(System.Web.HttpUtility.HtmlDecode(listMarketingListView), referer);

			_grid_cmds_dlg_listcaassociation_aspx lassoc = new _grid_cmds_dlg_listcaassociation_aspx(user);
			lassoc.iObjType = 4300;
			yield return (lassoc);

			AssociateRecords.AssociateRecords ar = new AssociateRecords.AssociateRecords();

			WebTestRequest wtrRefresh = null;
			try { ar.Associate(4300, 4400, new Guid(newEntityId), new Guid(campaignentityId), "targetListsaddtoCA", "campaignlist_association"); }
			catch (crmException x)
			{
				wtrRefresh = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtrRefresh);

			_grid_cmds_dlg_listcaassociation_aspx lassoc2 = new _grid_cmds_dlg_listcaassociation_aspx(user);
			lassoc2.iObjType = 4300;
			yield return (lassoc2);

			// Make the list Grid for members
			yield return AppGridWebServiceReset(System.Web.HttpUtility.HtmlDecode(WebTestHelp.RefreshGridXmls[EntityViewNames.CampaignMarketingLists]), referer);

			this.EndTransaction("AddListToCampaign");

			this.BeginTransaction("CreateCampaignActivity");
			mainPage = new main_aspx(user)
			{
				etc = WebTestHelp.EntityEtc[EntityNames.CampaignActivities],
				extraqs = string.Format("?_CreateFromId=%7b{0}%7d&_CreateFromType={1}&etc={2}", campaignentityId, WebTestHelp.EntityEtc[EntityNames.Campaigns].ToString(), WebTestHelp.EntityEtc[EntityNames.CampaignActivities].ToString()),

				pagetype = "entityrecord",
			};
			yield return mainPage;

			this.BeginTransaction(string.Format("CreateAssosiatedEntity{0}", EntityNames.CampaignActivities));
			InlineEditHelper inlineEditHelper = new InlineEditHelper(AssosiatedEntityCommandXml, user);
			CrmRequest createAssosiateEntity = inlineEditHelper.getInlineEditWTR(referer, 1) as CrmRequest;
			yield return createAssosiateEntity;
			this.EndTransaction(string.Format("CreateAssosiatedEntity{0}", EntityNames.CampaignActivities));
			int idIdx = createAssosiateEntity.lastResponse.BodyString.IndexOf(newIdMarker);
			string campaignActivityId = createAssosiateEntity.lastResponse.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			campaignActivityId = new Guid(campaignActivityId).ToString();

			try { ribbon.ReloadCommandBar(entityName.ToLower(), "Form", formId, referer, newEntityId, "2"); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}

			this.EndTransaction("CreateCampaignActivity");

			this.BeginTransaction("PropogateCampaignActivity");

			MarketingAutomation.MarketingAutomationWebService maws = new MarketingAutomation.MarketingAutomationWebService();
			try { maws.GetTargetListAssociated(new Guid(campaignActivityId)); }
			catch (crmException x)
			{
				wtr = ProcessCRMExceptionFromWebServiceCall(x.wtr);
			}
			yield return (wtr);

			_grid_cmds_dlg_listfax_aspx listFax = new _grid_cmds_dlg_listfax_aspx(user);
			//listFax.dType = 1;
			listFax.iObjType = 4402;
			listFax.iTotal = 1;
			listFax.sIds = new Guid(campaignActivityId).ToString("B");
			yield return (listFax);

			referer = listFax.lastResponse.ResponseUri.AbsoluteUri;

			MA_CampaignActivity_Dialogs_confirm_propagation_aspx propConfirm = new MA_CampaignActivity_Dialogs_confirm_propagation_aspx(user);
			propConfirm.EntityTypeCode = 4204;
			yield return (propConfirm);

			listFax = new _grid_cmds_dlg_listfax_aspx(user);
			listFax.iObjType = 4402;
			listFax.iTotal = 1;
			listFax.iIndex = 0;
			listFax.SendEmail = false;
			listFax.ownerType = 8;
			listFax.OwnerOption = 3;
			listFax.iId = new Guid(campaignActivityId);


			StringHttpBody httpBody = new StringHttpBody();
			string faxXml = "<fax><directioncode>1</directioncode><subject>" + Utils.GetRandomString(10, 15) + "</subject><description>" + Utils.GetRandomString(100, 120) + "</description><actualdurationminutes>30</actualdurationminutes><prioritycode>1</prioritycode></fax>";
			httpBody.BodyString = faxXml;
			httpBody.ContentType = "text/xml";
			listFax.Body = httpBody;

			rpcInfo = Utils.GenerateWRPCToken();

			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCTokenTimeStamp";
			headerItem.Value = rpcInfo.timeStamp.ToString();
			listFax.Headers.Add(headerItem);
			headerItem = new WebTestRequestHeader();
			headerItem.Name = "CRMWRPCToken";
			headerItem.Value = rpcInfo.token;
			listFax.Headers.Add(headerItem);
			listFax.Method = "Post";
			yield return (listFax);

			this.EndTransaction("PropogateCampaignActivity");
		}

		#endregion

		protected override string entityName
		{
			get
			{
				return EntityNames.Lists;
			}
		}
		protected override string siteMapPath
		{
			get
			{
				return WebTestHelp.MarketingSiteMapPath[EntityNames.Lists];
			}
		}
		protected string formId
		{
			get
			{
				return "6e77626b-e693-44f0-a1c7-359b1a7a9a4c";
			}
		}
		//command xml needed for entity creation operation
		protected string commandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, entityName.ToLower(), "6e77626b-e693-44f0-a1c7-359b1a7a9a4c");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateListXml(new Guid(user["systemuserid"]), 8, currency);
				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}

		protected string AssosiatedEntityCommandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, EntityNames.CampaignActivities.ToLower(), "30b5a041-afe1-4ced-91c5-86c7554df10c");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				if (newEntityId != null)
				{
					string dataXml = EntityXmlHelper.GetCreateCampaignActivityXml(new Guid(user[EntityIDNames.User]), 8, new Guid(campaignentityId), 4400, 5, currency);

					//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
					dataXml = dataXml.Replace("<", "&#60;");
					dataXml = dataXml.Replace(">", "&#62;");
					dataXml = dataXml.Replace("</", "&#60;&#47;");
					dataXml = dataXml.Replace("=", "&#61;");
					dataXml = dataXml.Replace("\"", "&#34;");
					sb.Append(dataXml);
					sb.Append(commandXml_post);


				}
				return sb.ToString(); ;
			}
		}

		protected string campaigncommandXml
		{
			get
			{
				string commandXml_pre = string.Format("<Input><id>{0}</id><name>{1}</name><formId>{2}</formId><dataxml>", Guid.Empty, EntityNames.Campaigns.ToLower(), "6356ff2a-bbbe-49fb-9da2-160b08865688");
				string commandXml_post = "</dataxml><associations></associations></Input>";
				StringBuilder sb = new StringBuilder(commandXml_pre);
				string dataXml = EntityXmlHelper.GetCreateCampaignXml(new Guid(user[EntityIDNames.User]), 8);
				//need to convert the special characters to html entity numeric format so that they can be recognized by the produciton code 
				dataXml = dataXml.Replace("<", "&#60;");
				dataXml = dataXml.Replace(">", "&#62;");
				dataXml = dataXml.Replace("</", "&#60;&#47;");
				dataXml = dataXml.Replace("=", "&#61;");
				dataXml = dataXml.Replace("\"", "&#34;");
				sb.Append(dataXml);
				sb.Append(commandXml_post);
				return sb.ToString();
			}
		}

		#region Validate Repsonse
		/// <summary>
		/// Validate response
		/// </summary>
		/// <param name="sender">sender</param>
		/// <param name="e">ValidationEvent</param>
		private void NewEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			newEntityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				newEntityId = new Guid(newEntityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}

		private void NewCampaignEntity_ValidateResponse(object sender, ValidationEventArgs e)
		{
			int idIdx = e.Response.BodyString.IndexOf(newIdMarker);
			campaignentityId = e.Response.BodyString.Substring(idIdx + (newIdMarker.Length), 36);
			try
			{
				newEntityId = new Guid(newEntityId).ToString();
			}
			catch (System.FormatException fe)
			{
				System.Diagnostics.Trace.WriteLine("Format exception: " + fe.ToString());
				e.IsValid = false;
				return;
			}
			e.IsValid = true;
		}
		#endregion
		private CRMEntity currency, account, campaign;
		protected string newEntityId, campaignentityId;
		protected readonly string newIdMarker = "\"Id\":\"{";
		private static string listMarketingListViewId = "F500D0FA-A21E-47FB-B0C6-7BE373175895";
		//private static string listViewInCampaignViewId = "BDD93547-53F6-4609-B591-9F48CE86295F";
		private string listMarketingListView;
	}
}