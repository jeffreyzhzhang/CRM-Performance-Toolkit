﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace CRM_Perf_BenchMark
{
	public static class Roles
	{
		public const string SalesPerson = "Salesperson";
		public const string SystemAdministrator = "System Administrator";
		public const string MarketingProfessional = "Marketing Professional";
		public const string CSR = "Customer Service Representative";
		public const string Scheduler = "Scheduler";
		public const string VPMarketing = "Vice President of Marketing";
		public const string SalesManager = "Sales Manager";
		public const string ScheduleManager = "Schedule Manager";
		public const string CEO = "CEO-Business Manager";
		public const string SupportUser = "Support User";
		public const string MarketingManager = "Marketing Manager";
		public const string SystemCustomizer = "System Customizer";
		public const string CSRManager = "CSR Manager";
		public const string VPSales = "Vice President of Sales";
	}

	/// <summary>
	/// List of enty names. The naming scheme corresponds to the CRM 2.0 database table naming scheme.
	/// </summary>
	public static class EntityNames
	{
		public const string Users = "SystemUser";
		public const string Leads = "Lead";
		public const string Opportunities = "Opportunity";
		public const string Accounts = "Account";
		public const string Appointments = "Appointment";
		public const string ExchangeContact = "ExchangeContact";
		public const string ExchangeTask = "ExchangeTask";
		public const string ExchangeAppointment = "ExchangeAppointment";
		public const string ExchangeRecurringAppointment = "ExchangeRecurringAppointmentMaster";
		public const string RecurringAppointments = "RecurringAppointmentMaster";
		public const string Emails = "Email";
		public const string Phonecalls = "Phonecall";
		public const string Letters = "Letter";
		public const string Faxes = "Fax";
		public const string Contacts = "Contact";
		public const string Goals = "Goal";
		public const string GenericActivities = "GenericActivities";
		public const string Service = "Service";
		public const string Subject = "Subject";
		public const string Tasks = "Task";
		public const string Quotes = "Quote";
		public const string Templates = "Template";
		public const string Roles = "Role";
		public const string Incidents = "Incident";
		public const string Notes = "Annotation";
		public const string PriceLevels = "PriceLevel";
		public const string Lists = "List";
		public const string OwningBusinessUnit = "OwningBusinessUnit";
		public const string BusinessUnits = "BusinessUnit";
		public const string Campaigns = "Campaign";
		public const string ServiceAppointments = "ServiceAppointment";
		public const string Privileges = "Privilege";
		public const string Organizations = "Organization";
		public const string Equipment = "Equipment";
		public const string Team = "Team";
		public const string SavedQueryVisualizations = "SavedQueryVisualization";
		public const string SpSite = "SharePointSite";
		public const string SharePointDocumentLocation = "SharePointDocumentLocation";
		public const string Solution = "Solution";
		public const string Reports = "Report";
		public const string New_Simple_CustomAccounts = "New_Simple_CustomAccount";
		public const string TransactionCurrency = "TransactionCurrency";
		public const string ConnectionRole = "ConnectionRole";
		public const string Queue = "Queue";
		public const string Workflow = "Workflow";
		public const string New_IM = "new_IM";
		public const string New_Prospect = "new_Prospect";
		public const string Competitor = "Competitor";
		public const string Contracts = "Contract";
		public const string Products = "Product";
		public const string SalesOrders = "SalesOrder";
		public const string Invoice = "Invoice";
		public const string QuoteDetails = "QuoteDetail";
		public const string InvoiceDetails = "InvoiceDetail";
		public const string CampaignActivities = "Campaignactivity";
		public const string CampaignResponse = "CampaignResponse";
		public const string UoM = "UoM";
		public const string SalesOrderDetails = "SalesOrderDetail";
		public const string Connections = "Connection";
		public const string ProductPriceLevels = "ProductPriceLevel";
		public const string SLA = "SLA";
		public const string SocialInsightsConfiguration = "SocialInsightsConfiguration";
		public const string Resource = "Resource";
		public const string OpportunityProduct = "OpportunityProduct";
		public const string New_CustomAccount = "new_customaccount";
		public const string New_CustomOpportunity = "new_customopportunity";
		public const string Entitlements = "Entitlement";
		public const string HostedApplication = "UII_hostedapplication";
	}

	/// <summary>
	/// Names of the primary key for each entity type.
	/// </summary>
	public static class EntityIDNames
	{
		public const string User = "SystemUserId";
		public const string Lead = "LeadId";
		public const string Opportunities = "OpportunityId";
		public const string Account = "AccountId";
		public const string Appointment = "ActivityId";
		public const string ExchangeSync = "ObjectId";
		public const string ExchangeTask = "ExchangeId";
		public const string RecurringAppointmentMaster = "ActivityId";
		public const string Phonecall = "ActivityId";
		public const string Fax = "ActivityId";
		public const string Email = "ActivityId";
		public const string Letter = "ActivityId";
		public const string Contact = "ContactId";
		public const string Task = "ActivityId";
		public const string Service = "ServiceId";
		public const string Subject = "SubjectId";
		public const string Quote = "QuoteId";
		public const string Template = "TemplateId";
		public const string Role = "RoleId";
		public const string Incident = "IncidentId";
		public const string Note = "AnnotationId";
		public const string PriceLevel = "PriceLevelId";
		public const string List = "ListId";
		public const string OwningBusinessUnit = "BusinessUnitId";
		public const string BusinessUnit = "BusinessUnitId";
		public const string Campaign = "CampaignId";
		public const string ServiceAppointment = "ActivityId";
		public const string Privilege = "Name";
		public const string Organization = "OrganizationId";
		public const string Goal = "GoalId";
		public const string Equipment = "EquipmentId";
		public const string Team = "TeamId";
		public const string SavedQueryVisualizationId = "SavedQueryVisualizationId";
		public const string SpSite = "SharePointSiteId";
		public const string SharePointDocumentLocation = "SharePointDocumentLocationId";
		public const string Solution = "SolutionId";
		public const string Report = "ReportId";
		public const string TransactionCurrency = "TransactionCurrencyId";
		public const string ConnectionRole = "ConnectionRoleId";
		public const string Queue = "QueueId";
		public const string Workflow = "WorkflowId";
		public const string New_IM = "ActivityId";
		public const string New_CustomAccount = "new_customaccountId";
		public const string New_CustomOpportunity = "new_customopportunityId";
		public const string New_Prospect = "new_ProspectId";
		public const string Competitor = "CompetitorId";
		public const string Contracts = "ContractId";
		public const string Products = "ProductId";
		public const string SalesOrders = "SalesOrderId";
		public const string Invoice = "InvoiceId";
		public const string QuoteDetails = "QuoteDetailId";
		public const string InvoiceDetails = "InvoiceDetailId";
		public const string CampaignActivities = "CampaignactivityId";
		public const string CampaignResponse = "CampaignResponseId";
		public const string UoM = "UoMId";
		public const string SalesOrderDetails = "SalesOrderDetailId";
		public const string Connections = "ConnectionId";
		public const string ProductPriceLevels = "ProductPriceLevelId";
		public const string SLA = "SlaId";
		public const string Resource = "ResourceId";
		public const string OpportunityProduct = "OpportunityProduct";
		public const string HostedApplication = "UII_hostedapplicationId";

		public static string GetByEntityName(string entityName)
		{
			switch (entityName)
			{
				case EntityNames.Accounts:
					return EntityIDNames.Account;
				case EntityNames.Opportunities:
					return EntityIDNames.Opportunities;
				case EntityNames.Contacts:
					return EntityIDNames.Contact;
				case EntityNames.Appointments:
					return EntityIDNames.Appointment;
				case EntityNames.Phonecalls:
					return EntityIDNames.Phonecall;
				case EntityNames.Tasks:
					return EntityIDNames.Task;
				case EntityNames.Emails:
					return EntityIDNames.Email;
				case EntityNames.Leads:
					return EntityIDNames.Lead;
			}

			// TODO: implement the rest
			throw new Exception(string.Format("Entity id attribute name was not defined for {0}.", entityName));
		}
	}

	/// <summary>
	/// List of view names
	/// </summary>
	public static class EntityViewNames
	{
		//activities
		public const string AllActivities = "AllActivitiesView";
		public const string MyActivities = "MyActivitiesView";
		public const string ClosedActivities = "ClosedActivitiesView";
		public const string AllTasks = "AllTasksView";
		public const string MyTasks = "MyTasksView";
		public const string AllApointments = "AllApointmentsView";
		public const string MyAppointments = "MyAppointmentsView";
		public const string MyCompletedAppointments = "MyCompletedAppointmentsView";
		public const string MyLetters = "MyLettersView";
		public const string MyFaxes = "MyFaxesView";
		public const string MyDraftEmails = "MyDraftEmailsView";
		public const string AllRecurringAppointments = "AllRecurringAppointmentsView";
		public const string OpenRecurringAppointments = "OpenRecurringAppointmentsView";
		public const string MyRecurringAppointments = "MyRecurringAppointmentsView";
		public const string ClosedRecurringAppointments = "ClosedRecurringAppointmentsView";
		public const string MyClosedRecurringAppointments = "MyClosedRecurringAppointmentsView";
		public const string ActivityAttachmentAssociated = "ActivityAttachmentAssociatedView";
		public const string AllPhoneCalls = "AllPhoneCallsView";
		public const string MyPhoneCalls = "MyPhoneCallsView";
		public const string AllServiceActivities = "AllServiceActivitiesView";
		public const string MyServiceActivities = "MyServiceActivitiesView";
		public const string AllNewIM = "AllNewIMView";
		public const string MyOpenNewIM = "MyOpenNewIMView";

		//sales entities
		public const string MyActiveAcounts = "MyActiveAccountsView";
		public const string ActiveAcounts = "ActiveAccountsView";
		public const string MyActiveContacts = "MyActiveContactsView";
		public const string ActiveContacts = "ActiveContactsView";
		public const string MyOpenOpportunities = "MyOpenOpportunitiesView";
		public const string ActiveContactsSubgrid = "ActiveContactsSubgridView";
		public const string AccountsNoOrdersInLast6Months = "AccountsNoOrdersInLast6MonthsView";
		public const string AccountsRespondedToCampaingsInLast6Months = "AccountsRespondedToCampaingsInLast6MonthsView";
		public const string AccountsNoCampaignActivitiesInLast3Months = "AccountsNoCampaignActivitiesInLast3MonthsView";
		public const string InActiveAccounts = "InActiveAccountsView";
		public const string MyOpenLeads = "MyOpenLeadsView";

		public const string OpenLeads = "OpenLeadsView";
		public const string ClosedLeads = "ClosedLeadsView";
		public const string LeadsOlderThan6Months = "LeadsOlderThan6MonthsView";
		public const string LeadsWithNoCampaignSent = "LeadsWithNoCampaignSentView";
		public const string NewLeadsLastWeek = "NewLeadsLastWeekView";
		public const string NewLeadsThisWeek = "NewLeadsThisWeekView";
		public const string ContactsNoOrdersinLast6Months = "ContactsNoOrdersinLast6MonthsView";
		public const string ContactsRespondedToCampignsIn6months = "ContactsRespondedToCampignsIn6monthsView";
		public const string ContactsNoCampaignSentInLast3Months = "ContactsNoCampaignSentInLast3MonthsView";
		public const string InActiveContacts = "InActiveContactsView";
		public const string ClosedOpportunities = "ClosedOpportunitiesView";
		public const string OpenOpportunities = "OpenOpportunitiesView";
		public const string OpportunitiesClosingNextMonth = "OpportunitiesClosingNextMonthView";
		public const string OpportunitiesOpenedLastWeek = "OpportunitiesOpenedLastWeekView";
		public const string OpportunitiesOpenedThisWeek = "OpportunitiesOpenedThisWeekView";
		public const string AllStakeholders = "AllStakeholdersView";
		public const string AllCompetitors = "AllCompetitorsView";
		public const string AllSalesTeamMembers = "AllSalesTeamMembersView";
		public const string AllOrderProducts = "AllOrderProductsView";
		public const string AllInvoiceProducts = "AllInvoiceProductsView";
		public const string AllLeads = "AllLeadsView";
		public const string OpportunityProductInlineEditView = "OpportunityProductInlineEditView";
		public const string OpportunityQuotesView = "OpportunityQuotesView";
		public const string SuggestionsGridQuery = "SuggestionsGridQueryView";
		public const string QuoteProductInlineEditView = "QuoteProductInlineEditView";
		public const string AllQuotes = "AllQuotesView";
		public const string OrderProductInlineEdit = "OrderProductInlineEditView";
		public const string MyOrders = "MyOrdersView";
		public const string ContactEntitlements = "ContactEntitlementsView";

		//marketing entities
		public const string ActiveMarketingLists = "ActiveMarketingListsView";
		public const string MyActiveMarketingLists = "MyActiveMarketingListsView";

		public const string CampaignActivities = "CampaignActivitiesView";
		public const string CampaignLeads = "CampaignLeadsView";
		public const string CampaignResponses = "CampaignResponsesView";
		public const string CampaignMarketingLists = "CampaignMarketingListsView";
		public const string AllCampaignResponses = "AllCampaignResponsesView";
		public const string MyCampaignsResponses = "MyCampaignsResponsesView";
		public const string MyCampaigns = "MyCampaignsView";
		public const string OpenCampaignResponses = "OpenCampaignResponsesView";
		public const string ListCampaigns = "ListCampaignsView";
		public const string MyQuickCampaigns = "MyQuickCampaignsView";
		public const string LeadAssociated = "LeadAssociatedView";
		public const string BasicMarketingList = "BasicMarketingListView";
		public const string MyActiveMarketingList = "MyActiveMarketingListView";
		public const string AllCampaignActivities = "AllCampaignActivitiesView";
		public const string LeadListMembers = "LeadListMembersView";
		public const string OpenPlanningActivityAssosiated = "OpenPlanningActivityAssosiatedView";
		public const string ContactListMembers = "ContactListMembersView";
		public const string AccountListMembers = "AccountListMembersView";

		//service entities
		public const string ActiveCases = "ActiveCasesView";
		public const string MyActiveCases = "MyActiveCasesView";
		public const string AllActivitiesforCustomer = "AllActivitiesforCustomerView";
		public const string SimilarResolvedCases = "SimilarResolvedCasesView";

		public const string RecentCasesSubgrid = "RecentCasesSubgridView";
		public const string RecentActivitiesSubgrid = "RecentActivitiesSubgridView";
		public const string CaseAccountSubgrid = "CaseSubgrid3";
		public const string CaseAccountSubgrid2 = "CaseSubgrid4";
		public const string RelatedSolutionsSubGrid = "RelatedSolutionsSubGridView";
		public const string CaseRefreshData1 = "CaseRefreshData1";
		public const string CaseRefreshData2 = "CaseRefreshData2";
		public const string AllCases = "AllCasesView";
		public const string EntitlementSubgrid = "EntitlementSubgridView";
		public const string AccountEntitlements = "AccountEntitlementsView";
		public const string AssosiatedCases = "AssosiatedCasesView";
		public const string AllKBArticles = "AllKBArticlesView";
		public const string SlaKpiInstancesList = "SlaKpiInstancesListView";

		//others
		public const string AllCasesforCustomer = "AllCasesforCustomerView";
		public const string RelatedSolutions = "RelatedSolutionsView";
		public const string UserLookup = "UserLookupView";
		public const string EnabledUsers = "EnabledUsersView";
		public const string MyTeams = "MyTeamsView";
		public const string AccountLookup = "AccountLookupView";
		public const string RecentCases = "RecentCasesView";
		public const string RecentOpportunities = "RecentOpportunitiesView";
		public const string TeamMembers = "TeamMembersView";
		public const string SharePointAssociated = "SharePointDocumentAssociatedView";

	}

	/// <summary>
	/// List of OOB charts names
	/// </summary>
	public static class ChartNames
	{
		public const string SalesPipelineChart = "SalesPipelineChart";
		public const string LeadsbySourceCampaignChart = "LeadsbySourceCampaignChart";
		public const string CasesByPriorityPerDayChart = "CasesByPriorityPerDayChart";
		public const string ResolveCaseSatisfactionChart = "ResolveCaseSatisfactionChart";
		public const string ActivitiesbyOwnerandPriorityChart = "ActivitiesbyOwnerandPriorityChart";
		public const string ServiceLeaderboardChart = "ServiceLeaderboardChart";
		public const string CasesByOriginPerDay = "CasesByOriginPerDay";
		public const string ArticlesByStatusChart = "ArticlesByStatusChart";
		public const string CaseResolutionTrendByDayChart = "CaseResolutionTrendByDayChart";
		public const string ProgressAgainstCountBasedGoalsChart = "ProgressAgainstCountBasedGoalsChart";
		public const string CaseMixbyOriginChart = "CaseMixbyOriginChart";
		public const string CampaignBudgetvsActualCostsByFiscalChart = "CampaignBudgetvsActualCostsByFiscalChart";
		public const string RevenueGeneratedbyCampaignChart = "RevenueGeneratedbyCampaignChart";
		public const string CampaignTypeMixChart = "CampaignTypeMixChart";
		public const string LeadsbySourceChart = "LeadsbySourceChart";
		public const string Top10OpportunitiesChart = "Top10OpportunitiesChart";
		public const string Top10CustomersChart = "Top10CustomersChart";
		public const string PercentageAchievedAgainstGoalsChart = "PercentageAchievedAgainstGoalsChart";
		public const string SalesLeaderboardChart = "SalesLeaderboardChart";
		public const string SalesProgressagainstRevenueGoalsChart = "SalesProgressagainstRevenueGoalsChart";
		public const string DealsWonvsDealsLostByFiscalPeriodChart = "DealsWonvsDealsLostByFiscalPeriodChart";
	}
}

