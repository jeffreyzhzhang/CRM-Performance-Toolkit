using Microsoft.Exchange.WebServices.Data;
//included to clean up registries when we are loading the entitymanager database
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Reflection;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Metadata;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using System.Configuration;
using System.Collections.Concurrent;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Class to manage CRM Entities for perf testing.
	/// </summary>
	public partial class EntityManager
	{
		private static TimeSpan DefaultTimeout = new TimeSpan(0, 59, 0);
		private static System.Threading.Semaphore poolTask = null;

		private static Lazy<EntityManager> m_instance = new Lazy<EntityManager>(() =>
		{
			return new EntityManager();
		});

		private static Lazy<IUserManager> m_userManager = new Lazy<IUserManager>(() => CreateUserManagerInstance(ConfigSettings.Default.EMSQLCNN));

		public static IUserManager GetUserManager()
		{
			return m_userManager.Value;
		}

		// Singleton instance
		public static EntityManager Instance
		{
			get
			{
				return m_instance.Value;
			}
		}

		/// <summary>
		/// Private constructor
		/// </summary>
		private EntityManager()
		{
			Init();
		}

		/// <summary>
		/// Initializes manager by reading app settings from app.config.
		/// Then loads information about all entities from the CRM SQL Server.
		/// It is up to callers to provide thread protection, this function is not multi-thread friendly.
		/// </summary>
		private void Init()
		{
			LoadFromSQL();
		}

		private static Lazy<Dictionary<string, string>> _Context = new Lazy<Dictionary<string, string>>(() => new Dictionary<string, string>());
		public static Dictionary<string, string> Context { get { return _Context.Value; } }

		private static object OwnerLock = new object();

		public const string EntityManagerID = "ID";
		public const string EntityManagerStateCode = "State";
		public const string EntityManagerOutlookStateCode = "OutlookState";
		public const string AppendFilter = "AppendFilter";
		public const string IsDeletableFlag = "deletable";

		//we are changing the BitShift from 46 to 25 to support multi org scenarios
		//we are assuming we are not going to have more than 1000 orgs => 10 bits
		//Remaining bits = 64- 10 = 54. We do shift twice - one for Org owned entities
		//and another for user owned entities

		//In future we are going to have different BitShift value for Org owned entities and
		//user owned entities and these will be read from ConfigSettings.xml so that
		//we will be able to change them run time

		//with Bit shift == 25, each user can have 2^25 = 33,554,432 entities
		private const int BitShift = 25;

		/// <summary>
		/// Connection to SQL Server, used for Init()
		/// </summary>
		//private static SqlConnection m_CRMSQLCon = null;
		private static SqlConnection m_EMSQLCon = null;

		private System.Random m_RanNum = new Random();

		private static Dictionary<Guid, Hashtable> m_Owners = new Dictionary<Guid, Hashtable>();

		private static List<EntityMetadata> m_EntityMatadatas = new List<EntityMetadata>();

		private static List<string> m_UserSubSet;

		private static List<string> m_UserSubSetInValid;

		//we are moving to multiple CRM servers
		//we will read these per crm server
		//server name
		//sql conn
		//user password
		//user base
		//user count

		private static ConcurrentDictionary<string, IOrganizationService> m_userXrmServiceTable;

		private bool m_isUnitTestCase = false;
		public bool IsUnitTestCase
		{
			get
			{
				return m_isUnitTestCase;
			}
			set
			{
				m_isUnitTestCase = value;
			}
		}

		private bool m_isPerUserPerRun = false;
		public bool IsPerUserPerRun
		{
			get
			{
				return m_isPerUserPerRun;
			}
			set
			{
				m_isPerUserPerRun = value;
			}
		}

		private static IOrganizationService adminUserProxy = null;

		public ConcurrentDictionary<string, IOrganizationService> UserXrmServiceTable
		{
			get
			{
				return m_userXrmServiceTable;
			}
		}

		#region Orgization ID
		/// <summary>
		/// Makes life easier to just expose the ORG's GUID.
		/// we are using this in case of multi org scenario too - we set this value
		/// for every org we read to read entities for that org
		/// </summary>
		private static int m_numOrgs = 0;

		//private ArrayList m_OrganizationCount = new ArrayList();
		//private ArrayList m_OrganizationIds = new ArrayList();

		public static List<OrganizationInfo> Organizations = new List<OrganizationInfo>();

		//to suport multiple Orgs, we will assume a fake parent org
		public static Guid m_FakeOrgID = Guid.Empty;
		public Guid OrgId
		{
			get
			{
				//here we going to get a random Org from the list of orgs
				return GetRandomOrg();
			}
		}

		public Guid GetRandomOrg()
		{
			Guid orgId = Guid.Empty;

			try
			{
				EntityRequest orgRequest = new EntityRequest();
				orgRequest.Type = EntityNames.Organizations;
				orgRequest.ReturnAs = EntityNames.Organizations;
				orgRequest.ParentID = Guid.Empty;

				System.Collections.Hashtable entities = EntityManager.Instance.GetEntities(orgRequest);
				CRMEntity organization = (CRMEntity)entities[EntityNames.Organizations];

				orgId = new Guid(organization[EntityIDNames.Organization]);
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
			}
			return orgId;
		}

		public Guid GetRandomExchangeOrg()
		{
			Guid orgId = Guid.Empty;
			SqlConnection sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			SqlCommand sqlcmd;
			SqlDataReader reader;
			try
			{
				string cmd = "select top 1 * from organization where ExchangeMode = 1 ORDER BY NEWID()";
				sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
				sqlconn.Open();
				sqlcmd = new SqlCommand(cmd, sqlconn);
				reader = sqlcmd.ExecuteReader();
				try
				{
					while (reader.Read())
					{
						orgId = new Guid(reader[EntityIDNames.Organization].ToString());
					}
				}
				finally
				{
					reader.Close();
				}

			}
			catch (SqlException sex)
			{
				FileWriter.Instance.WriteToFile(sex.ToString());
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
			}
			finally
			{
				sqlconn.Close();
			}

			return orgId;
		}

		public Guid GetRandomNoneExchangeOrg()
		{
			Guid orgId = Guid.Empty;
			SqlConnection sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			SqlCommand sqlcmd;
			SqlDataReader reader;
			try
			{
				string cmd = @"select top 1 * from organization where ExchangeMode = 0 ORDER BY NEWID()";
				sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
				sqlconn.Open();
				sqlcmd = new SqlCommand(cmd, sqlconn);
				reader = sqlcmd.ExecuteReader();
				try
				{
					while (reader.Read())
					{
						orgId = new Guid(reader[EntityIDNames.Organization].ToString());
					}
				}
				finally
				{
					reader.Close();
				}

			}
			catch (SqlException sex)
			{
				FileWriter.Instance.WriteToFile(sex.ToString());
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
			}
			finally
			{
				sqlconn.Close();
			}

			return orgId;
		}

		public CRMEntity GetRandomUserNoLock(string userRole, Guid orgId, Guid buID, Guid lockedUser)
		{
			CRMEntity user = null;
			SqlConnection sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			SqlCommand sqlcmd = new SqlCommand();
			SqlDataReader reader = null;

			StringBuilder sb = new StringBuilder();
			sb.Append("select top 1 * from SystemUser WITH (NOLOCK) where organizationid = @orgId and systemuserid != @userId");
			sqlcmd.Parameters.AddWithValue("orgId", orgId.ToString());
			sqlcmd.Parameters.AddWithValue("userId", lockedUser.ToString());
			if (userRole != string.Empty)
			{
				sb.Append(" and role=@role");
				sqlcmd.Parameters.AddWithValue("role", userRole);
				if (buID != Guid.Empty)
				{
					sb.Append(" and businessunitid=@buId ");
					sqlcmd.Parameters.AddWithValue("buId", buID);
				}
			}
			sb.Append(" ORDER BY NEWID()");
			sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			try
			{
				sqlconn.Open();
				sqlcmd.CommandText = sb.ToString();
				sqlcmd.Connection = sqlconn;

				DataTable table = null;
				table = new DataTable();
				try
				{
					reader = sqlcmd.ExecuteReader();
					table.Load(reader);
				}
				finally
				{
					if (null != reader)
						reader.Close();
				}

				user = new CRMEntity(table, 0, EntityNames.Users);
			}
			catch (SqlException sex)
			{
				FileWriter.Instance.WriteToFile(sex.ToString());
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
			}
			finally
			{
				sqlconn.Close();
			}

			return user;
		}

		public static Guid GetOwnerGuid(Guid userId, Guid orgId)
		{
			return CommonTypes.EntityReader.GetOwnerGuid(userId, orgId);
		}

		/// <summary>
		/// Temp workaround for UOM data
		/// </summary>
		/// <returns></returns>
		public CRMEntity GetRandomUOM()
		{
			CRMEntity uom = null;

			SqlConnection sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			SqlCommand sqlcmd;
			SqlDataReader reader;
			try
			{
				string cmd = @"select top 1 * from UoM";
				sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
				sqlconn.Open();
				sqlcmd = new SqlCommand(cmd, sqlconn);
				reader = sqlcmd.ExecuteReader();
				DataTable table = new DataTable();
				table.Load(reader);
				int numberOfRows = table.Rows.Count;
				if (numberOfRows <= 0)
				{
					throw new EntityNotFoundException("No rows found for entity UOM");
				}
				else
				{
					uom = new CRMEntity(table, 0, EntityNames.UoM);
				}

			}
			catch (SqlException sex)
			{
				FileWriter.Instance.WriteToFile(sex.ToString());
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
			}
			finally
			{
				sqlconn.Close();
			}
			return uom;
		}

		/// <summary>
		/// Temp workaround for UOM data
		/// </summary>
		/// <returns></returns>
		public CRMEntity GetRandomProduct()
		{
			CRMEntity products = null;

			SqlConnection sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			SqlCommand sqlcmd;
			SqlDataReader reader;
			try
			{
				string cmd = @"select top 1 * from Product";
				sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
				sqlconn.Open();
				sqlcmd = new SqlCommand(cmd, sqlconn);
				reader = sqlcmd.ExecuteReader();
				DataTable table = new DataTable();
				table.Load(reader);
				int numberOfRows = table.Rows.Count;
				if (numberOfRows <= 0)
				{
					throw new EntityNotFoundException("No rows found for entity Product");
				}
				else
				{
					products = new CRMEntity(table, 0, EntityNames.Products);
				}

			}
			catch (SqlException sex)
			{
				FileWriter.Instance.WriteToFile(sex.ToString());
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
			}
			finally
			{
				sqlconn.Close();
			}
			return products;
		}

		public void CleanOutlookSyncRegistry()
		{
			string origKeyPath = "SOFTWARE\\Microsoft";
			//we are going to copy all the registry from this and then replace values for userId etc

			if (Registry.CurrentUser.OpenSubKey(origKeyPath) != null)
			{
				RegistryKey regKey = Registry.CurrentUser.OpenSubKey(origKeyPath);
				string[] valueNames = regKey.GetSubKeyNames();

				for (int i = 0; i < valueNames.Length; i++)
				{
					//we need to see if name has MSCRMClient in it then we need to delete the key
					if (valueNames[i].ToLower().IndexOf("mscrm") == 0)
						Registry.CurrentUser.DeleteSubKey(origKeyPath + "\\" + valueNames[i]);
				}
			}
		}


		#endregion


		public static string GetEntityIDName(string Type)
		{
			switch (Type)
			{
				case EntityNames.Accounts:
					return EntityIDNames.Account;
				case EntityNames.BusinessUnits:
					return EntityIDNames.BusinessUnit;
				case EntityNames.Campaigns:
					return EntityIDNames.Campaign;
				case EntityNames.Contacts:
					return EntityIDNames.Contact;
				case EntityNames.Equipment:
					return EntityIDNames.Equipment;
				case EntityNames.Team:
					return EntityIDNames.Team;
				case EntityNames.SavedQueryVisualizations:
					return EntityIDNames.SavedQueryVisualizationId;
				case EntityNames.SpSite:
					return EntityIDNames.SpSite;
				case EntityNames.SharePointDocumentLocation:
					return EntityIDNames.SharePointDocumentLocation;
				case EntityNames.Incidents:
					return EntityIDNames.Incident;
				case EntityNames.Leads:
					return EntityIDNames.Lead;
				case EntityNames.Lists:
					return EntityIDNames.List;
				case EntityNames.Notes:
					return EntityIDNames.Note;
				case EntityNames.Opportunities:
					return EntityIDNames.Opportunities;
				case EntityNames.Organizations:
					return EntityIDNames.Organization;
				case EntityNames.PriceLevels:
					return EntityIDNames.PriceLevel;
				case EntityNames.Privileges:
					return EntityIDNames.Privilege;
				case EntityNames.Quotes:
					return EntityIDNames.Quote;
				case EntityNames.Roles:
					return EntityIDNames.Role;
				case EntityNames.Service:
					return EntityIDNames.Service;
				case EntityNames.ServiceAppointments:
					return EntityIDNames.ServiceAppointment;
				case EntityNames.RecurringAppointments:
					return EntityIDNames.RecurringAppointmentMaster;
				case EntityNames.Subject:
					return EntityIDNames.Subject;
				case EntityNames.Tasks:
					return EntityIDNames.Task;
				case EntityNames.Templates:
					return EntityIDNames.Template;
				case EntityNames.Users:
					return EntityIDNames.User;
				case EntityNames.Reports:
					return EntityIDNames.Report;
				case EntityNames.TransactionCurrency:
					return EntityIDNames.TransactionCurrency;
				case EntityNames.ConnectionRole:
					return EntityIDNames.ConnectionRole;
				case EntityNames.Queue:
					return EntityIDNames.Queue;
				case EntityNames.Workflow:
					return EntityIDNames.Workflow;
				case EntityNames.Products:
					return EntityIDNames.Products;
				case EntityNames.ProductPriceLevels:
					return EntityIDNames.ProductPriceLevels;
				case EntityNames.New_IM:
					return EntityIDNames.New_IM;
				case EntityNames.New_Prospect:
					return EntityIDNames.New_Prospect;
				default:
					throw new NotImplementedException("Add Type " + Type.ToString());
			}
		}

		private static void TruncateExchangeSyncTables(SqlCommand truncateCommand)
		{
			if (truncateCommand == null)
			{
				truncateCommand = new SqlCommand();
				truncateCommand.Connection = m_EMSQLCon;
			}

			truncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.ExchangeTask;
			truncateCommand.ExecuteNonQuery();

			truncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.ExchangeContact;
			truncateCommand.ExecuteNonQuery();

			truncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.ExchangeAppointment;
			truncateCommand.ExecuteNonQuery();

			truncateCommand.CommandText = "TRUNCATE TABLE ExchangeSyncSettings";
			truncateCommand.ExecuteNonQuery();
		}

		/// <summary>
		/// Truncate the SQL tables for a new set of data.
		/// </summary>
		private static void TruncateTables()
		{
			SqlCommand TruncateCommand = new SqlCommand();

			TruncateCommand.Connection = m_EMSQLCon;
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Accounts;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.BusinessUnits;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Campaigns;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Contacts;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Equipment;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Team;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.SavedQueryVisualizations;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.SpSite;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.SharePointDocumentLocation;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.GenericActivities;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Incidents;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Leads;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Lists;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Notes;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Opportunities;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Organizations;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.PriceLevels;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Privileges;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Queue;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Quotes;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Reports;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Roles;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Service;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.ServiceAppointments;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Subject;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Tasks;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.TransactionCurrency;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Appointments;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.RecurringAppointments;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Emails;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Letters;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Faxes;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Goals;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Phonecalls;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.ConnectionRole;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Templates;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Users;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Solution;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Workflow;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.New_IM;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.New_Prospect;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + "FakeParentOrg";
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Competitor;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Products;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.ProductPriceLevels;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.Resource;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.SalesOrders;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE SetupUser";
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.New_CustomAccount;
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE " + EntityNames.New_CustomOpportunity;
			TruncateCommand.ExecuteNonQuery();
			//Temp tables in EMDB side will be truncated.
			TruncateCommand.CommandText = "TRUNCATE TABLE tempSystemUserRole";
			TruncateCommand.ExecuteNonQuery();
			TruncateCommand.CommandText = "TRUNCATE TABLE tempUserRole";
			TruncateCommand.ExecuteNonQuery();
		}

		/// <summary>
		/// EMDB is loaded already. Load the data from EMDB into memory
		/// </summary>
		private void LoadFromSQL()
		{
			// Try block to wrap SQL access to ensure connection is closed. No Exception handling.
			try
			{
				if (ConfigSettings.Default.m_MulServers == null || ConfigSettings.Default.m_MulServers.Length == 0)
				{
					throw new Exception("No server configurations found");
				}
				// Load the entities into memory from the EM DB
				Trace.WriteLine("Connecting to EntityManager SQL: " + ConfigSettings.Default.EMSQLCNN);
				m_EMSQLCon = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
				m_EMSQLCon.Open();
				Trace.WriteLine("Connected to Entity Manager SQL Database");
				BuildFromSQL();

			}
			catch (Exception ex)
			{
				string msg = string.Format("Failure in loading EMDB from SQL. Error msg: {0}", ex.Message);
				Trace.WriteLine(msg);
				throw new Exception(msg, ex);
			}
		}

		/// <summary>
		/// Load data from CRM DB to EMDB
		/// </summary>
		public static void LoadFromCRM()
		{
			// Try block to wrap SQL access to ensure connection is closed. No Exception handling.
			try
			{
				if (ConfigSettings.Default.m_MulServers == null || ConfigSettings.Default.m_MulServers.Length == 0)
				{
					throw new Exception("No server configurations found");
				}
				CheckEMDB();
				if (ConfigSettings.Default.OutlookSyncDir != string.Empty)
				{
					Directory.CreateDirectory(ConfigSettings.Default.OutlookSyncDir + "\\SyncToOutlook");
					Directory.CreateDirectory(ConfigSettings.Default.OutlookSyncDir + "\\ManagedABPSYnc");
					Directory.CreateDirectory(ConfigSettings.Default.OutlookSyncDir + "\\GoOffline");
				}
				RefreshEmDbFromCrmDbs();
			}
			catch (Exception ex)
			{
				string msg = string.Format("Failure in loading EMDB from CRM. Error msg: {0}", ex.Message);
				Trace.WriteLine(msg);
				throw new Exception(msg, ex);
			}
		}

		public static void RefreshEmDbFromCrmDbs(string buildNumber = null)
		{
			// Reset the owners
			m_Owners.Clear();

			//we have to read how many crm servers we are reading from
			Trace.WriteLine("Connecting to EntityManager SQL: " + ConfigSettings.Default.EMSQLCNN);
			m_EMSQLCon = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			m_EMSQLCon.Open();
			Trace.WriteLine("Connected to Entity Manager SQL Database");

			TruncateTables();

			PopulateFakeParentOrg();

			m_userXrmServiceTable = new ConcurrentDictionary<string, IOrganizationService>();

			m_numOrgs = ConfigSettings.Default.m_MulServers.Length;

			foreach (var serverInfo in ConfigSettings.Default.m_MulServers)
			{
				adminUserProxy = GetAdminUserProxy(serverInfo);
				ReadAllEntitesFromCrmDBIntoEmDB(serverInfo);
			}

		}

		public static void RefreshAllAuthTokens()
		{
			var userManager = GetUserManager();

			for (int i = 0; i < ConfigSettings.Default.m_MulServers.Length; i++)
			{
				string start = ConfigSettings.Default.m_MulServers[i].userStart;
				string count = ConfigSettings.Default.m_MulServers[i].userCount;
				string userBase = ConfigSettings.Default.m_MulServers[i].userBase;
				string domain = ConfigSettings.Default.m_MulServers[i].userDomain;
				string password = ConfigSettings.Default.m_MulServers[i].userPassword;
				string orgName = ConfigSettings.Default.m_MulServers[i].OrgName;
				string orgBaseUrl = ConfigSettings.Default.m_MulServers[i].OrganizationBaseUrl;

				userManager.RefreshAllAuthTokens(start, count, userBase, domain, password, orgName, orgBaseUrl);
			}
		}


		/// <summary>
		/// Load CRM Data into EM Database
		/// </summary>
		/// <param name="serverData"></param>
		private static void ReadAllEntitesFromCrmDBIntoEmDB(MultipleServersData serverData)
		{
			Trace.WriteLine("Connected to CRM SQL Database");
			Guid orgID = UpdateCurrentOrgIdFromCrmDb();
			ReadOrgs(serverData, orgID);
			ReadSetupUser(serverData, orgID);
			ReadUsers(serverData, orgID);
			ReadUserSettings();
			ReadSystemUserRoles();
			ReadOutlookUsers(orgID);
			ResetOutlookStateCode(EntityNames.Users);
			bool skipEntities = EntityManager.Context.ContainsKey("SkipEntities") && string.CompareOrdinal(EntityManager.Context["SkipEntities"], "1") == 0;
			if (!skipEntities)
			{
				//Start reading Entities.
				//This is for rollups perf testing. Added in try-catch block as per existing pattern so that it doesnt break if the system is not customized
				//Disable data loading for Hiearchy/Rollup for OOB deployment
				Trace.WriteLine("########## If your system doesn't have test data for Hierarchy/Rollup pre-populated, you can ignore the loading errors for New_CustomAccounts, New_CustomOpportunities and UII_hostedapplication ##########");
				try
				{
					ReadNew_CustomAccounts(orgID);
					ReadNew_CustomOpportunities(orgID);
				}
				catch (Exception)
				{
					Trace.WriteLine("Failed to read custom account. Skipping...");
				}

				try
				{
					ReadUII_hostedapplication(orgID);
				}
				catch (Exception)
				{
					Trace.WriteLine("Failed to read UII_hostedapplication. Skipping...");
				}
				
				//Retrive user subset to filter entity based on ownerid
				RetriveUserSubset(serverData);

				ReadBUs(orgID);

				List<System.Threading.Tasks.Task> tasks = new List<System.Threading.Tasks.Task>();

				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadCompetitors));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadLeads));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadOpportunities));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadAccounts));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadContacts));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadAppointments));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadEmails));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadFaxes));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadGoals));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadLetters));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadPhonecalls));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadTasks));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadSubjects));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadServices));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadQuotes));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadRoles));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadIncidents));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadNotes));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadCampaigns));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadPriceLevels));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadLists));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadServiceAppointments));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadRecurringAppointments));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadPrivileges));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadEquipment));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadTeams));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadSavedQueryVisualizations));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadSpSite));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadSharePointDocumentLocation));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadReports));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadTransactionCurrencies));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadConnectionRoles));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadQueues));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadWorkflows));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadSolutions));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadProducts));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadProductPriceLevels));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadSalesOrders));
				tasks.Add(ParallelExecutionMode(serverData, orgID, ReadResource));

				var appSettings = ConfigurationManager.AppSettings;
				int maximumParallelism = Int32.Parse(appSettings["MaximumParallelism"] ?? "1");

				if (maximumParallelism < 1)
				{
					maximumParallelism = 1;
				}

				poolTask = new System.Threading.Semaphore(maximumParallelism, maximumParallelism);
				foreach (System.Threading.Tasks.Task task in tasks)
				{
					poolTask.WaitOne();
					task.Start();
				}

				try
				{
					System.Threading.Tasks.Task.WaitAll(tasks.ToArray(), -1);
				}
				catch (AggregateException agex)
				{
					Trace.WriteLine("Some aggregate exception is caught");
					foreach (var e in agex.InnerExceptions)
					{
						Trace.WriteLine("Printing agex.InnerException");
						Trace.WriteLine(e.Message);
						Trace.WriteLine(e.StackTrace);
						Trace.WriteLine(e.InnerException.Message);
						Trace.WriteLine(e.InnerException.StackTrace);
					}
					throw;
				}
				catch (Exception e)
				{
					Trace.WriteLine("Some other exception is caught");
					Trace.WriteLine(e.Message);
					Trace.WriteLine(e.StackTrace);
					Trace.WriteLine(e.InnerException.Message);
					Trace.WriteLine(e.InnerException.StackTrace);
					throw;
				}

				// Reading custom entity and activity. Might throw exception if system is not customized
				try
				{
					ReadNew_IMs(orgID);
				}
				catch (Exception)
				{
					Trace.WriteLine("Failed to read custom activity. Skipping...");
				}

				// Reading custom entity and activity. Might throw exception if system is not customized
				try
				{
					ReadNew_Prospects(orgID);
				}
				catch (Exception)
				{
					Trace.WriteLine("Failed to read custom entity. Skipping...");
				}
			}
		}

		private static System.Threading.Tasks.Task ParallelExecutionMode(MultipleServersData serverData, Guid organizationId, SyncCRMDataDelegate syncMethod)
		{
			System.Threading.Tasks.Task t1 = new System.Threading.Tasks.Task(() => syncMethod(serverData, organizationId));
			t1.ContinueWith(((System.Threading.Tasks.Task t) => OnTaskComplete(t)));
			return t1;
		}

		private static void OnTaskComplete(System.Threading.Tasks.Task t)
		{
			poolTask.Release();
		}
		/// <summary>
		/// help methond to check if EMDB exists on the client
		/// If EMDB exists, do nothing. Otherwise create EMDB on the client
		/// </summary>
		private static void CheckEMDB()
		{
			//check if EMDB exists, if not, create one
			string emdbName = "";
			using (SqlCommand emdbCheck = new SqlCommand("SELECT name FROM master.dbo.sysdatabases WHERE name = @name"))
			{
				emdbCheck.Parameters.AddWithValue("name", "EntityManager");
				using (var sqlConn = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
				{
					sqlConn.Open();
					emdbCheck.Connection = sqlConn;

					using (var emdbCheckReader = emdbCheck.ExecuteReader())
					{
						while (emdbCheckReader.Read())
						{
							emdbName = emdbCheckReader["name"].ToString();
						}
					}
				}
			}

			//Create EMDB
			if (string.IsNullOrEmpty(emdbName))
			{
				string argument = string.Format(@" -S . -i ""{0}"" ", Path.Combine(ConfigSettings.Default.CRMToolkitRoot, @"Binaries\Scripts\SQL\EMDB_Setup.sql"));
				var process = Process.Start("sqlcmd.exe", argument);
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.CreateNoWindow = false;
				try
				{
					process.Start();
					while (true)
					{
						if (process.HasExited)
						{
							break;
						}
						System.Threading.Thread.Sleep(500);
					}
					if (process.ExitCode != 0)
					{
						throw new Exception("Create EMDB failed; Please setup EMDB manually and try to run the test again");
					}
				}
				catch (Exception ex)
				{
					Trace.WriteLine("Failed to create EMDB.");
					Trace.WriteLine("Exception Message: {0}", ex.Message);
					throw ex;
				}
			}
		}

		private static void BuildFromSQL()
		{
			// Load all the Organizations
			ResetStateCode("organization");
			LoadAllOrganizations();
			m_userXrmServiceTable = new ConcurrentDictionary<string, IOrganizationService>();

			// Load all the users
			LoadAllUsers();
			BuildEntityFromSQL(EntityNames.Users, "OrganizationID");
			ResetOutlookStateCode(EntityNames.Users);
			BuildEntityFromSQL(EntityNames.Leads, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Accounts, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Contacts, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Opportunities, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Service, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Subject, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Tasks, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Appointments, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Emails, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Faxes, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Goals, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Letters, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Phonecalls, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Quotes, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Templates, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Incidents, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Notes, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.PriceLevels, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Lists, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.BusinessUnits, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Campaigns, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.ServiceAppointments, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.RecurringAppointments, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Roles, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Privileges, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Team, "OrganizationID");
			BuildEntityFromSQL(EntityNames.SavedQueryVisualizations, "OrganizationID");
			BuildEntityFromSQL(EntityNames.SpSite, "OrganizationID");
			BuildEntityFromSQL(EntityNames.SharePointDocumentLocation, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Equipment, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Reports, "OrganizationID");
			BuildEntityFromSQL(EntityNames.TransactionCurrency, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Competitor, "OrganizationID");
			BuildEntityFromSQL(EntityNames.ConnectionRole, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Queue, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Solution, "OrganizationID");
			BuildEntityFromSQL(EntityNames.Workflow, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.New_IM, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.New_Prospect, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Products, "OrganizationID");
			BuildEntityFromSQL(EntityNames.ProductPriceLevels, "OrganizationID");
			BuildEntityFromSQL(EntityNames.ExchangeTask, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.ExchangeContact, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.ExchangeAppointment, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.SocialInsightsConfiguration, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.Resource, "OrganizationID");
			BuildEntityFromSQL(EntityNames.SalesOrders, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.New_CustomAccount, "EntityManagerOwningUser");
			BuildEntityFromSQL(EntityNames.New_CustomOpportunity, "EntityManagerOwningUser");
		}

		private static void ResetStateCode(string EntityName)
		{
			int rowCnt = 0;
			using (SqlConnection emsqlCon = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
			{
				emsqlCon.Open();
				string cmdText = string.Format("UPDATE {0} SET {1}=@state WHERE {2}=@stateCode", EntityName, EntityManagerStateCode, EntityManagerStateCode);
				using (SqlCommand cmd = new SqlCommand(cmdText, emsqlCon))
				{
					cmd.Parameters.AddWithValue("state", (int) EntityStates.Free);
					cmd.Parameters.AddWithValue("stateCode", (int) EntityStates.InUse);
					rowCnt = cmd.ExecuteNonQuery();
				}
			}
		}

		private static void ResetOutlookStateCode(string EntityName)
		{
			int rowCnt = 0;

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			cmd.Connection.Open();
			cmd.CommandText = "UPDATE " + EntityName + " SET " + EntityManagerOutlookStateCode + "=" + (int)EntityStates.Free;
			cmd.CommandText += " WHERE " + EntityManagerOutlookStateCode + "=" + (int)EntityStates.InUse;
			try
			{
				rowCnt = cmd.ExecuteNonQuery();
			}
			catch (Exception e)
			{
				Trace.WriteLine(e.ToString());
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		private static void BuildEntityFromSQL(string EntityName, string KeyName)
		{
			Trace.WriteLine("Building memory tables for entity: " + EntityName);

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = m_EMSQLCon;
			cmd.CommandTimeout = 0;

			cmd.CommandText = "SELECT count(*) as Count, " + KeyName + " FROM " + EntityName + " GROUP BY " + KeyName;
			SqlDataReader reader = cmd.ExecuteReader();

			ulong totalRecords = 0;
			try
			{
				while (reader.Read())
				{
					var key = reader[KeyName].ToString();
					Hashtable Owner = m_Owners[new Guid(key)];

					System.Int64 numRead = System.Int64.Parse(reader["Count"].ToString());

					totalRecords += (UInt64)numRead;

					Owner.Add(EntityName, numRead);
				}
			}
			finally
			{
				reader.Close();
			}

			Trace.WriteLine(string.Format("\tTotal: {0}", totalRecords));

			ResetStateCode(EntityName);
		}

		public void UpdateEntity(ref CRMEntity Entity, string EntityName, Guid Owner, string[] PropNames, string[] PropValues, string EntityIdName, string EntityId)
		{
			for (int i = 0; i < PropNames.Length; i++)
			{
				Entity[PropNames[i]] = PropValues[i];
			}

			System.Int64 NextID = System.Int64.Parse("0");

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			cmd.Connection.Open();
			try
			{
				cmd.CommandText = "UPDATE " + EntityName + " set ";

				// Check if the entity["OwnerId"] is different from the new owner
				// if so create a new EntityManagerID for the entity row in the DB and
				// point the new owner to this new entity row through the new ID
				if (Entity["EntityManagerOwningUser"] != Owner.ToString())
				{
					// Need the ID value.
					//The owner should exist.
					lock (OwnerLock)
					{
						Hashtable OwnersEntities = m_Owners[Owner];

						if (false == OwnersEntities.ContainsKey(EntityName))
							OwnersEntities.Add(EntityName, System.Int64.Parse("0"));

						System.Int64 BaseVal = System.Int64.Parse(OwnersEntities[EntityManagerID].ToString());
						System.Int64 BaseVal2 = BaseVal << BitShift;

						NextID = (System.Int64)OwnersEntities[EntityName];
						NextID++;
						if (System.Int64.MaxValue == NextID)
							throw new Exception("Attempt to use reserved const of Int64.MaxValue");

						OwnersEntities[EntityName] = NextID;
						System.Int64 NextID2 = BaseVal + NextID;
						cmd.CommandText += "ID = '" + NextID2 + "',";
					}
				}

				for (int i = 0; i < PropNames.Length; i++)
				{
					cmd.CommandText += PropNames[i] + "=";
					cmd.CommandText += "'" + PropValues[i] + "',";
				}
				cmd.CommandText = cmd.CommandText.Remove(cmd.CommandText.Length - 1);

				//cmd.CommandText += " where " + EntityIdName + "='" + EntityId + "'";

				//in mutli server system, we can have same entity ids, so we
				//are going to update on ID
				cmd.CommandText += " where " + EntityManagerID + "='" + Entity[EntityManagerID] + "'";
				if (cmd.Connection.State == System.Data.ConnectionState.Closed)
				{
					Trace.WriteLine("Reopen closed m_EMSQLCon connection");
					cmd.Connection.Open();
				}

				cmd.ExecuteNonQuery();
				//
				// If the update succeeded then we will be in this code path
				// If the NextID is not null, it means the Entity has a new owner
				// then we need to update the EntityManagerID to the new ID.
				//
				if (NextID != System.Int64.Parse("0"))
				{
					Entity[EntityManagerID] = NextID.ToString();
				}
			}
			catch (Exception ex)
			{
				throw new Exception("EMDB UpdateEntity Failure: " + ex.ToString());
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		//        /// <summary>
		//        /// Adds a new entity to the EntityLists
		//        /// </summary>
		//        /// <param name="EntityName">Entity type name</param>
		//        /// <param name="PropNames"></param>
		//        /// <param name="PropValues"></param>
		public void AddEntity(string EntityName, Guid Owner, string[] PropNames, string[] PropValues)
		{
			System.Int64 BaseVal = System.Int64.Parse("0");
			System.Int64 NextID = System.Int64.Parse("0");
			System.Int64 BaseVal2 = System.Int64.Parse("0");
			System.Int64 NextID2 = System.Int64.Parse("0");

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = new SqlConnection(m_EMSQLCon.ConnectionString);
			cmd.Connection.Open();
			try
			{
				cmd.CommandText = "INSERT INTO " + EntityName + " (ID,";

				foreach (string Prop in PropNames)
					cmd.CommandText += Prop + ",";

				cmd.CommandText = cmd.CommandText.Remove(cmd.CommandText.Length - 1);

				cmd.CommandText += ") VALUES(";

				// Need the ID value.
				//The owner should exist.
				lock (OwnerLock)
				{
					Hashtable OwnersEntities = m_Owners[Owner];

					if (false == OwnersEntities.ContainsKey(EntityName))
						OwnersEntities.Add(EntityName, System.Int64.Parse("0"));

					BaseVal = System.Int64.Parse(OwnersEntities[EntityManagerID].ToString());
					BaseVal2 = BaseVal << BitShift;

					NextID = (System.Int64)OwnersEntities[EntityName];
					NextID++;
					if (System.Int64.MaxValue == NextID)
						throw new Exception("Attempt to use reserved const of Int64.MaxValue");

					OwnersEntities[EntityName] = NextID;
					NextID2 = BaseVal2 + NextID;
					cmd.CommandText += "@nextId2, ";
					cmd.Parameters.AddWithValue("nextId2", NextID2);
				}

				var index = 0;
				foreach (string prop in PropValues)
				{
					var paramName = string.Format("param{0}", index++);
					cmd.CommandText += string.Format("@{0}, ", paramName);
					cmd.Parameters.AddWithValue(paramName, prop);
				}
				cmd.CommandText = cmd.CommandText.TrimEnd();
				cmd.CommandText = cmd.CommandText.Remove(cmd.CommandText.Length - 1);

				cmd.CommandText += ")";

				if (cmd.Connection.State == System.Data.ConnectionState.Closed)
				{
					Trace.WriteLine("Reopen closed m_EMSQLCon connection");
					cmd.Connection.Open();
				}

				if (1 != cmd.ExecuteNonQuery())
					throw new Exception("Failed to insert new entity into table: " + cmd.CommandText);
			}
			catch (Exception ex)
			{
				throw new Exception("EMDB AddEntity Failure: " + ex.ToString());
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		public void AddEntityWithoutId(string EntityName, Guid Owner, string[] PropNames, string[] PropValues)
		{
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = new SqlConnection(m_EMSQLCon.ConnectionString);
			cmd.Connection.Open();
			try
			{
				cmd.CommandText = "INSERT INTO " + EntityName + " (";

				foreach (string Prop in PropNames)
					cmd.CommandText += Prop + ",";

				cmd.CommandText = cmd.CommandText.Remove(cmd.CommandText.Length - 1);

				cmd.CommandText += ") VALUES(";

				// Need the ID value.
				//The owner should exist.
				lock (OwnerLock)
				{
					Hashtable OwnersEntities = m_Owners[Owner];

					if (false == OwnersEntities.ContainsKey(EntityName))
						OwnersEntities.Add(EntityName, System.Int64.Parse("0"));
				}

				var index = 0;
				foreach (string prop in PropValues)
				{
					var paramName = string.Format("param{0}", index++);
					cmd.CommandText += string.Format("@{0}, ", paramName);
					cmd.Parameters.AddWithValue(paramName, prop);
				}
				cmd.CommandText = cmd.CommandText.TrimEnd();
				cmd.CommandText = cmd.CommandText.Remove(cmd.CommandText.Length - 1);

				cmd.CommandText += ")";

				if (cmd.Connection.State == System.Data.ConnectionState.Closed)
				{
					Trace.WriteLine("Reopen closed m_EMSQLCon connection");
					cmd.Connection.Open();
				}

				if (1 != cmd.ExecuteNonQuery())
					throw new Exception("Failed to insert new entity into table: " + cmd.CommandText);
			}
			catch (Exception ex)
			{
				throw new Exception("EMDB AddEntity Failure: " + ex.ToString());
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		#region Entity Loading


		//refresh exchange setting for online
		public static void RefreshExchange()
		{
			using (m_EMSQLCon = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
			{
				m_EMSQLCon.Open();

				TruncateExchangeSyncTables(null);

				SqlCommand cmd = new SqlCommand();
				cmd.Connection = m_EMSQLCon;
				cmd.CommandText = "SELECT " + EntityIDNames.Organization + " as OwnerID," + EntityManagerID + " , ServerBaseUrl FROM " + EntityNames.Organizations;

				SqlDataReader reader = cmd.ExecuteReader();

				try
				{
					while (reader.Read())
					{
						//Build the owners table.
						Hashtable Owner = new Hashtable();

						System.Int64 ID = System.Int64.Parse(reader[1].ToString());
						Owner.Add(EntityManagerID, ID);
						if (m_Owners.ContainsKey(reader.GetGuid(0)))
							continue;

						m_Owners.Add(reader.GetGuid(0), Owner);

						m_numOrgs++;
					}
				}
				finally
				{
					reader.Close();
				}
			}


			for (int i = 0; i < m_numOrgs; i++)
			{

				try
				{
					MultipleServersData serverData = ConfigSettings.Default.m_MulServers[i];

					adminUserProxy = GetAdminUserProxy(serverData);
					Guid orgID = UpdateCurrentOrgIdFromCrmDb();
					//refresh exchange
					using (SqlConnection emdbSqlConn = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
					{
						emdbSqlConn.Open();
						ReadExchangeSyncSettings(orgID, emdbSqlConn);
						ReadExchangeData(orgID, emdbSqlConn);
					}

				}
				catch (Exception e)
				{
					Trace.WriteLine(e.ToString());
				}

			}
		}

		private static void PopulateFakeParentOrg()
		{
			Guid fakeguid = new Guid("19007b7e-d9a3-da11-b5fc-001143d30bf2");

			string SqlCommand = "Insert into FakeParentOrg (ID,OrganizationId) Values (0, @fakeguid)";
			SqlCommand getOrg = new SqlCommand(SqlCommand, m_EMSQLCon);
			getOrg.Parameters.AddWithValue("fakeguid", fakeguid);
			getOrg.ExecuteNonQuery();

			Hashtable orgOwner = new Hashtable();

			orgOwner.Add(EntityManagerID, (System.Int64)0);

			//Need to enter the org as a owner in our global table.
			SqlCommand = "SELECT  Top 1 " + EntityIDNames.Organization + " FROM FakeParentOrg";
			getOrg = new SqlCommand(SqlCommand, m_EMSQLCon);
			SqlDataReader reader = getOrg.ExecuteReader();
			try
			{
				while (reader.Read())
				{

					//if (false == reader.Read())
					//    throw new Exception("Failed to read any rows while searching for the org.");

					m_Owners.Add(reader.GetGuid(0), orgOwner);
					m_FakeOrgID = reader.GetGuid(0);
				}
			}
			finally
			{
				reader.Close();
			}
		}

		private static void LoadAllOrganizations()
		{
			// Load all the Organizations
			//to support multi server scenario, we are going to read crmServer name also from Org as well as user table
			//Read from the EM DB and setup the memory structures we need to run the test cases.
			string cmdText = string.Format("SELECT [{0}], [OrganizationId], [ServerBaseUrl], [FeatureSet], [ExchangeMode], [{1}] FROM {2}", EntityManagerID, EntityManagerStateCode, EntityNames.Organizations);
			using (SqlCommand cmd = new SqlCommand(cmdText, m_EMSQLCon))
			{
				using (SqlDataReader reader = cmd.ExecuteReader())
				{
					while (reader.Read())
					{
						//Build the owners table.
						Hashtable Owner = new Hashtable();
						System.Int64 ID = System.Int64.Parse(reader[0].ToString());
						var orgInfo = new OrganizationInfo
						{
							OrganizationId = reader.GetGuid(1),
							ServerBaseUrl = reader.GetString(2),
							FeatureSet = reader.GetString(3),
							ExchangeMode = reader.GetBoolean(4),
							State = (EntityStates)reader.GetInt32(5)
						};
						// Return the first matching server
						orgInfo.ServerInfo = ConfigSettings.Default.m_MulServers.Where(s =>
						string.Compare(s.ServerBaseUrl, orgInfo.ServerBaseUrl, StringComparison.OrdinalIgnoreCase) == 0).FirstOrDefault();

						// Store the organizations
						Organizations.Add(orgInfo);
						Owner.Add(EntityManagerID, ID);
						if (m_Owners.ContainsKey(orgInfo.OrganizationId))
							continue;

						m_Owners.Add(orgInfo.OrganizationId, Owner);
						m_numOrgs++;
					}
				}
			}
		}

		private static void LoadAllUsers()
		{
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = m_EMSQLCon;
			cmd.CommandText = "SELECT " + EntityIDNames.User + " as OwnerID ," + EntityIDNames.Organization + " as OrgID," + EntityManagerID + " FROM " + EntityNames.Users;

			SqlDataReader reader = cmd.ExecuteReader();

			try
			{
				while (reader.Read())
				{
					//Build the owners table.
					Hashtable Owner = new Hashtable();
					Guid g = GetOwnerGuid(reader.GetGuid(0), reader.GetGuid(1));
					if (m_Owners.ContainsKey(g))
						continue;
					System.Int64 ID = System.Int64.Parse(reader[2].ToString());
					Owner.Add(EntityManagerID, ID);

					m_Owners.Add(g, Owner);
				}
			}
			finally
			{
				reader.Close();
			}
		}

		private static Guid UpdateCurrentOrgIdFromCrmDb()
		{
			try
			{
				EntityCollection results = null;
				bool getmorerows = true;

				QueryExpression query = new QueryExpression("organization");
				query.PageInfo.Count = 5000;
				query.PageInfo.PageNumber = 1;
				query.ColumnSet.AllColumns = true;

				while (getmorerows)
				{
					results = adminUserProxy.RetrieveMultiple(query);
					query.PageInfo.PageNumber++;
					query.PageInfo.PagingCookie = results.PagingCookie;
					getmorerows = results.MoreRecords;

					for (int k = 0; k < results.Entities.Count; k++)
					{
						Entity en = results[k];
						if (en.Attributes.Contains("organizationid"))
						{
							return (Guid)en.Attributes["organizationid"];
						}
					}
				}
			}
			catch (System.Exception e)
			{
				Trace.WriteLine("Exception:\n" + e.ToString());
				throw;
			}
			return Guid.Empty;
		}
		#endregion

		private static IOrganizationService GetAdminUserProxy(MultipleServersData serverData)
		{
			IOrganizationService retService = XrmServiceCreator.CreateOrganizationService(serverData.OrganizationServiceUrl,
					ConfigSettings.Default.RunAsUser,
					ConfigSettings.Default.RunAsPassword,
					DefaultTimeout);
			int maxTry = 0;
			while (retService == null && maxTry < 20)
			{
				retService = XrmServiceCreator.CreateOrganizationService(serverData.OrganizationServiceUrl,
					ConfigSettings.Default.RunAsUser,
					ConfigSettings.Default.RunAsPassword,
					DefaultTimeout);
				maxTry++;
			}


			return retService;
		}

		private static void RetriveUserSubset(MultipleServersData serverData)
		{
			m_UserSubSet = new List<string>();
			m_UserSubSetInValid = new List<string>();

			QueryExpression query;
			EntityCollection results = null;

			try
			{
				query = new QueryExpression();
				query.EntityName = "systemuser";

				query.ColumnSet.AddColumns("setupuser", "isdisabled", "systemuserid");
				bool getmorerows = true;
				query.PageInfo.Count = 5000;
				query.PageInfo.PageNumber = 1;
				var userFilter = GetUserFilter(serverData);
				query.Criteria.AddFilter(userFilter);
				while (getmorerows)
				{
					results = adminUserProxy.RetrieveMultiple(query);
					query.PageInfo.PageNumber++;
					query.PageInfo.PagingCookie = results.PagingCookie;
					getmorerows = results.MoreRecords;

					for (int k = 0; k < results.Entities.Count; k++)
					{
						Entity en = results[k];
						bool isSetupUser = (bool)en.Attributes["setupuser"];
						bool isDisabled = (bool)en.Attributes["isdisabled"];
						if (isSetupUser || !isDisabled)
						{
							m_UserSubSet.Add(en.Attributes["systemuserid"].ToString());
						}
						else
						{
							m_UserSubSetInValid.Add(en.Attributes["systemuserid"].ToString());
						}
					}
				}
			}
			catch (System.Exception e)
			{
				Trace.WriteLine("Exception:\n" + e.ToString());
				throw;
			}
		}


		private static FilterExpression CreateQueryForUserSubsetChunk(FilterExpression where, Guid[] users)
		{
			if (where == null)
			{
				where = new FilterExpression();
			}

			where.Conditions.Add(new ConditionExpression("ownerid", ConditionOperator.In, users));
			return where;
		}

		private static FilterExpression CreateQueryForUserSubset(FilterExpression where)
		{
			if (where == null)
			{
				where = new FilterExpression();
			}

			return where;
		}

		public IOrganizationService GetTestUserProxy(CRMEntity user)
		{
			string userName = user["domainname"];
			string password = user["userpassword"];
			string organization = user["organizationname"];
			string organizationServiceUrl = user["organizationserviceurl"];
			IOrganizationService proxy;

			string key = string.Format("{0}_{1}", organization, userName);
			if (this.UserXrmServiceTable.ContainsKey(key))
			{
				proxy = this.UserXrmServiceTable[key];
			}
			else
			{
				proxy = XrmServiceCreator.CreateOrganizationService(organizationServiceUrl, userName, password);
				if (null != proxy)
				{
					try
					{
						this.UserXrmServiceTable[key] = proxy;
					}
					catch (Exception e)
					{
						throw e;
					}
				}
			}

			if (null == proxy)
			{
				string msg = string.Format("The OrganizationService of key {0} is NULL", key);
				FileWriter.Instance.WriteToFile(msg);
				throw new NullReferenceException(msg);
			}


			return proxy;
		}

		private static FilterExpression CreateQueryForCustomAccount(int level, bool isDeletable)
		{
			FilterExpression where = new FilterExpression();
			where.AddCondition("new_level", ConditionOperator.Equal, level);
			if (isDeletable)
				where.AddCondition("new_name", ConditionOperator.Like, "%" + IsDeletableFlag + "%");
			return where;
		}


		public static ExchangeService GetService(Guid userId, string emailAddress, string password)
		{
			string select = "Select OutgoingServerLocation,UseAutoDiscover FROM ExchangeSyncSettings WHERE SystemUserId=@userId";
			ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2010_SP2);
			service.Credentials = new WebCredentials(emailAddress, password);
			using (SqlConnection connection = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
			{
				connection.Open();
				using (SqlCommand users = new SqlCommand(select, connection))
				{
					users.Parameters.AddWithValue("userId", userId.ToString());
					using (SqlDataReader reader = users.ExecuteReader())
					{
						if (reader.Read())
						{
							string serverLocation = reader["OutgoingServerLocation"].ToString();
							bool autoDiscover = (bool)reader["UseAutoDiscover"];
							if (autoDiscover)
							{
								service.AutodiscoverUrl(emailAddress);
							}
							else
							{
								service.Url = new Uri(serverLocation);
							}
						}
					}
				}
			}
			return service;
		}

		#region Fetch / Checkout


		//        /// <summary>
		//        /// Gets the next user not marked as busy
		//        /// </summary>
		//        /// <returns>CRMEntity object for the user</returns>
		public CRMEntity GetNextUser()
		{
			return GetNextUser(new Hashtable());
		}
		public CRMEntity GetNextUser(Guid Org)
		{
			return GetNextUser(new Hashtable(), Org);
		}

		public CRMEntity[] GetRandomUserRecipients(string userRole, Guid orgId)
		{
			CRMEntity[] userRecipients = new CRMEntity[3];
			SqlConnection sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			SqlCommand sqlcmd = new SqlCommand();
			SqlDataReader reader;

			try
			{
				StringBuilder sb = new StringBuilder();
				sb.Append("select top 3 * from SystemUser where organizationid=@orgId");
				sqlcmd.Parameters.AddWithValue("orgId", orgId.ToString());
				if (userRole != string.Empty)
				{
					sb.Append("' and role=@role");
					sqlcmd.Parameters.AddWithValue("role", userRole);
				}
				sb.Append("' ORDER BY NEWID()");
				sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
				sqlconn.Open();
				sqlcmd.CommandText = sb.ToString();
				sqlcmd.Connection = sqlconn;
				reader = sqlcmd.ExecuteReader();
				DataTable table = null;
				try
				{
					table = new DataTable();
					table.Load(reader);
				}
				finally
				{
					reader.Close();
				}

				for (int i = 0; i < 3; i++)
				{
					userRecipients[i] = new CRMEntity(table, i, EntityNames.Users);
				}
			}
			catch (SqlException sex)
			{
				FileWriter.Instance.WriteToFile(sex.ToString());
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
			}
			finally
			{
				sqlconn.Close();
			}

			return userRecipients;
		}

		public Guid GetRandomChildBUid(Guid BUid)
		{
			Guid childBUid = Guid.Empty;
			SqlConnection sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			SqlCommand sqlcmd;
			SqlDataReader reader;
			try
			{
				string cmd = "select top 1 BusinessUnitId from BusinessUnit where Name not like '&deletable&' and ParentBusinessUnitId=@buId ORDER BY NEWID()";
				sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
				sqlconn.Open();
				sqlcmd = new SqlCommand(cmd, sqlconn);
				sqlcmd.Parameters.AddWithValue("buId", BUid);
				reader = sqlcmd.ExecuteReader();
				try
				{
					while (reader.Read())
					{
						childBUid = new Guid(reader["BusinessUnitId"].ToString());
					}
				}
				finally
				{
					reader.Close();
				}

			}
			catch (SqlException sex)
			{
				FileWriter.Instance.WriteToFile(sex.ToString());
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
			}
			finally
			{
				sqlconn.Close();
			}

			return childBUid;
		}



		public CRMEntity GetNextOutlookUser()
		{
			return GetNextOutlookUser(string.Empty, Guid.Empty);
		}

		public CRMEntity GetNextOutlookUser(string role, Guid orgID)
		{
			if (orgID == Guid.Empty)
			{
				orgID = GetRandomOrg();
			}
			CRMEntity user;
			Hashtable props = new Hashtable();

			if (role != string.Empty)
			{
				if (!props.ContainsKey("role"))
				{
					props.Add("role", role);
				}
				else
				{
					props["role"] = role;
				}
			}

			if (!props.ContainsKey("outlookuser"))
			{
				props.Add("outlookuser", "1");
			}
			else
			{
				props["outlookuser"] = "1";
			}
			user = GetNextUser(props, orgID);
			SetUserStateCode(user, EntityStates.InUse);
			return user;
		}

		#region Macro Mobile Offline TEST

		/// <summary>
		/// Get Mobile offline user
		/// </summary>
		/// <param name="orgID"></param>
		/// <returns>Mobile Enable System User Entity</returns>
		public CRMEntity GetNextMobileOfflineUser(Guid orgID)
		{
			if (orgID == Guid.Empty)
			{
				CRMEntity organization;
				organization = GetRandomMobileOfflineOrganization();
				orgID = new Guid(organization[EntityIDNames.Organization]);
			}

			Hashtable props = new Hashtable();
			props.Add(EntityIDNames.Organization, orgID);
			props.Add("IsUserConfiguredForMobileOffline", 1);
			CRMEntity user = GetNextUser(props, orgID);
			return user;
		}

		/// <summary>
		/// Select the randomly organization if IsMobileOfflineOptedIn column boolean value is true from Organization table         
		/// </summary 
		/// <returns>get the one organization record randomly from organization table if IsMobileOfflineOptedIn is true</returns>
		public static CRMEntity GetRandomMobileOfflineOrganization()
		{
			CRMEntity organization = null;

			try
			{
				string cmd = string.Format("select top 1 * from {0} where {1} = 1 ORDER BY NEWID()", EntityNames.Organizations, "IsMobileOfflineOptedIn");
				using (SqlConnection sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
				{
					sqlconn.Open();
					using (SqlCommand sqlcmd = new SqlCommand(cmd, sqlconn))
					{
						using (SqlDataReader reader = sqlcmd.ExecuteReader())
						{
							while (reader.Read())
							{
								organization = new CRMEntity(reader, EntityNames.Organizations);
								break;
							}

							// handling org not found case 
							if (organization == null)
							{
								string msg = "Mobile Offline Enabled organization not found";
								throw new Exception(msg);
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
				throw;
			}
			return organization;
		}

		/// <summary>
		/// To update the properties of system user so that next time when testcase is executed for same user, 
		/// it behaves as incremental sync and not full sync
		/// </summary>
		/// <param name=entity">System User entity</param>
		public static void UpdateMobileOfflineSyncSettings(CRMEntity entity)
		{
			//// TO DO write generic EMDB Entity Update method
			int rowCnt = 0; 
			using(SqlCommand cmd = new SqlCommand())
			{ 
				using(cmd.Connection = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
				{ 
					cmd.Connection.Open();
					cmd.CommandText = string.Format("UPDATE {0} SET {1} = {2} , {3} = {4} where {5} = '{6}'", entity["type"]
																											, "MobileOfflinePrevSID", entity["MobileOfflinePrevSID"]
																											, "MobileOfflineModelVersion", entity["MobileOfflineModelVersion"]
																											, EntityManagerID, entity[EntityManagerID]);
					try
					{
						rowCnt = cmd.ExecuteNonQuery();
					}
					catch (Exception e)
					{
						FileWriter.Instance.WriteToFile(string.Format("Error when setting entity prevSID in Organization table - {0}", cmd.CommandText));
						FileWriter.Instance.WriteToFile(string.Format("Error message: {0}", e.ToString()));
						throw;
					}
				}
			}
		}
		#endregion

		/// <summary>
		/// Gets the next free user object.
		/// </summary>
		/// <param name="Props">Properties for the requested user</param>
		/// <returns>CRMEntity representing the user</returns>
		public CRMEntity GetNextUser(Hashtable Props)
		{
			EntityRequest er = new EntityRequest();
			er.ReturnAs = EntityNames.Users;
			er.Type = EntityNames.Users;
			er.ParentID = GetRandomOrg(); // m_OrgID; - this is to support numti org scenario
			er.Props = Props;

			Hashtable User = GetEntities(er);

			return (CRMEntity)User[er.ReturnAs];
		}
		public CRMEntity GetNextORGEntity(string EntityType)
		{
			EntityRequest er = new EntityRequest();
			er.Type = EntityType;
			er.ParentID = GetRandomOrg(); // m_OrgID; - this is to support numti org scenario
			er.ReturnAs = EntityType;

			return (CRMEntity)(GetEntities(er)[EntityType]);
		}

		//get a user from this org
		public CRMEntity GetNextUser(Hashtable Props, Guid Org)
		{
			EntityRequest er = new EntityRequest();
			er.ReturnAs = EntityNames.Users;
			er.Type = EntityNames.Users;
			er.ParentID = Org;
			er.Props = Props;

			Hashtable User = GetEntities(er);

			return (CRMEntity)User[er.ReturnAs];
		}

		//get an entity from this org
		public CRMEntity GetNextORGEntity(string EntityType, Guid Org)
		{
			EntityRequest er = new EntityRequest();
			er.Type = EntityType;
			er.ParentID = Org;
			er.ReturnAs = EntityType;

			return (CRMEntity)(GetEntities(er)[EntityType]);
		}

		public CRMEntity[] GetAllRecordsForEntity(EntityRequest er, int count)
		{
			System.Int64 BaseVal = System.Int64.MinValue;
			System.Int64 MaxVal = System.Int64.MinValue;
			System.Int64 StartVal = System.Int64.MinValue;
			System.Int64 CurrentVal = 0;

			ArrayList list = new ArrayList();

			SqlConnection SqlCon = new SqlConnection(m_EMSQLCon.ConnectionString);

			try
			{
				SqlCon.Open();

				Guid ParentID = Guid.Empty;
				//If a parent is specified, get a start and max value.
				if (Guid.Empty != er.ParentID)
				{

					if (Guid.Empty != er.GrandParentID)
					{
						//this is a user owned entity, grand parent is the Org
						ParentID = GetOwnerGuid(er.ParentID, er.GrandParentID);

					}
					else
						ParentID = er.ParentID;
					System.Globalization.NumberFormatInfo nfi = new System.Globalization.NumberFormatInfo();
					nfi.NumberGroupSeparator = "";

					if (false == m_Owners.ContainsKey(ParentID))
						throw new EntityNotFoundException("Failed to find owner : " + er.ParentID.ToString());
					if (false == m_Owners[ParentID].ContainsKey(er.Type))
						throw new EntityNotFoundException("Owner : " + er.ParentID.ToString() + " Does not own any " + er.Type);

					BaseVal = System.Int64.Parse(m_Owners[ParentID][EntityManagerID].ToString());
					BaseVal = BaseVal << BitShift;

					//Now get the max val we should look at.
					MaxVal = System.Int64.Parse(m_Owners[ParentID][er.Type].ToString());
					MaxVal += BaseVal;

					StartVal = System.Int64.Parse(m_Owners[ParentID][er.Type].ToString());
					Double RanNum = m_RanNum.NextDouble();
					Double dbl = RanNum * StartVal;
					StartVal = System.Int64.Parse(dbl.ToString("n0", nfi));

					StartVal += BaseVal;
				}

				CurrentVal = StartVal;
				do
				{
					//Build the SQL for the current request
					SqlTransaction tran = SqlCon.BeginTransaction(System.Data.IsolationLevel.Serializable);

					SqlCommand cmd = new SqlCommand();
					cmd.Transaction = tran;
					cmd.Connection = SqlCon;
					cmd.CommandText = "SELECT TOP " + count.ToString() + " * FROM " + er.Type;

					if (er.Props.ContainsKey(AppendFilter))
					{
						cmd.CommandText += string.Format(" WHERE {0}", er.Props[AppendFilter]);
					}

					SqlDataReader reader = cmd.ExecuteReader();
					cmd.Parameters.Clear();

					try
					{
						//Lock this guy and commit the transaction.
						while (true == reader.Read())
						{
							list.Add(new CRMEntity(reader, er.Type));
							//we are locking the entity only when it is not a user
							if (er.Type != EntityNames.Users)
							{
								cmd.CommandText = "UPDATE " + er.Type + " SET " + EntityManagerStateCode + "=" + (int)EntityStates.InUse;
								cmd.CommandText += " WHERE " + EntityManagerID + "=@" + EntityManagerID;
								cmd.Parameters.AddWithValue(EntityManagerID, reader[EntityManagerID]);



								cmd.Parameters.Clear();
							}
						}
					}
					finally
					{
						if (!reader.IsClosed)
							reader.Close();

						tran.Commit();
					}

					if (list.Count == 0)
					{
						// Advance to the next position.
						if (CurrentVal++ == MaxVal)
							CurrentVal = BaseVal;
					}
					else
					{
						break;
					}

				} while (StartVal != CurrentVal);

				if (list.Count == 0)
					throw new EntityNotFoundException("Failed to find any entities for Request: " + er.ToString());
			}
			finally
			{
				SqlCon.Close();
			}

			CRMEntity[] retEntities = new CRMEntity[list.Count];
			for (int j = 0; j < list.Count; j++)
			{
				retEntities[j] = (CRMEntity)list[j];
			}

			return retEntities;
		}

		private string GetSqlQuery(SqlCommand command)
		{
			string commandText = command.CommandText;
			if (command.CommandType == System.Data.CommandType.Text)
			{
				foreach (SqlParameter param in command.Parameters)
				{
					string replacement;
					switch (param.DbType)
					{
						case System.Data.DbType.Boolean:
							replacement = Convert.ToBoolean(param.Value) == true ? "1" : "0";
							break;
						case System.Data.DbType.String:
							replacement = String.Format("'{0}'", param.Value);
							break;
						default:
							replacement = param.Value.ToString();
							break;
					}
					commandText = commandText.Replace("@" + param.ParameterName, replacement);
				}
			}
			return commandText;
		}

		/// <summary>
		/// Used to Get Setup user related data
		/// </summary>
		/// <returns></returns>
		public Hashtable GetSetupUser()
		{

			CRMEntity FoundEntity = null;
			Hashtable RetEntities = new Hashtable();

			SqlConnection SqlCon = new SqlConnection(ConfigSettings.Default.EMSQLCNN);

			try
			{
				SqlCon.Open();
				//Build the SQL for the current request
				SqlTransaction tran = SqlCon.BeginTransaction(System.Data.IsolationLevel.Serializable);

				SqlCommand cmd = new SqlCommand();
				cmd.Transaction = tran;
				cmd.Connection = SqlCon;
				cmd.CommandText = "SELECT top 1 systemuserid FROM SetupUser";
				SqlDataReader reader = cmd.ExecuteReader();

				DataTable table = new DataTable();
				table.Load(reader);
				int numberOfRows = table.Rows.Count;

				if (numberOfRows <= 0)
				{
					throw new EntityNotFoundException("No rows found for entity: " + GetSqlQuery(cmd));
				}

				cmd.Parameters.Clear();
				tran.Dispose();
				reader.Close();
				cmd.Connection.Dispose();
				FoundEntity = new CRMEntity(table, 0, "setupuser");
				RetEntities.Add("setupuser", FoundEntity);

			}
			finally
			{
				SqlCon.Close();
			}

			return RetEntities;

		}

		/// <summary>
		/// Gets the Entities Doesn't work recursivly and will Query based on hte UserID
		/// </summary>
		/// <param name="er"></param>
		/// <returns></returns>
		public Hashtable GetExchangeEntities(EntityRequest er)
		{

			CRMEntity FoundEntity = null;
			String entityTypeFormFailure = null;
			Hashtable RetEntities = new Hashtable();

			SqlConnection SqlCon = new SqlConnection(ConfigSettings.Default.EMSQLCNN);

			try
			{
				SqlCon.Open();

				Guid ParentID = Guid.Empty;
				//If a parent is specified, get a start and max value.
				if (Guid.Empty != er.ParentID)
				{

					if (Guid.Empty != er.GrandParentID)
					{
						//this is a user owned entity, grand parent is the Org
						ParentID = GetOwnerGuid(er.ParentID, er.GrandParentID);

					}
					else
						ParentID = er.ParentID;
					System.Globalization.NumberFormatInfo nfi = new System.Globalization.NumberFormatInfo();
					nfi.NumberGroupSeparator = "";

					if (false == m_Owners.ContainsKey(ParentID))
						throw new EntityNotFoundException("Failed to find owner : " + er.ParentID.ToString());
					if (false == m_Owners[ParentID].ContainsKey(er.Type))
						throw new EntityNotFoundException("Owner : " + er.ParentID.ToString() + " Does not own any " + er.Type, er.Type);
				}

				//Build the SQL for the current request
				SqlTransaction tran = SqlCon.BeginTransaction(System.Data.IsolationLevel.Serializable);

				SqlCommand cmd = new SqlCommand();
				cmd.Transaction = tran;
				cmd.Connection = SqlCon;

				string where = " WHERE " + EntityManagerStateCode + "=@" + EntityManagerStateCode + " AND ";
				cmd.Parameters.AddWithValue(EntityManagerStateCode, (int)EntityStates.Free);
				where += "EntityManagerOwningUser= @OwnerId AND ";
				cmd.Parameters.AddWithValue("OwnerId", ParentID);

				if (0 != er.Props.Count)
				{
					foreach (string Key in new ArrayList(er.Props.Keys))
					{
						object Prop = er.Props[Key];

						if (!Prop.GetType().Name.Equals("EntityRequest[]"))
						{
							if (Key.ToLower().Equals("name") || Key.ToLower().Equals("lastname") || Key.ToLower().Equals("subject") ||
							Key.ToLower().Equals("title"))
							{
								where += Key + " like '%" + ((string)Prop) + "%' AND ";
							}
							else
							{
								where += Key + "=@" + Key + " AND ";
								cmd.Parameters.AddWithValue(Key, Prop.ToString());
							}
						}
					}
				}
				//Trim off the the " AND " at the end.
				where = where.Remove(where.Length - 5);

				cmd.CommandText = "SELECT TOP 1 * FROM " + er.Type;
				cmd.CommandText += where;

				SqlDataReader reader = cmd.ExecuteReader();

				DataTable table = new DataTable();
				table.Load(reader);
				int numberOfRows = table.Rows.Count;
				int randomRow = -1;
				if (numberOfRows <= 0)
				{
					throw new EntityNotFoundException("No rows found for entity: " + GetSqlQuery(cmd), er.Type);
				}

				cmd.Parameters.Clear();
				tran.Dispose();
				reader.Close();
				cmd.Connection.Dispose();

				randomRow = 0;
				if (numberOfRows > 1)
				{
					randomRow = m_RanNum.Next(numberOfRows);
				}
				FoundEntity = new CRMEntity(table, randomRow, er.Type);

				int startRow = randomRow;
				while (null != FoundEntity)
				{
					try
					{
						//Now we need to check and see if recursion is necessary.
						foreach (string Key in new ArrayList(er.Props.Keys))
						{
							object Prop = er.Props[Key];
							if (Prop.GetType().Name.Equals("EntityRequest[]"))
							{
								EntityRequest[] EntitesRequested = (EntityRequest[])Prop;
								foreach (EntityRequest SubEr in EntitesRequested)
								{
									if (SubEr.ParentID != Guid.Empty)
										SubEr.ParentID = new Guid(FoundEntity[GetEntityIDName(er.Type)]);
									else
									{
										//Modify the requested SubEr to use a strange foreign key relationship.
										if (true == SubEr.Props.ContainsKey(Key))
											SubEr.Props.Remove(Key);

										SubEr.Props.Add(Key, FoundEntity[GetEntityIDName(er.Type)]);

									}
									SubEr.GrandParentID = ParentID;
									Hashtable NewRet = GetExchangeEntities(SubEr);

									foreach (string SubKey in new ArrayList(NewRet.Keys))
										RetEntities.Add(SubKey, NewRet[SubKey]);
								}
							}
						}
					}
					catch (EntityNotFoundException enfEx)
					{
						RetEntities.Clear();
						FoundEntity = null;
						entityTypeFormFailure = enfEx.EntityType;
					}

					if (null == FoundEntity)
					{
						if (numberOfRows > 1)
						{
							if (++randomRow == numberOfRows)
							{
								Trace.WriteLine("Unable to find Sub Entities for Entity, going to next Entity");
								randomRow = 0;
							}
							if (randomRow == startRow)
							{
								Trace.WriteLine("Did not find sub entities for range of entities, breaking out");
								break;
							}
							FoundEntity = new CRMEntity(table, randomRow, er.Type);
						}
					}
					else
					{
						RetEntities.Add(er.ReturnAs, FoundEntity);
						// Only lock the user if sub requests were also successful
						if (er.Type.Equals(EntityNames.Users))
						{
							InUseEntity(FoundEntity);
						}
						break;
					}
				}

				if (null == FoundEntity)
				{
					throw new EntityNotFoundException("Failed to find any entities for Request: " + er.ToString(),
							entityTypeFormFailure);
				}
			}
			finally
			{
				SqlCon.Close();
			}

			return RetEntities;
		}

		public Hashtable GetEntities(EntityRequest er)
		{
			System.Int64 BaseVal = System.Int64.MinValue;
			System.Int64 MaxVal = System.Int64.MinValue;
			System.Int64 StartVal = System.Int64.MinValue;
			System.Int64 CurrentVal = 0;

			CRMEntity FoundEntity = null;
			String entityTypeFormFailure = null;
			Hashtable RetEntities = new Hashtable();

			SqlConnection SqlCon = new SqlConnection(ConfigSettings.Default.EMSQLCNN);

			try
			{
				SqlCon.Open();

				Guid ParentID = Guid.Empty;
				//If a parent is specified, get a start and max value.
				if (Guid.Empty != er.ParentID)
				{

					if (Guid.Empty != er.GrandParentID)
					{
						//this is a user owned entity, grand parent is the Org
						ParentID = GetOwnerGuid(er.ParentID, er.GrandParentID);

					}
					else
						ParentID = er.ParentID;
					System.Globalization.NumberFormatInfo nfi = new System.Globalization.NumberFormatInfo();
					nfi.NumberGroupSeparator = "";

					if (false == m_Owners.ContainsKey(ParentID))
						throw new EntityNotFoundException("Failed to find owner : " + er.ParentID.ToString());
					if (false == m_Owners[ParentID].ContainsKey(er.Type))
						throw new EntityNotFoundException("Owner : " + er.ParentID.ToString() + " Does not own any " + er.Type, er.Type);

					BaseVal = System.Int64.Parse(m_Owners[ParentID][EntityManagerID].ToString());
					BaseVal = (BaseVal << BitShift) + 1;

					//Now get the max val we should look at.
					MaxVal = System.Int64.Parse(m_Owners[ParentID][er.Type].ToString());
					MaxVal += BaseVal;

					StartVal = System.Int64.Parse(m_Owners[ParentID][er.Type].ToString());
					Double RanNum = m_RanNum.NextDouble();
					Double dbl = RanNum * StartVal;
					StartVal = System.Int64.Parse(dbl.ToString("n0", nfi));

					StartVal += BaseVal;
					if (StartVal >= MaxVal)
					{
						StartVal = MaxVal - 1;
					}
				}

				CurrentVal = StartVal;
				bool hasProperties = false;
				bool notFound = true;
				bool hasSubEntityRequest = false;
				do
				{
					//Build the SQL for the current request
					SqlTransaction tran = SqlCon.BeginTransaction(System.Data.IsolationLevel.Serializable);

					SqlCommand cmd = new SqlCommand();
					cmd.Transaction = tran;
					cmd.Connection = SqlCon;

					string where = " where ";
					if (!IsPerUserPerRun)
					{
						where += EntityManagerStateCode + "=@" + EntityManagerStateCode + " AND ";
						cmd.Parameters.AddWithValue(EntityManagerStateCode, (int)EntityStates.Free);
					}
					else
					{
						where += EntityManagerStateCode + "<>@" + EntityManagerStateCode + " AND ";
						cmd.Parameters.AddWithValue(EntityManagerStateCode, (int)EntityStates.Deleted);
					}

					if (System.Int64.MinValue != StartVal)
					{
						where += EntityManagerID + ">= @BaseVal AND ";
						cmd.Parameters.AddWithValue("BaseVal", BaseVal.ToString());
						where += EntityManagerID + "<= @MaxVal AND ";
						cmd.Parameters.AddWithValue("MaxVal", MaxVal.ToString());

						if (0 != er.Props.Count)
						{
							foreach (string Key in new ArrayList(er.Props.Keys))
							{
								object Prop = er.Props[Key];

								if (!Prop.GetType().Name.Equals("EntityRequest[]"))
								{
									hasProperties = true;
									//Attribute new_name added as it is used as filter condition in new_customAccount and new_customOpportunity 
									//entities for RollupCustomOpportunityCRUDUnitTest and RollupCustomAccountCRUDUnitTest

									if (Key.ToLower().Equals("name") || Key.ToLower().Equals("lastname") || Key.ToLower().Equals("subject") || Key.ToLower().Equals("title") || Key.ToLower().Equals("domainname") || Key.ToLower().Equals("new_name"))
									{
										where += Key + " like '%" + ((string)Prop) + "%' AND ";
									}
									else
									{
										where += Key + "=@" + Key + " AND ";
										cmd.Parameters.AddWithValue(Key, Prop.ToString());
									}
								}
								else
								{
									hasSubEntityRequest = true;
								}
							}
						}

						if (hasProperties == false && !er.DoNotUseIDLookup)
						{
							if (System.Int64.MinValue != CurrentVal)
							{
								if (!er.Type.Equals(EntityNames.Users))
								{
									where += EntityManagerID + "= @CurrentVal AND ";
									cmd.Parameters.AddWithValue("CurrentVal", CurrentVal.ToString());
								}
							}
						}
					}

					//
					// this is an option if the tables get very large and order by newid() is giving slow results.
					// The below addition considerably speeds up the queries but will sometimes give 0 results
					// even if there are results to retrieve due to randomness.
					//
					//if(hasProperties == true)
					//{
					//    where += " 0.2 >= CAST(CHECKSUM(NEWID(), ID) & 0x7fffffff AS float) / CAST (0x7fffffff AS int) AND  ";
					//}

					//Trim off the the " AND " at the end.
					where = where.Remove(where.Length - 5);

					// If there is a Sub Entity Request we need to get all the entities but if there is no sub entity request then we can only get top 10
					if (hasSubEntityRequest)
					{
						cmd.CommandText = "SELECT top 10 * FROM " + er.Type;
					}
					else
					{
						cmd.CommandText = "SELECT TOP 1 * FROM " + er.Type;
					}
					cmd.CommandText += where;

					if (System.Int64.MinValue == StartVal || hasProperties)
					{
						cmd.CommandText += " ORDER BY NEWID()";
					}

					int retryCount = 13;
					int retryTime = 1000;
					int numberOfRows = 0;
					SqlDataReader reader = null;
					DataTable table = null;
					int randomRow = -1;
					try
					{
						if (er.Type.Equals("SystemUser"))
						{
							while (retryCount > 0 && numberOfRows <= 0)
							{
								reader = cmd.ExecuteReader();
								table = new DataTable();
								table.Load(reader);
								numberOfRows = table.Rows.Count;
								retryCount--;
								if (retryCount >= 1 && numberOfRows <= 0)
								{
									reader.Close();
									cmd.Connection.Dispose();

									Trace.WriteLine(string.Format("Waiting for an available {0} ...", er.Type));
									System.Threading.Thread.Sleep(retryTime);
									if (retryCount >= 8)
									{
										retryTime += 500;
									}
									else if (retryCount < 8 && retryCount > 3)
									{
										retryTime += 1500;
									}
									else
									{
										retryTime += 2000;
									}
									SqlCon = new SqlConnection(m_EMSQLCon.ConnectionString);
									SqlCon.Open();
									tran = SqlCon.BeginTransaction(System.Data.IsolationLevel.Serializable);
									cmd.Transaction = tran;
									cmd.Connection = SqlCon;
								}
							}
						}
						else
						{
							reader = cmd.ExecuteReader();
							table = new DataTable();
							table.Load(reader);
							numberOfRows = table.Rows.Count;
						}
					}
					finally
					{
						//cmd.Parameters.Clear();
						tran.Dispose();
						reader.Close();
						cmd.Connection.Dispose();
					}
					if (numberOfRows <= 0)
					{
						if (er.Type.Equals("SystemUser"))
						{
							throw new EntityNotFoundException(string.Format(@"Failed to get Free System User. Retried for {0} ms: {1}", retryTime, GetSqlQuery(cmd)), er.Type);
						}
						else
						{
							throw new EntityNotFoundException("No rows found for entity: " + GetSqlQuery(cmd), er.Type);
						}
					}

					randomRow = 0;
					if (numberOfRows > 1)
					{
						randomRow = m_RanNum.Next(numberOfRows);
					}
					FoundEntity = new CRMEntity(table, randomRow, er.Type);

					int startRow = randomRow;
					while (null != FoundEntity)
					{
						try
						{
							//Now we need to check and see if recursion is necessary.
							foreach (string Key in new ArrayList(er.Props.Keys))
							{
								object Prop = er.Props[Key];
								if (Prop.GetType().Name.Equals("EntityRequest[]"))
								{
									EntityRequest[] EntitesRequested = (EntityRequest[])Prop;
									foreach (EntityRequest SubEr in EntitesRequested)
									{
										if (SubEr.ParentID != Guid.Empty)
											SubEr.ParentID = new Guid(FoundEntity[GetEntityIDName(er.Type)]);
										else
										{
											//Modify the requested SubEr to use a strange foreign key relationship.
											if (true == SubEr.Props.ContainsKey(Key))
												SubEr.Props.Remove(Key);

											SubEr.Props.Add(Key, FoundEntity[GetEntityIDName(er.Type)]);

										}
										SubEr.GrandParentID = ParentID;
										Hashtable NewRet = GetEntities(SubEr);

										foreach (string SubKey in new ArrayList(NewRet.Keys))
											RetEntities.Add(SubKey, NewRet[SubKey]);
									}
								}
							}
						}
						catch (EntityNotFoundException enfEx)
						{
							RetEntities.Clear();
							FoundEntity = null;
							entityTypeFormFailure = enfEx.EntityType;
						}

						if (null == FoundEntity)
						{
							if (numberOfRows == 1)
							{
								//Advance to the next position.
								if (CurrentVal++ == MaxVal)
									CurrentVal = BaseVal;
							}
							else if (numberOfRows > 1)
							{
								if (++randomRow == numberOfRows)
								{
									Trace.WriteLine("Unable to find Sub Entities for Entity, going to next Entity");
									randomRow = 0;
								}
								if (randomRow == startRow)
								{
									// Did not find any sub entities for all top level entities. need to break out of outer loop as well
									notFound = false;
									Trace.WriteLine("Did not find sub entities for range of entities, breaking out");
									break;
								}
								FoundEntity = new CRMEntity(table, randomRow, er.Type);
							}
						}
						else
						{
							RetEntities.Add(er.ReturnAs, FoundEntity);
							// Only lock the user if sub requests were also successful and the user is not for unit tests
							if (er.Type.Equals(EntityNames.Users) && !IsUnitTestCase)
							//if (er.Type.Equals(EntityNames.Users) )
							{
								InUseEntity(FoundEntity);
							}
							notFound = false;
							break;
						}
					}

				} while (StartVal != CurrentVal && hasProperties == false && notFound == true);

				if (null == FoundEntity)
				{
					throw new EntityNotFoundException("Failed to find any entities for Request: " + er.ToString(), entityTypeFormFailure);
				}
			}
			finally
			{
				SqlCon.Close();
			}

			return RetEntities;
		}

		#endregion

		#region Free / Delete

		public void DeleteEntity(CRMEntity Entity)
		{
			SetEntityStateCode(Entity, EntityStates.Deleted);
		}
		public void InUseEntity(CRMEntity Entity)
		{
			SetEntityStateCode(Entity, EntityStates.InUse);
		}
		public void FreeEntity(CRMEntity Entity)
		{
			SetEntityStateCode(Entity, EntityStates.Free);
		}
		private void SetEntityStateCode(CRMEntity Entity, EntityStates State)
		{
			int rowCnt = 0;

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			cmd.Connection.Open();
			cmd.CommandText = "UPDATE " + Entity["type"] + " SET " + EntityManagerStateCode + "=" + (int)State;
			if (Entity[EntityManagerID] != null)
			{
				cmd.CommandText += " WHERE " + EntityManagerID + "=" + Entity[EntityManagerID];
			}
			else
			{
				cmd.CommandText += " WHERE ExchangeId ='" + Entity["exchangeid"] + "'";
			}

			try
			{
				rowCnt = cmd.ExecuteNonQuery();
				//why does this check for 2 Exchange entities are returning 1 but being updated. Please review
				if (!Entity["type"].ToString().Contains("new_customaccount")
					&& !Entity["type"].ToString().Contains("new_customopportunity")
					&& !Entity["type"].ToString().Contains("Exchange")
					&& !Entity["type"].ToString().Contains("Task")
					&& !Entity["type"].ToString().Contains("QueueItem")
					&& !Entity["type"].ToString().Contains("Incident")
					&& rowCnt != 2)
				{
					Trace.WriteLine("Row Count Error: " + rowCnt);
					throw new Exception("ExecuteNonQuery Wrong # of rows " + cmd.CommandText);
				}
			}
			catch (SqlException e)
			{
				FileWriter.Instance.WriteToFile(string.Format("Error when setting entity state code - {0}", cmd.CommandText));
				FileWriter.Instance.WriteToFile(string.Format("Error message: {0}", e.ToString()));
				throw;
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(string.Format("Error when setting entity state code - {0}", cmd.CommandText));
				FileWriter.Instance.WriteToFile(string.Format("Error message: {0}", ex.ToString()));
				throw ex;
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		public void FreeOutlookUser(CRMEntity Entity)
		{
			SetUserStateCode(Entity, EntityStates.Free);
			SetUserOutlookStateCode(Entity, EntityStates.Free);
		}

		public void FreeUser(CRMEntity Entity)
		{
			SetUserStateCode(Entity, EntityStates.Free);
		}

		private void SetUserOutlookStateCode(CRMEntity Entity, EntityStates State)
		{
			int rowCnt = 0;

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			cmd.Connection.Open();
			cmd.CommandText = "UPDATE " + Entity["type"] + " SET " + EntityManagerOutlookStateCode + "=" + (int)State;
			cmd.CommandText += " WHERE " + EntityManagerID + "=@entityManagerId";
			cmd.Parameters.AddWithValue("entityManagerId", Entity[EntityManagerID]);
			try
			{
				rowCnt = cmd.ExecuteNonQuery();

				if (rowCnt != 2)
				{
					Trace.WriteLine("Row Count Error: " + rowCnt);
					throw new Exception("ExecuteNonQuery Wrong # of rows " + cmd.CommandText);
				}
			}
			catch (SqlException e)
			{
				FileWriter.Instance.WriteToFile(string.Format("Error when setting entity state code - {0}", cmd.CommandText));
				FileWriter.Instance.WriteToFile(string.Format("Error message: {0}", e.ToString()));
				throw e;
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(string.Format("Error when setting entity state code - {0}", cmd.CommandText));
				FileWriter.Instance.WriteToFile(string.Format("Error message: {0}", ex.ToString()));
				throw ex;
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		private void SetUserStateCode(CRMEntity Entity, EntityStates State)
		{
			int rowCnt = 0;

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = new SqlConnection(ConfigSettings.Default.EMSQLCNN);
			cmd.Connection.Open();
			cmd.CommandText = string.Format("UPDATE {0} SET {1} = @state where {2} = @entityManagerId", Entity["type"], EntityManagerStateCode, EntityManagerID);
			cmd.Parameters.AddWithValue("state", (int) State);
			cmd.Parameters.AddWithValue("entityManagerId", Entity[EntityManagerID]);
			try
			{
				rowCnt = cmd.ExecuteNonQuery();

				if (rowCnt != 2)
				{
					Trace.WriteLine("Row Count Error: " + rowCnt);
					throw new Exception("ExecuteNonQuery Wrong # of rows " + cmd.CommandText);
				}
			}
			catch (SqlException e)
			{
				Trace.WriteLine(e.Message);
			}
			finally
			{
				cmd.Connection.Close();
			}
		}

		public static IUserManager CreateUserManagerInstance(string _emdbSqlConnStr)
		{
			if (string.IsNullOrEmpty(ConfigSettings.Default.UserManagerClass))
			{
				return new DefaultUserManager();
			}

			var parts = ConfigSettings.Default.UserManagerClass.Split(new[] { ',' });
			var assembly = parts[0].Trim();
			var typeName = parts[1].Trim();
			Assembly asm;
			try
			{
				asm = Assembly.LoadFile(assembly);
			}
			catch (Exception ex)
			{
				var msg = string.Format(@"UserManager library {0} failed to be loaded. Please double check it is placed in {1}", parts[0], parts[1]);
				Trace.WriteLine(msg);
				throw new Exception(msg, ex);
			}

			var type = asm.GetType(typeName);
			var constructorArgs = new object[] { _emdbSqlConnStr };

			object obj;
			try
			{
				obj = Activator.CreateInstance(type, constructorArgs);
			}
			catch (Exception ex)
			{
				var msg = string.Format(@"Could not instantiate type {0} from assembly {1}", typeName, assembly);
				Trace.WriteLine(msg);
				throw new Exception(msg, ex);
			}

			if (!(obj is IUserManager))
			{
				var msg = string.Format(@"Type {0} from assembly {1} needs to implement {2}", typeName, assembly, typeof(IUserManager).ToString());
				Trace.WriteLine(msg);
				throw new Exception(msg);
			}

			return obj as IUserManager;
		}

		#endregion
	}

	public class EntityNotFoundException : System.Exception
	{
		public string EntityType { get; private set; }

		public EntityNotFoundException(string Message)
			: base(Message)
		{ }

		public EntityNotFoundException(string Message, string entityType)
			: this(Message)
		{
			this.EntityType = entityType;
		}
	}

	public enum EntityStates
	{
		Free = 0,
		InUse = 1,
		Deleted = 2
	}

	public class OrganizationInfo
	{
		public Guid OrganizationId { get; set; }
		public string ServerBaseUrl { get; set; }
		public string FeatureSet { get; set; }
		public bool ExchangeMode { get; set; }
		public EntityStates State { get; set; }
		public MultipleServersData ServerInfo { get; set; }
	}
}