﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;


using Microsoft.Xrm.Sdk;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class PhoneCallCRUDUnitTest: CreateBasicEntityBaseTest
	{
		public override string EntityName
		{
			get
			{
				return EntityNames.Phonecalls;
			}
		}


		public override string PrintEntityData(Entity entity)
		{
			return String.Format("{0} subject={1}", EntityName, entity["subject"].ToString());

		}

		[TestMethod]
		public void UnitTest_CreatePhoneCall()
		{
			string timer = "Phone Call Create Unit Test";
			Init();
			Entity phonecall = new Entity("phonecall");
			phonecall["subject"] = Utils.GetRandomString(5, 10) + "deleteable";
			phonecall["description"] = Utils.GetRandomString(50, 100);
			phonecall["actualdurationminutes"] = 30;
			phonecall["actualstart"] = DateTime.Now;            

			Entity organizer = new Entity("activityparty");
			organizer["partyid"] = new EntityReference("systemuser", new Guid(m_user["systemuserid"]));
			//phonecall["organizer"] = new Entity[] { organizer };
			phonecall["owninguser"] = new Entity[] { organizer };
			Guid phoneId = CreateEntityInCRM(phonecall,timer);

			//add the phonecall to EMDB
			Guid g = EntityManager.Instance.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(this.EntityName, g, new string[] { "OwnerId", "ActivityId", "EntityManagerOwningUser","Subject" }, new string[] { m_user["systemuserid"], phoneId.ToString(), g.ToString(),phonecall["subject"].ToString()});
		}

		[TestMethod]
		public void UnitTest_UpdatePhoneCall()
		{
			Entity phonecall = new Entity("phonecall");
			//find a CRM Entity for update test
			Init("subject", "updateable");

			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "subject", "description","subject"});
			//get the Phone Call in CRM
			phonecall = proxy.Retrieve(phonecall.LogicalName, new Guid(m_contact["ActivityId"]), attributes);
			//update contact address city value
			phonecall["description"] = Utils.GetRandomString(50, 100);
			this.UpdateEntityInCRM(phonecall,"Contact Update Unit Test");

		}

		[TestMethod]
		public void UnitTest_DeletePhoneCall()
		{
			Entity phonecall = new Entity("phonecall");
			//find a CRM Entity for update test
			Init("subject", "deleteable");
			DeleteEntityInCRM("activityid", phonecall, " Delete Phone Call Entity");
			EntityManager.Instance.DeleteEntity(m_contact);
		}
	}
}
