﻿using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.ServiceModel;
using System.Text;
using System.Web.Services.Protocols;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting product entity
	/// </summary>
	[TestClass]
	public class LocalizedAttributesCRUDUnitTest
	{
		CRMEntity m_user, m_products;
		string SummaryFile;
		IOrganizationService Proxy;
		private TestContext m_testContext;

		//test creating/retrieving/updating/deleting product (localized attributes)
		public LocalizedAttributesCRUDUnitTest()
		{
			string timestamp = System.DateTime.Now.Ticks.ToString();
			StringBuilder summaryFileSB = new StringBuilder();
			summaryFileSB.Append(CWR_Help.resultDir);
			summaryFileSB.Append(@"\Perf_Product_CRUD_Summary_");
			summaryFileSB.Append(timestamp);
			summaryFileSB.Append(".log");
			SummaryFile = summaryFileSB.ToString();
		}

		public TestContext TestContext
		{
			get { return m_testContext; }
			set { m_testContext = value; }
		}

		//initialization with sub-properties requirement
		//for instance, require name contains keyword of 'deletable'
		public void init(string filter)
		{
			System.Collections.Hashtable props = new System.Collections.Hashtable();
			System.Collections.Hashtable sub_props = new System.Collections.Hashtable();
			CWR_Help help = null;
			if (!string.IsNullOrEmpty(filter))
			{
				sub_props.Add("name", filter);
				props.Add(EntityNames.Products, sub_props);
				help = new CWR_Help(props);
			}
			else
			{
				string[] product_props = { EntityNames.Products };
				help = new CWR_Help(product_props);
			}

			Hashtable Entities = help.getEntities();
			m_products = (CRMEntity)Entities[EntityNames.Products];
			m_user = (CRMEntity)Entities[EntityNames.Users];
			Proxy = help.getOrganizationServiceProxy();

		}

		//default initialization which with no sub-properties requirement 
		public void init()
		{
			string temp = string.Empty;
			init(temp);
		}
		/// <summary>
		/// Test creating product
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_Prodcut()
		{
			init();
			//create product
			Guid prodcutId = Guid.Empty;
			Entity product = new Entity("product");
			product["name"] = "Macro Test Product " + Utils.GetRandomString(5, 10);

			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Product Create Unit Test");
			try
			{
				prodcutId = Proxy.Create(product);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Product Create Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Creating product test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Product id created in this test is " + prodcutId.ToString());
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		[TestMethod()]
		public void UnitTest__Retrieve_Product()
		{
			init();
			Entity productEntity = new Entity("prdouct");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "productid", "name" });
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Product Retrieve Unit Test");
			try
			{
				productEntity = Proxy.Retrieve("product", new Guid(m_products["productid"]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Prdouct Retrieve Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Retrieving Prdouct test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the product retrieved in this test is " + m_products["productid"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Retrieved attributes are Product Id and Name. " + "productId=" + productEntity["productid"] + " name=" + productEntity["name"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		//test retrieving and updating product
		[TestMethod()]
		public void UnitTest__Update_Product()
		{
			Entity productEntity = new Entity("product");
			//find a CRM Entity for update test
			init();
			//create a dummy product for update
			productEntity["name"] = "Macro Test Create Product " + Utils.GetRandomString(5, 10);
			Guid productId = Proxy.Create(productEntity);

			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "name"});
			//get the product in CRM
			productEntity = Proxy.Retrieve(productEntity.LogicalName, productId, attributes);
			//update product name value
			productEntity["name"] = "Macro Test Update Product " + Utils.GetRandomString(5, 10);
			//update the product
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Product Update Unit Test");
			try
			{
				Proxy.Update(productEntity);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("product Update Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Updating product test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the product retrieved in this test is " + m_products["productid"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Updated attribute is product name" + " name=" + productEntity["name"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}

		}

		//test deleting an Product
		[TestMethod()]
		public void UnitTest__Delete_Product()
		{
			init();
			//create a dummy producct for deletion
			Entity productEntity = new Entity("product");
			productEntity["name"] = "Macro Test Delete Product " + Utils.GetRandomString(5, 10);
			Guid productId = Proxy.Create(productEntity);

			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Product Delete Unit Test");
			try
			{
				Proxy.Delete("product", productId);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Product Delete Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Deleting Product test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the product deleted in this test is " + productId);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		[TestMethod()]
		//retrieve multiple product records
		public void UnitTest__RetrieveMultiple_Product()
		{
			init();
			Entity productEntity = new Entity("product");
			var queryExpression = new QueryExpression()
			{
				Distinct = false,
				EntityName = productEntity.LogicalName,
				ColumnSet = new ColumnSet("productid"),

				Criteria =
				{
					Filters = 
						{
							new FilterExpression
							{
								FilterOperator = LogicalOperator.And,
								Conditions = 
								{
									new ConditionExpression("name", ConditionOperator.Contains, "Macro"),
								},
							}
						}
				}
			};

			EntityCollection results;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Product RetrieveMultiple Unit Test");
			try
			{
				results = Proxy.RetrieveMultiple(queryExpression);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Product RetrieveMultiple Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for retrieving multiple product test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The total number of results returned is " + results.Entities.Count);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}

		}

		[TestMethod()]
		//retrieve using Quickfind (FetchXML)
		public void UnitTest__QuickFind_Product()
		{
			init();
			string quickFindProductSearchString = "Macro%";

			StringBuilder fetch = new StringBuilder();
			fetch.Append("<fetch version='1.0' output-format='xml-platform' mapping='logical'>");
			fetch.Append("<entity name='product'>");
			fetch.Append("<order attribute='name' descending='false' />");
			fetch.Append("<attribute name='name' />");
			fetch.Append("<filter type='or' isquickfindfields='1'>");
			fetch.AppendFormat("<condition attribute='name' operator='like' value='{0}' />", quickFindProductSearchString);
			fetch.Append("</filter>");
			fetch.Append("</entity>");
			fetch.Append("</fetch>");

			FetchExpression query = new FetchExpression(fetch.ToString());

			EntityCollection results;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Product QuickFind using FetchXML Unit Test");
			try
			{
				results = Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("Product QuickFind using FetchXML Unit Test");
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for QuickFind(Fetch XML) products test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The total number of results returned is " + results.Entities.Count);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}
	}
}
