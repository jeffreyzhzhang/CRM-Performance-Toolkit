//-------------------------------------------------------------------------------
// <copyright file="SocialActivityToMultipleEntitiesUnitTest.cs" company="Microsoft">
//		Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//-------------------------------------------------------------------------------

namespace CRM_Perf_BenchMark.SocialActivityToMultiple
{
	using Microsoft.Crm.Sdk.Messages;
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using Microsoft.Xrm.Sdk;
	using System;

	/// <summary>
	/// Unit Test to check SocialActivity to MultipleEntities Flow
	/// </summary>
	[TestClass]
	public class SocialActivityToMultipleEntitiesUnitTests : UnitTestBase
	{
		//WorkFlow Id for creating Social Activity to MultipleEntities which is imported through solution
		private Guid workFlowId = new Guid("aafea808-b12b-46f2-8ca4-9339bba61f3e");

		#region Additional test attributes

		// Use TestInitialize to run code before running each test 
		[TestInitialize()]
		public void TestInitialize()
		{
			base.Initialize();
		}

		#endregion

		#region Individual Test Cases

		/// <summary>
		/// Test Case for Social Activity to MultipleEntities
		/// </summary>
		[TestMethod()]
		public void SocialActivityToMultipleEntitiesTest()
		{
			String socialActivityName = "socialactivity";
			Entity socialActivity = new Entity(socialActivityName);
			socialActivity.Attributes["subject"] = "Social To MultipleEntities " + Utils.GetRandomString(5, 10);

			string socialHandle = "social handle" + Utils.GetRandomString(5, 10);
			string profileName = "profile name" + Utils.GetRandomString(5, 10);
			string profileLink = "profile link" + Utils.GetRandomString(5, 10);
			socialActivity.Attributes["socialadditionalparams"] = "{'targetEntityName':'incident', 'socialHandle':'" + socialHandle + "', 'profileName':'" + profileName + "', 'profilelink':'" + profileLink + "','community':'1', 'influencescore':'1.2', queueId:'" + null + "'}";
			Guid socialActivityId = Proxy.Create(socialActivity);

			//Executing WorkFlow to Create MultipleEntities
			ExecuteWorkflowRequest request = new ExecuteWorkflowRequest()
			{
				WorkflowId = workFlowId
			};
			request.EntityId = socialActivityId;
			Proxy.Execute(request);
		}

		#endregion

	}
}
