﻿using System;
using System.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk;
using ServiceCreator;
using System.IO;
using System.Collections;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Base class for all Macro unit test cases
	/// </summary>
	[TestClass]
	public abstract class UnitTestBase
	{
		protected string m_userName = string.Empty;
		protected string m_domain = string.Empty;
		protected string m_clientKeyPath = string.Empty;
		protected string m_organizationBaseUrl = string.Empty;
		protected string m_password = string.Empty;
		protected string m_organization = string.Empty;
		protected bool isOutlookUser = false;
		protected string m_tokenExpirationTime = string.Empty;
		protected string m_token = string.Empty;

		protected CRMEntity m_user;
		protected NetworkCredential m_nc;
		protected ICredentials networkCredential;
		protected string m_summaryFile;
		protected IOrganizationService m_proxy;



		/// <summary>
		/// Property for webservice so that we do not use the default credential
		/// </summary>
		protected ICredentials NetworkCredential
		{
			get { return networkCredential ?? CredentialCache.DefaultCredentials; }
			set { networkCredential = value; }
		}

		/// <summary>
		/// Property for CreateSubscription so that we do not use the environment variable for user and domain
		/// </summary>
		protected String UserName
		{
			get { return m_userName ?? (m_userName = Environment.UserName); }
			set { m_userName = value; }
		}

		/// <summary>
		/// Public property for CreateSubscription so that we do not use the environment variable for user and domain
		/// </summary>
		protected String UserDomain
		{
			get { return m_domain ?? (m_domain = Environment.UserDomainName); }
			set { m_domain = value; }
		}

		private TestContext m_testContext;
		public TestContext TestContext
		{
			get { return m_testContext; }
			set { m_testContext = value; }
		}

		/// <summary>
		/// User Guid, uniequely identifies user
		/// </summary>
		protected Guid UserId
		{
			get { return new Guid(m_user["systemuserid"]); }
		}


		protected string SummaryFile
		{
			get { return m_summaryFile; }
			set { m_summaryFile = value; }
		}

		protected IOrganizationService Proxy
		{
			get { return m_proxy; }
			set { m_proxy = value; }
		}


		/// <summary>
		/// Initialize() is called once during test execution before
		/// test methods in this test class are executed.
		/// </summary>
		[TestInitialize]
		public virtual void Initialize()
		{
			if (m_user == null)
			{
				EntityManager.Instance.IsUnitTestCase = true;
				Guid orgId = GetCurrentOrgId();

				if (!isOutlookUser)
				{
					var table = GetTestUserProperties();
					m_user = EntityManager.Instance.GetNextUser(table, orgId);
				}
				else
				{
					if (m_testContext.Properties["UserRole"] != null)
					{
						m_user = EntityManager.Instance.GetNextOutlookUser(m_testContext.Properties["UserRole"].ToString(), Guid.Empty);
					}
					else
					{
						m_user = EntityManager.Instance.GetNextOutlookUser();
					}
				}
			}
			m_userName = m_user["domainname"];
			m_password = m_user["userpassword"];
			m_organizationBaseUrl = m_user["OrganizationBaseUrl"];
			m_organization = m_user["organizationname"];
			m_nc = new NetworkCredential(m_userName, m_password);
			m_tokenExpirationTime = m_user["passportticketexpiration"];
			m_token = m_user["crmTicket"];
			m_proxy = EntityManager.Instance.GetTestUserProxy(m_user);
			//set the user credentials for passing into the sync for emulating the outlook client
			//user names can be same for different orgs
			m_clientKeyPath = string.Format("SOFTWARE\\Microsoft\\MSCRM{0}_{1}", m_userName, m_user["organizationid"]);
			NetworkCredential = m_nc;
		}

		protected virtual Guid GetCurrentOrgId()
		{
			return EntityManager.Instance.GetRandomOrg();
		}

		protected virtual Hashtable GetTestUserProperties()
		{
			Hashtable table = new Hashtable();
			if (TestContext.Properties["UserRole"] != null)
			{
				table.Add("role", m_testContext.Properties["UserRole"].ToString());
				//Adding domain name here because Rollup custom entity records are populated for "administrator" user only.
				if (TestContext.Properties["DomainName"] != null)
				{
					table.Add("DomainName", m_testContext.Properties["DomainName"].ToString());
				}
			}
			if (TestContext.Properties["EnabledForACT"] != null)
			{
				table.Add("EnabledForACT", "1");
			}
			return table;
		}

		#region Retrieve Test Entity
		/// <summary>
		/// Retrieve an entity owned by an user
		/// </summary>
		/// <param name="owner">EntityOwner</param>
		/// <param name="entityName">EntityName</param>
		/// <param name="filters">Filters</param>
		/// <returns></returns>
		protected CRMEntity RetrieveTestEntity(CRMEntity owner, string entityName, Hashtable filters = null)
		{
			if (owner == null)
			{
				throw new Exception("Entity owner is null");
			}

			EntityRequest er = new EntityRequest
			{
				Type = entityName,
				ParentID = new Guid(owner[EntityIDNames.User]),
				GrandParentID = new Guid(owner[EntityIDNames.Organization]),
				ReturnAs = entityName,

			};
			if (filters != null)
			{
				er.Props = filters;
			}

			Hashtable Entities = EntityManager.Instance.GetEntities(er);
			return Entities[entityName] as CRMEntity;
		}

		/// <summary>
		/// Retrieve an entity owned by an org
		/// </summary>
		/// <param name="owner">OrgGUID</param>
		/// <param name="entityName">EntityName</param>
		/// <param name="filters">Filters</param>
		/// <returns></returns>
		protected CRMEntity RetrieveTestEntity(Guid ownerId, string entityName, Hashtable filters = null)
		{
			if (ownerId == null)
			{
				throw new Exception("Entity owner is null");
			}

			EntityRequest er = new EntityRequest
			{
				Type = entityName,
				ParentID = ownerId,
				ReturnAs = entityName,

			};

			if (filters != null)
			{
				er.Props = filters;
			}

			Hashtable Entities = EntityManager.Instance.GetEntities(er);
			return Entities[entityName] as CRMEntity;
		}
		#endregion

		/// <summary>
		/// Cleanup() is called once during test execution after
		/// test methods in this class have executed unless the
		/// corresponding Initialize() call threw an exception.
		/// </summary>
		[TestCleanup]
		public virtual void Cleanup()
		{
			if (m_user == null)
			{
				return;
			}

			EntityManager.Instance.FreeUser(m_user);
		}
	}
}
