﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting Contact entity
	/// </summary>
	[TestClass]
	public class ContactCRUDUnitTest : UnitTestBase
	{
		#region Create an account
		/// <summary>
		/// Test creating an contact
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_Contact()
		{
			//create an contact
			Guid contactId = Guid.Empty;
			Entity contact = new Entity("contact");
			contact["firstname"] = Utils.GetRandomString(5, 10);
			contact["lastname"] = Utils.GetRandomString(5, 10);

			TestContext.BeginTimer("Contact Create Unit Test");
			try
			{
				contactId = Proxy.Create(contact);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Contact Create Unit Test");

			//add the contact to EMDB
			Guid g = EntityManager.Instance.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Contacts, g, new string[] { "OwnerId", "ContactID", "EntityManagerOwningUser" }, new string[] { m_user["systemuserid"], contactId.ToString(), g.ToString() });

		}
		#endregion

		#region Retrieve an account
		/// <summary>
		/// Retrieve an account
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_Contact()
		{
			CRMEntity m_contact = RetrieveTestEntity(m_user, EntityNames.Contacts);
			Entity contact = new Entity("contact");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "lastname", "jobtitle" });
			TestContext.BeginTimer("Contact Retrieve Unit Test");
			try
			{
				contact = Proxy.Retrieve(contact.LogicalName, new Guid(m_contact["contactId"]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			
			TestContext.EndTimer("Contact Retrieve Unit Test");
			
		}
		#endregion

		#region Update an account
		/// <summary>
		/// Test retrieving and updating an contact
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_Contact()
		{
			Entity contact = new Entity("contact");
			//find a CRM Entity for update test
			CRMEntity m_contact = RetrieveTestEntity(m_user, EntityNames.Contacts, new Hashtable() {{"LastName", "updatable"}});
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "firstname", "lastname" });
			//get the contact in CRM
			contact = Proxy.Retrieve(contact.LogicalName, new Guid(m_contact["contactId"]), attributes);
			//update contact address city value
			contact["jobtitle"] = Utils.GetRandomString(3, 10);
			//update the contact
			TestContext.BeginTimer("Contact Update Unit Test");
			try
			{
				Proxy.Update(contact);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			
		}
		#endregion

		#region Delete an account
		
		/// <summary>
		/// test deleting an contact
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_Contact()
		{
			CRMEntity m_contact = RetrieveTestEntity(m_user, EntityNames.Contacts, new Hashtable() { { "LastName", "deletable" } });
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Contact Delete Unit Test");
			try
			{
				Proxy.Delete("contact", new Guid(m_contact["contactId"]));

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			//delete the contact from EMDB
			EntityManager.Instance.DeleteEntity(m_contact);

		}
		#endregion

		#region Retrieve multiple accounts
		/// <summary>
		/// Retrieve multiple accounts
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_Contacts()
		{
			Entity contact = new Entity("contact");
			QueryExpression query = new QueryExpression("contact");
			query.ColumnSet.AddColumn("firstname");
			query.ColumnSet.AddColumn("lastname");
			query.ColumnSet.AddColumn("telephone1");
			query.Criteria.AddCondition("telephone1", ConditionOperator.Like, "%(206)%");
			query.Criteria.AddCondition("description", ConditionOperator.NotNull);

			EntityCollection results;
			TestContext.BeginTimer("Contact RetrieveMultiple Unit Test");
			try
			{
				results = Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}

		}
		#endregion

	}
}
