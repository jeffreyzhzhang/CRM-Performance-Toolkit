﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	//test RetrieveAvailableLanguagesRequest
	[TestClass]
	public class RetrieveAvailableLanguagesRequestUnitTest : UnitTestBase
	{
		#region Retrieve available language request
		/// <summary>
		/// Test retrieving available language
		/// </summary>
		[TestMethod]
		public void UnitTest__RetrieveAvailableLanguagesRequest()
		{
			//create RetrieveAvailableLanguagesRequest
			RetrieveAvailableLanguagesRequest req = new RetrieveAvailableLanguagesRequest();

			//execute the request
			TestContext.BeginTimer("RetrieveAvailableLanguagesRequest Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveAvailableLanguagesRequest Unit Test");
		}
		#endregion

	}
}
