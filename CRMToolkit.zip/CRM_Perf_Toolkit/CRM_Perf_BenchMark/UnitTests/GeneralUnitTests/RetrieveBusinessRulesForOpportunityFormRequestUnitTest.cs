﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages.Internal;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class RetrieveBusinessRulesForOpportunityFormRequestUnitTest : UnitTestBase
	{

		[TestMethod]
		public void UnitTest__RetrieveBusinessRulesForOpportunityFormRequest()
		{
			//create RetrieveBusinessRulesForFormRequest Request 
			RetrieveBusinessRulesForFormRequest req = new RetrieveBusinessRulesForFormRequest();
			// Retrieve Rules for Opportunity Entity
			req.EntityTypeCode = 3;
			req.FormId = Guid.NewGuid();

			//execute the request
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("RetrieveBusinessRulesForFormRequest (Opportunity) Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveBusinessRulesForFormRequest (Opportunity) Unit Test");

		}


	}
}
