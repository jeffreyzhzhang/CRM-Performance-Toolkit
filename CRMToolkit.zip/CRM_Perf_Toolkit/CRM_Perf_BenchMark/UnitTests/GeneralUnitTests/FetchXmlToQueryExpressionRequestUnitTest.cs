﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	//test FetchXMLToQueryExpression request
	[TestClass]
	public class FetchXmlToQueryExpressionRequestUnitTest : UnitTestBase
	{
		#region Fetch xml to query expression request
		/// <summary>
		/// test fetching xml to query expression request
		/// </summary>
		[TestMethod()]
		public void UnitTest__FetchXmlToQueryExpressionRequest()
		{
			FetchXmlToQueryExpressionRequest req = new FetchXmlToQueryExpressionRequest();
			//sample test xml file
			StringBuilder xmlSB = new StringBuilder();
			xmlSB.Append("<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>");
			xmlSB.Append("<entity name='account'>");
			xmlSB.Append("<attribute name='name' /> ");
			xmlSB.Append("<attribute name='accountid' /> ");
			xmlSB.Append("<order attribute='name' descending='false' /> ");
			xmlSB.Append("<filter type='and'>");
			xmlSB.Append("<condition attribute='statecode' operator='eq' value='0' /> ");
			xmlSB.Append("</filter>");
			xmlSB.Append("</entity>");
			xmlSB.Append("</fetch>");

			req.FetchXml = xmlSB.ToString();
			//execute the associate request
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("FetchXMLToQuery Unit Test");
			try
			{
				FetchXmlToQueryExpressionResponse resp = (FetchXmlToQueryExpressionResponse)Proxy.Execute(req);
			}
			catch (FaultException<IOrganizationService> fe)
			{
				Trace.WriteLine(fe.Detail);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			
			TestContext.EndTimer("FetchXMLToQuery Unit Test");

		}
		#endregion

	}
}
