﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{

	[TestClass]
	public class RetrieveUserPrivilegesRequestUnitTest : UnitTestBase
	{
		#region Retrieve user privilege
		/// <summary>
		/// Test retrieving user privilege
		/// </summary>
		[TestMethod]
		public void UnitTest__RetrieveUserPrivilegesRequest()
		{
			//create RetrieveUserPrivilegesRequest
			RetrieveUserPrivilegesRequest req = new RetrieveUserPrivilegesRequest();
			req.UserId = new Guid(m_user["systemuserid"]);

			//execute the request
			TestContext.BeginTimer("RetrieveUserPrivilegesRequest Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveUserPrivilegesRequest Unit Test");
		}
		#endregion
	}
}
