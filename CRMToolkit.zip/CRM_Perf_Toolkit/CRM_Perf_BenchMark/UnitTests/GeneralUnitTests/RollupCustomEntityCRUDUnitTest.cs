using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit Testcases for creating, updating, retrieving and deleting customopportunities
	/// </summary>
	[TestClass]
	public class RollupCustomOpportunityCRUDUnitTest : UnitTestBase
	{
		[TestInitialize]
		public override void Initialize()
		{
			//Rollup DB Populator generates the record in the custom entity tables which are mapped to "System Administrator" role. 
			//Hence setting the UserRole as "System Administrator" and user(DomainName) to "administrator".
			TestContext.Properties["UserRole"] = "System Administrator";			
			TestContext.Properties["DomainName"] = "administrator";
			base.Initialize();
		}

		#region Create
		/// <summary>
		/// Create
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_customopportunity()
		{
			//create a customopportunity
			Guid customopportunityId = Guid.Empty;
			Entity customopportunity = new Entity(_entityLogicalName);
			customopportunity[_primaryNameAttribute] = Utils.GetRandomString(5, 30);
			customopportunity["new_actualrevenue"] = new Microsoft.Xrm.Sdk.Money(1);
			customopportunity["new_estimatedrevenue"] = new Microsoft.Xrm.Sdk.Money(1);

			try
			{
				System.Collections.Hashtable filter = new System.Collections.Hashtable()
				{
					{ _primaryNameAttribute, "customopportunityName"}
				};

				CRMEntity m_customaccount = RetrieveTestEntity(m_user, EntityNames.New_CustomAccount, filter);
				if (m_customaccount != null)
				{
					Guid parentEntityId = new Guid(m_customaccount[_parentPrimaryKeyAttribute]);
					customopportunity[_parentingAttribute] = new EntityReference(_parentEntityLogicalName, parentEntityId);
				}
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Create_customopportunity: Could not find any customaccount therefore not setting customopportunity parent");
			}
			TestContext.BeginTimer("customopportunity Create UnitTest");
			try
			{
				customopportunityId = Proxy.Create(customopportunity);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("customopportunity Create UnitTest");

			//add the customopportunity to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.New_CustomOpportunity, g, new string[] { "OwnerId", _primaryKeyAttribute, _primaryNameAttribute, "EntityManagerOwningUser" }, new string[] { m_user["systemuserid"], customopportunityId.ToString(), customopportunity[_primaryNameAttribute].ToString(), g.ToString() });
		}

		#endregion

		#region Retrieve an customopportunity
		/// <summary>
		/// Retrieve an customopportunity
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_customopportunity()
		{
			CRMEntity m_customopportunity = null;
			try
			{
				System.Collections.Hashtable filter = new System.Collections.Hashtable()
				{
					{ _primaryNameAttribute, "customopportunityName"}
				};
				m_customopportunity = RetrieveTestEntity(m_user, EntityNames.New_CustomOpportunity, filter);
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Retrieve_customopportunity: Could not find any customopportunity therefore exiting the unit test");
			}

			if (m_customopportunity == null) return;

			Entity customopportunity = new Entity(_entityLogicalName);
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { _primaryNameAttribute, "ownerid" });
			TestContext.BeginTimer("customopportunity Retrieve UnitTest");
			try
			{
				customopportunity = Proxy.Retrieve(customopportunity.LogicalName, new Guid(m_customopportunity[_primaryKeyAttribute]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("customopportunity Retrieve UnitTest");

		}
		#endregion

		private string _entityLogicalName = "new_customopportunity";
		private string _primaryNameAttribute = "new_name";
		private string _primaryKeyAttribute = "new_customopportunityid";
		private string _parentingAttribute = "new_customerid";

		private string _parentEntityLogicalName = "new_customaccount";
		private string _parentPrimaryKeyAttribute = "new_customaccountid";

		#region Updatea an customopportunity
		/// <summary>
		/// Update an customopportunity
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_customopportunity()
		{
			Entity customopportunity = new Entity(_entityLogicalName);
			CRMEntity m_customopportunity = null;
			try
			{
				System.Collections.Hashtable filter = new System.Collections.Hashtable()
				{
					{ _primaryNameAttribute, "customopportunityName"}
				};

				m_customopportunity = RetrieveTestEntity(m_user, EntityNames.New_CustomOpportunity, filter);
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Update_customopportunity: Could not find any customopportunity therefore exiting the testcase");
			}

			if (m_customopportunity == null) return;

			customopportunity.Id = new Guid(m_customopportunity[_primaryKeyAttribute]);


			CRMEntity m_customaccount = null;
			try
			{
				m_customaccount = RetrieveTestEntity(m_user, EntityNames.New_CustomAccount);
				if (m_customaccount != null)
				{
					Guid parentEntityId = new Guid(m_customaccount[_parentPrimaryKeyAttribute]);
					customopportunity[_parentingAttribute] = new EntityReference(_parentEntityLogicalName, parentEntityId);
				}
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Update_customopportunity: Could not find any customaccount to set the parent");
			}


			//update the customopportunity
			TestContext.BeginTimer("customopportunity Update UnitTest");
			try
			{
				Proxy.Update(customopportunity);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("customopportunity Update UnitTest");
		}
		#endregion

		#region Delete an customopportunity
		/// <summary>
		/// Delete an customopportunity
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_customopportunity()
		{
			CRMEntity m_customopportunity = null;
			try
			{
				System.Collections.Hashtable filter = new System.Collections.Hashtable()
				{
					{ _primaryNameAttribute, "deletable"}
				};
				m_customopportunity = RetrieveTestEntity(m_user, EntityNames.New_CustomOpportunity, filter);
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Delete_customopportunity: Could not find any customopportunity to delete. exiting.");
			}

			if (m_customopportunity == null) return;

			TestContext.BeginTimer("customopportunity Delete UnitTest");
			try
			{
				Proxy.Delete(_entityLogicalName, new Guid(m_customopportunity[_primaryKeyAttribute]));
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("customopportunity Delete UnitTest");
			//delte the test customopportunity from EMDB
			EntityManager.Instance.DeleteEntity(m_customopportunity);
		}
		#endregion

		#region Retreive multiple customopportunitys
		/// <summary>
		/// Retrieve multiple customopportunitys
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_customopportunity()
		{
			Entity customopportunity = new Entity(_entityLogicalName);

			QueryExpression query = new QueryExpression(_entityLogicalName);
			query.ColumnSet.AddColumn(_primaryNameAttribute);
			query.TopCount = 5000;

			TestContext.BeginTimer("customopportunity RetrieveMultiple UnitTest");
			try
			{
				var results = Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("customopportunity RetrieveMultiple UnitTest");
		}
		#endregion
	}

	/// <summary>
	/// Unit Testcases for creating, updating, retrieving and deleting CustomAccounts
	/// </summary>
	[TestClass]
	public class RollupCustomAccountCRUDUnitTest : UnitTestBase
	{
		[TestInitialize]
		public override void Initialize()
		{
			//Rollup DB Populator generates the record in the custom entity tables which are mapped to "System Administrator" role. 
			//Hence setting the UserRole as "System Administrator" and user(DomainName) to "administrator".
			TestContext.Properties["UserRole"] = "System Administrator";
			TestContext.Properties["DomainName"] = "administrator";
			base.Initialize();
		}

		#region Create
		/// <summary>
		/// Create
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_customaccount()
		{
			//create a customaccount
			Guid customaccountId = Guid.Empty;
			Entity customaccount = new Entity(_entityLogicalName);
			customaccount[_primaryNameAttribute] = Utils.GetRandomString(5, 30);

			try
			{
				System.Collections.Hashtable filter = new System.Collections.Hashtable()
				{
					{ _primaryNameAttribute, "customaccountName"}
				};

				CRMEntity m_customaccount = RetrieveTestEntity(m_user, EntityNames.New_CustomAccount, filter);
				if (m_customaccount != null)
				{
					Guid parentEntityId = new Guid(m_customaccount[_primaryKeyAttribute]);
					customaccount[_parentingAttribute] = new EntityReference(_entityLogicalName, parentEntityId);
				}
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Create_customaccount: Could not find any customaccount therefore not setting customaccount parent");
			}

			TestContext.BeginTimer("customaccount Create UnitTest");
			try
			{
				customaccountId = Proxy.Create(customaccount);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer("customaccount Create UnitTest");

			//add the customaccount to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.New_CustomAccount, g, new string[] { "OwnerId", _primaryKeyAttribute, _primaryNameAttribute, "EntityManagerOwningUser" }, new string[] { m_user["systemuserid"], customaccountId.ToString(), customaccount[_primaryNameAttribute].ToString(), g.ToString() });
		}

		#endregion

		#region Retrieve an customaccount
		/// <summary>
		/// Retrieve an customaccount
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_customaccount()
		{
			CRMEntity m_customaccount = null;
			try
			{
				System.Collections.Hashtable filter = new System.Collections.Hashtable()
				{
					{ _primaryNameAttribute, "customaccountName"}
				};
				m_customaccount = RetrieveTestEntity(m_user, EntityNames.New_CustomAccount, filter);
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Retrieve_customaccount: Could not find any customaccount therefore exiting the unit test");
			}

			if (m_customaccount == null) return;

			Entity customaccount = new Entity(_entityLogicalName);
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { _primaryNameAttribute, "ownerid" });
			TestContext.BeginTimer("customaccount Retrieve UnitTest");
			try
			{
				customaccount = Proxy.Retrieve(customaccount.LogicalName, new Guid(m_customaccount[_primaryKeyAttribute]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("customaccount Retrieve UnitTest");

		}
		#endregion

		private string _entityLogicalName = "new_customaccount";
		private string _primaryNameAttribute = "new_name";
		private string _primaryKeyAttribute = "new_customaccountid";
		private string _parentingAttribute = "new_parentid";

		#region Updatea an customaccount
		/// <summary>
		/// Update an customaccount
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_customaccount()
		{
			Entity customaccount = new Entity(_entityLogicalName);
			CRMEntity m_customaccount = null;
			try
			{
				System.Collections.Hashtable filter = new System.Collections.Hashtable()
				{
					{ _primaryNameAttribute, "customaccountName"}
				};
				m_customaccount = RetrieveTestEntity(m_user, EntityNames.New_CustomAccount, filter);
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Update_customaccount: Could not find any customaccount therefore exiting the testcase");
			}

			if (m_customaccount == null) return;


			customaccount.Id = new Guid(m_customaccount[_primaryKeyAttribute]);

			try
			{
				int loopCount = 0;
				while (loopCount++ < 10)
				{
					CRMEntity m_parentaccount = RetrieveTestEntity(m_user, EntityNames.New_CustomAccount);
					if (m_parentaccount != null)
					{
						Guid parentEntityId = new Guid(m_parentaccount[_primaryKeyAttribute]);
						if (parentEntityId != customaccount.Id)
						{
							customaccount[_parentingAttribute] = new EntityReference(_entityLogicalName, parentEntityId);
							break;
						}
					}
				}
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Update_customaccount: Could not find any customaccount to set the parent");
			}

			//update the customaccount
			TestContext.BeginTimer("customaccount Update UnitTest");
			try
			{
				Proxy.Update(customaccount);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("customaccount Update UnitTest");
		}
		#endregion

		#region Delete an customaccount
		/// <summary>
		/// Delete an customaccount
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_customaccount()
		{
			CRMEntity m_customaccount = null;
			try
			{
				System.Collections.Hashtable filter = new System.Collections.Hashtable()
				{
					{ _primaryNameAttribute, "deletable"}
				};
				m_customaccount = RetrieveTestEntity(m_user, EntityNames.New_CustomAccount, filter);
			}
			catch (EntityNotFoundException)
			{
				Trace.WriteLine("UnitTest__Delete_customaccount: Could not find any customaccount to delete. exiting.");
			}

			if (m_customaccount == null) return;

			TestContext.BeginTimer("customaccount Delete UnitTest");
			try
			{
				Proxy.Delete(_entityLogicalName, new Guid(m_customaccount[_primaryKeyAttribute]));

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("customaccount Delete UnitTest");
			//delte the test customaccount from EMDB
			EntityManager.Instance.DeleteEntity(m_customaccount);
		}
		#endregion

		#region Retreive multiple customaccounts
		/// <summary>
		/// Retrieve multiple customaccounts
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_customaccount()
		{
			Entity customaccount = new Entity(_entityLogicalName);

			QueryExpression query = new QueryExpression(_entityLogicalName);
			query.ColumnSet.AddColumn(_primaryNameAttribute);
			query.TopCount = 5000;

			TestContext.BeginTimer("customaccount RetrieveMultiple UnitTest");
			try
			{
				var results = Proxy.RetrieveMultiple(query);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("customaccount RetrieveMultiple UnitTest");
		}
		#endregion
	}
}
