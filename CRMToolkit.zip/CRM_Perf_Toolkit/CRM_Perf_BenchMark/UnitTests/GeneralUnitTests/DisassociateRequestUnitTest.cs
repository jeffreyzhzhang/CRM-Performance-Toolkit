﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	//unit test for disassociating request
	[TestClass]
	public class DisassociateRequestUnitTest : UnitTestBase
	{
		#region Disassociate Request UnitTest
		[TestMethod()]
		public void UnitTest__DisassociateRequest()
		{
			CRMEntity m_account = RetrieveTestEntity(m_user, EntityNames.Accounts);
			CRMEntity m_contact = RetrieveTestEntity(m_user, EntityNames.Contacts);
			//create an associate request which links an account to a contact
			Microsoft.Xrm.Sdk.Messages.DisassociateRequest disassociateRequest = new Microsoft.Xrm.Sdk.Messages.DisassociateRequest();
			disassociateRequest.Target = new EntityReference("account", new Guid(m_account["accountid"]));
			disassociateRequest.RelatedEntities = new EntityReferenceCollection();
			disassociateRequest.RelatedEntities.Add(new EntityReference("contact", new Guid(m_contact["contactid"])));

			//todo: retrieve the relationship entity from EMDB
			disassociateRequest.Relationship = new Relationship("contact_customer_accounts");

			//execute the associate request
			TestContext.BeginTimer("Disassociate Request Unit Test");
			try
			{
				Proxy.Execute(disassociateRequest);

			}
			catch (FaultException<IOrganizationService> fe)
			{
				Trace.WriteLine(fe.Detail);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Disassociate Request Unit Test");

		}
		#endregion

	}
}
