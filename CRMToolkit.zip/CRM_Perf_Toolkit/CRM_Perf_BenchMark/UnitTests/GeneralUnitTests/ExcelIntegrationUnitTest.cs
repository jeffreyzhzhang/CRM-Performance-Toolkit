﻿namespace CRM_Perf_BenchMark.UnitTests
{
	using System;
	using System.Diagnostics;
	using System.ServiceModel;
	using Microsoft.Crm.Sdk.Messages;
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using Microsoft.Xrm.Sdk;
	using Microsoft.Xrm.Sdk.Query;

	[TestClass]
	public class ExcelIntegrationUnitTest : UnitTestBase
	{
		/// <summary>
		/// Test Export To Excel
		/// </summary>
		[TestMethod()]
		public void UnitTest__ExportToExcel()
		{
			Entity query = this.Proxy.Retrieve("savedquery", Guid.Parse("00000000-0000-0000-00AA-000010003001"), new ColumnSet("fetchxml", "layoutxml"));
			
			OrganizationRequest request = new OrganizationRequest();
			request.RequestName = "ExportToExcel";
			request.Parameters.Add("FetchXml", query["fetchxml"]);
			request.Parameters.Add("LayoutXml", query["layoutxml"]);
			request.Parameters.Add("View", new EntityReference("savedquery", Guid.Parse("00000000-0000-0000-00AA-000010003001")));
			request.Parameters.Add("QueryApi", string.Empty);
			request.Parameters.Add("QueryParameters", new InputArgumentCollection());
			
			TestContext.BeginTimer("ExportToExcelUnitTest");
			
			try
			{
				OrganizationResponse response = Proxy.Execute(request);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}

			TestContext.EndTimer("ExportToExcelUnitTest");
		}
	}
}