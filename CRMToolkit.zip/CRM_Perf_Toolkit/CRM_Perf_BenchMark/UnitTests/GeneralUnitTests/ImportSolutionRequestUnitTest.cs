﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;
using Microsoft.Win32;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	//Marco test case for solution importing
	//1. Record time before importing
	//2. Import standard solution MattB_Examples_AddressValidation from <toolKitDir>\CRM_Perf_Toolkit\ImportCustomization\Sample_Xmls\
	//3. Record time after importing
	// In case of importing fails, log execpetion and then rethrow
	[TestClass]
	public class ImportSolutionRequestUnitTest : UnitTestBase
	{
		private const string solutionUniqueName = "MattB_Examples_AddressValidation";
		private string ManagedSolutionLocation;
		private string solutionFileFullName;

		public ImportSolutionRequestUnitTest()
		{
			string toolKitDir = GetCRMToolKitDir();
			if (!Directory.Exists(toolKitDir))
			{
				throw new ApplicationException(string.Format("Cannot find CRM Toolkit directory {0}", toolKitDir));
			}

			ManagedSolutionLocation = string.Format("{0}{1}", toolKitDir, @"\CRM_Perf_Toolkit\ImportCustomization\Sample_Xmls\");
			solutionFileFullName = string.Format("{0}{1}{2}", ManagedSolutionLocation, solutionUniqueName, "_1_2_managed.zip");
		}

		[TestMethod]
		public void UnitTest__ImportSolutionRequest()
		{
			//import the standard macro test solution
			DateTime start;
			DateTime end;

			try
			{
				byte[] fileBytes = File.ReadAllBytes(solutionFileFullName);

				ImportSolutionRequest impSolReq = new ImportSolutionRequest()
				{
					CustomizationFile = fileBytes
				};

				start = DateTime.UtcNow;

				TestContext.BeginTimer("ImportSolutionRequest Unit Test");

				Proxy.Execute(impSolReq);
				//Add EndTimer inside try block as we don't want to count in the execution time in the final  block below
				TestContext.EndTimer("ImportSolutionRequest Unit Test");
				end = DateTime.UtcNow;
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			catch (Exception ex)
			{
				Trace.WriteLine(ex.Message);
				throw;
			}

			TimeSpan duration = (end - start);

			StringBuilder summaryFileSB = new StringBuilder();
			string resultDir = string.Format(@"{0}\PerfResult", Environment.SystemDirectory.Split(new char[] { '\\' }, 2)[0]);
			summaryFileSB.Append(resultDir);
			summaryFileSB.Append(String.Format(@"\Perf_ImportSolution_Summary_"));
			summaryFileSB.Append(System.DateTime.Now.Ticks.ToString());
			summaryFileSB.Append(".log");
			SummaryFile = summaryFileSB.ToString();

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for ImportSolutionRequest execution ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("User id for this test is " + m_user["systemuserid"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Imported Solution from {0}", solutionFileFullName);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}

		}

		//delete a solution
		private void deleteSolution()
		{
			//cleanup: delete the test solution from the system
			QueryExpression queryImportedSolution = new QueryExpression
			{
				EntityName = "solution",
				ColumnSet = new ColumnSet(new string[] { "solutionid", "friendlyname" }),
				Criteria = new FilterExpression()
			};

			queryImportedSolution.Criteria.AddCondition("uniquename", ConditionOperator.Equal, solutionUniqueName);
			Entity solution = new Entity("solution");
			solution = Proxy.RetrieveMultiple(queryImportedSolution).Entities[0];
			Proxy.Delete(solution.LogicalName, (Guid)solution.Attributes["solutionid"]);
		}

		private string GetCRMToolKitDir()
		{
			string configDirKeyPath = "SOFTWARE\\Wow6432Node\\Microsoft\\MSCRMToolkit";
			string configDir = null;

			if (Registry.LocalMachine.OpenSubKey(configDirKeyPath) != null)
			{
				RegistryKey regKey = Registry.LocalMachine.OpenSubKey(configDirKeyPath);
				configDir = (string)regKey.GetValue("CRM_Perf_Toolkit_ConfigDir", Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles");
			}
			else
			{
				//setting the default directory of configsettings.xml
				configDir = Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles";
			}

			DirectoryInfo di = new DirectoryInfo(configDir);
			return di.Parent.FullName;
		}

		#region test cleanup
		/// <summary>
		/// Cleanup() is called once during test execution after
		/// test methods in this class have executed unless the
		/// corresponding Initialize() call threw an exception.
		/// </summary>
		[TestCleanup()]
		public override void Cleanup()
		{
			//we need a valid user to run
			if (m_user == null)
				return;

			try
			{
				deleteSolution();
			}
			catch (Exception ex)
			{
				Trace.WriteLine("Cleanup: Deleting solution fails with {0}", ex.Message);
			}

			base.Cleanup();
		}
		#endregion
	}
}
