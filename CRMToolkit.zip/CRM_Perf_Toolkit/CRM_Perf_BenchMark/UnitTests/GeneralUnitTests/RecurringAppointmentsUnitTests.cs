﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using CRM_Perf_BenchMark;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class RecurringAppointmentsUnitTests : UnitTestBase
	{
		CRMEntity ram;
		CRMEntity appointmentInstance;
		CRMEntity[] users;
		string recurringAppointmentAppendable = null;


		private static string resultDir = Environment.SystemDirectory.Split(new char[] { '\\' }, 2)[0] + @"\PerfResult";

		private readonly int PARTYCOUNT = 5;
		private readonly int PARTYUPDATECOUNT = 2;

		[TestInitialize]
		public override void Initialize()
		{
			base.Initialize();
			EntityRequest userRequest = new EntityRequest();
			userRequest.Type = EntityNames.Users;
			userRequest.ParentID = new Guid(m_user[EntityIDNames.Organization]);
			userRequest.ReturnAs = EntityNames.Users;

			System.Collections.Hashtable userProps = new System.Collections.Hashtable();
			userProps.Add(EntityNames.Users, new EntityRequest[] { userRequest });

			users = EntityManager.Instance.GetAllRecordsForEntity(userRequest, PARTYCOUNT);

		}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		[ClassInitialize()]
		public static void ClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
			}
		}


		// Use TestCleanup to run code after each test has run
		[TestCleanup()]
		public void TestCleanup()
		{
			//EntityManager.Instance.FreeEntity(m_user);
		}

		#endregion

		#region Individual Test Cases

		[TestMethod()]
		public void UnitTest_CreateDailyRecurringAppointment()
		{
			string timestamp = System.DateTime.Now.Ticks.ToString();
			string SummaryFile = string.Format(@"{0}\Perf_RecurringAppointments_Create_Summary_{1}.log", resultDir, timestamp);
			DateTime start = DateTime.UtcNow;
			Guid masterId = CreateRecurringAppointment();
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Recurring Appointment creation ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Recurring appointment id for this test is " + masterId);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Synchronous Expansion took {0} milisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.RecurringAppointments, g, new string[] { "OwnerId", "ActivityID", "EntityManagerOwningUser", "Subject", "RecurrencePatternType" }, new string[] { m_user["systemuserid"], masterId.ToString(), g.ToString(), recurringAppointmentAppendable + "recurring deletable", "0" });
		}

		[TestMethod()]
		public void UnitTest_CreateWeeklyRecurringAppointment()
		{
			string timestamp = System.DateTime.Now.Ticks.ToString();
			string SummaryFile = string.Format(@"{0}\Perf_WeeklyRecurringAppointments_Create_Summary_{1}.log", resultDir, timestamp);
			DateTime start = DateTime.UtcNow;
			Guid masterId = CreateRecurringAppointment(RecurrencePattern.Weekly, DateTime.UtcNow.AddMonths(-6), DateTime.MaxValue);
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Recurring Appointment creation ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Recurring appointment id for this test is " + masterId);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Synchronous Expansion took {0} milisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		[TestMethod()]
		public void UnitTest_UpdateRecurringAppointmentBasicInformation()
		{
			System.Collections.Hashtable props = ExchangeSyncLoadMapper.UpdateRecurringAppointmentFilter();
			bool exchangeSync = true;
			if (props == null)
			{
				exchangeSync = false;
				props = new System.Collections.Hashtable() {{"subject", "recurring updatable"}};
			}

			ram = RetrieveTestEntity(m_user, EntityNames.RecurringAppointments, props);
			string timestamp = System.DateTime.Now.Ticks.ToString();
			string SummaryFile = string.Format(@"{0}\Perf_UpdateRecurringAppointmentsBasicInformation_Summary_{1}.log", resultDir, timestamp);

			DateTime start = DateTime.UtcNow;
			UpdateRecurringAppointmentBasicInformation(ram,(exchangeSync? ExchangeSyncLoadMapper.Identifier: ""));
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Recurring Appointment updation (basic info) ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Recurring appointment id for this test is " + ram["activityid"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Synchronous update took {0} milisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		[TestMethod()]
		public void UnitTest_UpdateRecurringAppointmentRecurrenceInformation()
		{
			System.Collections.Hashtable props = ExchangeSyncLoadMapper.UpdateRecurringAppointmentFilter();
			if (props == null)
			{
				props = new System.Collections.Hashtable() {{"subject", "recurring updatable"}};
			}

			ram = RetrieveTestEntity(m_user, EntityNames.RecurringAppointments, props);
			string timestamp = System.DateTime.Now.Ticks.ToString();
			string SummaryFile = string.Format(@"{0}\Perf_UpdateRecurringAppointmentRecurrenceInformation_Summary_{1}.log", resultDir, timestamp);

			DateTime start = DateTime.UtcNow;
			UpdateRecurringAppointmentRecurrenceInformation(ram);
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Recurring Appointment updation (recurrence info) ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Recurring appointment id for this test is " + ram["activityid"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Synchronous update took {0} milisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		[TestMethod()]
		public void UnitTest_DeleteRecurringAppointment()
		{
			ram = RetrieveTestEntity(m_user, EntityNames.RecurringAppointments, new System.Collections.Hashtable() { { "subject", "recurring deletable" } });

			string timestamp = System.DateTime.Now.Ticks.ToString();
			string SummaryFile = string.Format(@"{0}\Perf_DeleteRecurringAppointment_Summary_{1}.log", resultDir, timestamp);

			DateTime start = DateTime.UtcNow;
			try
			{
				//Proxy.Delete("recurringappointmentmaster", new Guid(ram["activityid"]));
				Proxy.Delete(EntityNames.RecurringAppointments.ToLower(), new Guid(ram["activityid"]));
			}
			catch (FaultException<IOrganizationService> e)
			{
				Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException ex)
			{
				Trace.Write(ex.Detail + ex.StackTrace);
				throw ex;
			}
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Recurring Appointment deletion ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Recurring appointment id for this test is " + ram["activityid"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Synchronous Delete took {0} milisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}

			EntityManager.Instance.DeleteEntity(ram);
		}

		[TestMethod()]
		public void UnitTest_TerminateRecurringAppointment()
		{
			ram = RetrieveTestEntity(m_user, EntityNames.RecurringAppointments, new System.Collections.Hashtable() { { "subject", "deletable" } });

			string timestamp = System.DateTime.Now.Ticks.ToString();
			string SummaryFile = string.Format(@"{0}\Perf_TerminateRecurringAppointment_Summary_{1}.log", resultDir, timestamp);

			Entity master = new Entity("recurringappointmentmaster");
			master["activityid"] = new Guid(ram["activityid"]);

			DeleteOpenInstancesRequest snipSeriesRequest = new DeleteOpenInstancesRequest();
			snipSeriesRequest.Target = master;
			snipSeriesRequest.SeriesEndDate = DateTime.Now;
			snipSeriesRequest.StateOfPastInstances = 0;

			DeleteOpenInstancesResponse snipSeriesResponse = null;

			DateTime start = DateTime.UtcNow;
			try
			{
				TestContext.BeginTimer("RecurringAppointment Terminate Unit Test");
				snipSeriesResponse = (DeleteOpenInstancesResponse)Proxy.Execute(snipSeriesRequest);
				TestContext.EndTimer("RecurringAppointment Terminate Unit Test");
			}
			catch (FaultException<IOrganizationService> e)
			{
				Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException ex)
			{
				Trace.Write(ex.Detail + ex.StackTrace);
				throw ex;
			}
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Recurring Appointment termination ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Recurring appointment id for this test is " + ram["activityid"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Synchronous termination took {0} milisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}

			EntityManager.Instance.DeleteEntity(ram);
		}

		[TestMethod()]
		public void UnitTest_AssignRecurringAppointment()
		{
			Random random1 = new Random();
			ram = RetrieveTestEntity(m_user, EntityNames.RecurringAppointments, new System.Collections.Hashtable() { { "subject", "deletable" } });

			string timestamp = System.DateTime.Now.Ticks.ToString();
			string SummaryFile = string.Format(@"{0}\Perf_TerminateRecurringAppointment_Summary_{1}.log", resultDir, timestamp);

			AssignRequest assignRequest = new AssignRequest();

			assignRequest.Assignee = new EntityReference("systemuser", new Guid(users[random1.Next(0, users.Length)]["systemuserid"]));
			assignRequest.Target = new EntityReference("recurringappointmentmaster", new Guid(ram["activityid"]));
			AssignResponse assignResponse = null;

			DateTime start = DateTime.UtcNow;
			try
			{
				TestContext.BeginTimer("RecurringAppointment Assign Unit Test");
				assignResponse = (AssignResponse)Proxy.Execute(assignRequest);
				TestContext.EndTimer("RecurringAppointment Assign Unit Test");
			}
			catch (FaultException<IOrganizationService> e)
			{
				Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException ex)
			{
				Trace.Write(ex.Detail + ex.StackTrace);
				throw ex;
			}
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Recurring Appointment assign ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Recurring appointment id for this test is " + ram["activityid"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Synchronous assign took {0} milisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		[TestMethod()]
		public void UnitTest_UpdateRecurringAppointmentInstance()
		{
			appointmentInstance = RetrieveTestEntity(m_user, EntityNames.Appointments, new System.Collections.Hashtable() { { "subject", "updatable" }, { "instancetypecode", "2" } });

			string timestamp = System.DateTime.Now.Ticks.ToString();
			string SummaryFile = string.Format(@"{0}\Perf_UpdateRecurringAppointmentInstance_Summary_{1}.log", resultDir, timestamp);

			Entity newInstance = new Entity("appointment");
			newInstance["activityid"] = new Guid(appointmentInstance["activityid"]);

			newInstance["location"] = "New location";
			newInstance["subject"] = "New topic recurring updatable";

			DateTime start = DateTime.UtcNow;
			try
			{
				TestContext.BeginTimer("RecurringAppointment Update Unit Test");
				Proxy.Update(newInstance);
				TestContext.EndTimer("RecurringAppointment Update Unit Test");
			}
			catch (FaultException<IOrganizationService> e)
			{
				Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException ex)
			{
				Trace.Write(ex.Detail + ex.StackTrace);
				throw ex;
			}
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Recurring Appointment instance update ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Appointment instance id for this test is " + newInstance["activityid"].ToString());
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Instance updation took {0} milisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
		}

		[TestMethod()]
		public void UnitTest_DeleteRecurringAppointmentInstance()
		{
			appointmentInstance = RetrieveTestEntity(m_user, EntityNames.Appointments, new System.Collections.Hashtable() { { "subject", "deletable" }, { "instancetypecode", "2" } });

			string timestamp = System.DateTime.Now.Ticks.ToString();
			string SummaryFile = string.Format(@"{0}\Perf_DeleteRecurringAppointmentInstance_Summary_{1}.log", resultDir, timestamp);

			Entity instance = new Entity("appointment");
			instance["activityid"] = new Guid(appointmentInstance["activityid"]);

			DateTime start = DateTime.UtcNow;
			try
			{
				TestContext.BeginTimer("RecurringAppointmentInstance Delete Unit Test");
				Proxy.Delete("appointment", (Guid)instance["activityid"]);
				TestContext.EndTimer("RecurringAppointmentInstance Delete Unit Test");
			}
			catch (FaultException<IOrganizationService> e)
			{
				Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException ex)
			{
				Trace.Write(ex.Detail + ex.StackTrace);
				throw ex;
			}
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test reult for Recurring Appointment instance deletion ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Appointment instance id for this test is " + instance["activityid"].ToString());
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Instance deletion took {0} milisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}

			EntityManager.Instance.DeleteEntity(appointmentInstance);
		}

		#endregion

		#region Private Methods

		private Guid CreateRecurringAppointment(RecurrencePattern recurrencePattern, DateTime patternStart, DateTime patternEnd)
		{
			//Create 
			Entity master = new Entity("recurringappointmentmaster");
			master["subject"] = "New Subject recurring deletable";

			if (recurrencePattern == RecurrencePattern.Daily)
			{
				recurringAppointmentAppendable = ExchangeSyncLoadMapper.CreateRecurringAppointmentAppendable();
				master["subject"] += recurringAppointmentAppendable;
			}
			master["location"] = "New Location";
			master["description"] = "New Description";
			switch (recurrencePattern)
			{
				case RecurrencePattern.Daily:
					master["recurrencepatterntype"] = new OptionSetValue(0); // Picklist(RecurrencePatternType.Daily);
					break;

				case RecurrencePattern.Weekly:
					master["recurrencepatterntype"] = new OptionSetValue(1); // Picklist(RecurrencePatternType.Weekly);
					master["daysofweekmask"] = 10;
					break;

				case RecurrencePattern.Monthly:
					master["recurrencepatterntype"] = new OptionSetValue(2); // Picklist(RecurrencePatternType.Monthly);
					break;

				case RecurrencePattern.Yearly:
					master["recurrencepatterntype"] = new OptionSetValue(3); // Picklist(RecurrencePatternType.Yearly);
					break;

				default:
					master["recurrencepatterntype"] = new OptionSetValue(0); // Picklist(RecurrencePatternType.Daily);
					break;
			}

			master["patternstartdate"] = patternStart;
			if (patternEnd.Equals(DateTime.MaxValue))
			{
				master["patternendtype"] = new OptionSetValue(1); // Picklist(RecurrencePatternEndType.EndTypeNoEndDate);
			}
			else
			{
				master["patternenddate"] = patternEnd;
				master["patternendtype"] = new OptionSetValue(3);
			}

			master["statecode"] = new OptionSetValue(3);// RecurringAppointmentMasterStateInfo();
			master["statuscode"] = new OptionSetValue(-1);

			Random r1 = new Random();
			DateTime start = DateTime.Now + TimeSpan.FromHours(r1.Next(4));
			DateTime end = start += TimeSpan.FromHours(1);
			master["starttime"] = start;
			master["endtime"] = end;


			Entity organizer = new Entity("activityparty");
			organizer["partyid"] = new EntityReference("systemuser", new Guid(m_user["systemuserid"]));
			master["organizer"] = new Entity[] { organizer };

			int actualPartyCount = Math.Min(PARTYCOUNT, users.Length);
			master["requiredattendees"] = new Entity[actualPartyCount];
			for (int i = 0; i < actualPartyCount; i++)
			{
				Entity party = new Entity("activityparty");
				party["partyid"] = new EntityReference("systemuser", new Guid(users[i]["systemuserid"]));

				((Entity[])master["requiredattendees"])[i] = party;
			}

			Guid masterAppointmentId = Guid.Empty;
			try
			{
				TestContext.BeginTimer("RecurringAppointment Create Unit Test");
				masterAppointmentId = Proxy.Create(master);
				TestContext.EndTimer("RecurringAppointment Create Unit Test");


			}
			catch (FaultException<IOrganizationService> e)
			{
				Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException ex)
			{
				Trace.Write(ex.Detail + ex.StackTrace);
				throw ex;
			}

			return masterAppointmentId;
		}

		private Guid CreateRecurringAppointment(RecurrencePattern recurrencePattern, DateTime patternStart, int occurences)
		{
			//Create 
			Entity master = new Entity("recurringappointmentmaster");
			master["subject"] = "New Subject deletable";
			master["location"] = "New Location";
			master["description"] = "New Description";

			if (recurrencePattern == RecurrencePattern.Daily)
			{
				recurringAppointmentAppendable = ExchangeSyncLoadMapper.CreateRecurringAppointmentAppendable();
				master["subject"] += recurringAppointmentAppendable;
			}

			switch (recurrencePattern)
			{
				case RecurrencePattern.Daily:
					master["recurrencepatterntype"] = new OptionSetValue(0); // Picklist(RecurrencePatternType.Daily);
					break;

				case RecurrencePattern.Weekly:
					master["recurrencepatterntype"] = new OptionSetValue(1); // Picklist(RecurrencePatternType.Weekly);
					master["daysofweekmask"] = 10;
					break;

				case RecurrencePattern.Monthly:
					master["recurrencepatterntype"] = new OptionSetValue(2); // Picklist(RecurrencePatternType.Monthly);
					break;

				case RecurrencePattern.Yearly:
					master["recurrencepatterntype"] = new OptionSetValue(3); // Picklist(RecurrencePatternType.Yearly);
					break;

				default:
					master["recurrencepatterntype"] = new OptionSetValue(0); // Picklist(RecurrencePatternType.Daily);
					break;
			}

			master["patternstartdate"] = patternStart;
			master["occurrences"] = occurences;
			master["patternendtype"] = new OptionSetValue(2); // Picklist(RecurrencePatternEndType.EndTypeOccurrences);
			master["statecode"] = new OptionSetValue(0);
			master["statuscode"] = new OptionSetValue(-1);

			Random r1 = new Random();
			DateTime start = DateTime.Now + TimeSpan.FromHours(r1.Next(4));
			DateTime end = start += TimeSpan.FromHours(1);
			master["starttime"] = start;
			master["endtime"] = end;

			Entity organizer = new Entity("activityparty");
			organizer["partyid"] = new EntityReference("systemuser", new Guid(m_user["systemuserid"]));
			master["organizer"] = new Entity[] { organizer };

			int actualPartyCount = Math.Min(PARTYCOUNT, users.Length);
			master["requiredattendees"] = new Entity[actualPartyCount];
			for (int i = 0; i < actualPartyCount; i++)
			{
				Entity party = new Entity("activityparty");
				party["partyid"] = new EntityReference("systemuser", new Guid(users[i]["systemuserid"]));

				((Entity[])master["requiredattendees"])[i] = party;
			}

			Guid masterAppointmentId = Guid.Empty;
			try
			{
				masterAppointmentId = Proxy.Create(master);
			}
			catch (FaultException<IOrganizationService> e)
			{
				Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException ex)
			{
				Trace.Write(ex.Detail + ex.StackTrace);
				throw ex;
			}
			return masterAppointmentId;
		}

		private Guid CreateRecurringAppointment()
		{
			return CreateRecurringAppointment(RecurrencePattern.Daily, DateTime.UtcNow.AddMonths(-6), DateTime.MaxValue);
		}

		private void UpdateRecurringAppointmentRecurrenceInformation(CRMEntity ram)
		{
			Entity master = new Entity("recurringappointmentmaster");
			master["activityid"] = new Guid(ram["activityid"]);

			//Update
			master["recurrencepatterntype"] = new OptionSetValue(1); // Picklist(RecurrencePatternType.Weekly);
			master["daysofweekmask"] = 6;
			master["patternendtype"] = new OptionSetValue(1); // Picklist(RecurrencePatternEndType.EndTypeNoEndDate);
			master["patternstartdate"] = DateTime.Now + TimeSpan.FromDays(-5);
			DateTime start = DateTime.UtcNow.AddHours(-4);
			DateTime end = DateTime.UtcNow.AddHours(-2);
			master["starttime"] = start;
			master["endtime"] = end;

			try
			{
				TestContext.BeginTimer("RecurringAppointmentRecurrenceInformation Update Unit Test");
				Proxy.Update(master);
				TestContext.EndTimer("RecurringAppointmentRecurrenceInformation Update Unit Test");
			}
			catch (FaultException<IOrganizationService> e)
			{
				Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException ex)
			{
				Trace.Write(ex.Detail + ex.StackTrace);
				throw ex;
			}
		}

		private void UpdateRecurringAppointmentBasicInformation(CRMEntity ram, string identifier = "")
		{
			Entity master = new Entity("recurringappointmentmaster");
			master["activityid"] = new Guid(ram["activityid"]);

			//Update
			master["subject"] = Utils.GetRandomString(5, 10) + " updatable" + identifier;
			master["location"] = Utils.GetRandomString(5, 10);
			master["description"] = Utils.GetRandomString(10, 20);

			UpdateParties(master, PARTYUPDATECOUNT);

			try
			{
				TestContext.BeginTimer("RecurringAppointmentBasicInformation Update Unit Test");
				Proxy.Update(master);
				TestContext.EndTimer("RecurringAppointmentBasicInformation Update Unit Test");
			}
			catch (FaultException<IOrganizationService> e)
			{
				Trace.Write(e.Detail + e.StackTrace);
				throw e;
			}
			catch (SoapException ex)
			{
				Trace.Write(ex.Detail + ex.StackTrace);
				throw ex;
			}
		}

		private void UpdateParties(Entity master, int countPartiesToBeChaned)
		{
			int actualCount = Math.Min(countPartiesToBeChaned, users.Length);
			Entity[] optionalAttendees = new Entity[actualCount];

			for (int i = 0; i < actualCount; i++)
			{
				optionalAttendees[i] = new Entity("activityparty");
				optionalAttendees[i]["partyid"] = new EntityReference("systemuser", new Guid(users[i]["systemuserid"]));
			}
			master["optionalattendees"] = optionalAttendees;
		}

		#endregion
	}

	public enum RecurrencePattern
	{
		Daily,
		Weekly,
		Monthly,
		Yearly
	}
}
