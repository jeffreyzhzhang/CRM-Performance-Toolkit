﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;


namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// test CustomOperation
	/// </summary>
	[TestClass]
	public class CustomOperationUnitTest : UnitTestBase
	{
		
		/// <summary>
		/// 1. retrieve a case
		/// 2. call CustomOperation to update case's title
		/// 3. return new title as Output Argument
		/// </summary>
		[TestMethod()]
		public void UnitTest__UpdateAndRetrieve()
		{
			//set input Arguments
			CRMEntity m_incident = RetrieveTestEntity(m_user, EntityNames.Incidents);
			EntityReference target = new EntityReference("incident", new Guid(m_incident[EntityIDNames.Incident]));
			OrganizationRequest req = new OrganizationRequest("new_UpdateAndRetrieve");
			req.Parameters["Target"] = target;
			string caseSubject = Utils.GetRandomString(5, 10);
			req.Parameters["caseSubject"] = caseSubject;
			
			//execute request
			OrganizationResponse response = null;
			TestContext.BeginTimer("UpdateAndRetrieve Unit Test");
			try
			{
				//invoke Custom Operation
				response = Proxy.Execute(req);

				//add EndTimer inside try block as we don't want to count in the execution time in the final block below
				TestContext.EndTimer("UpdateAndRetrieve Unit Test");
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			
			//verification
			string newTitle = response["newCaseTitle"] as string;
			if (!string.IsNullOrEmpty(newTitle))
			{
				Assert.IsTrue(newTitle.Contains(caseSubject));
			}

		}

		/// <summary>
		/// 1. create a Prospect
		/// 2. call CustomOperation QualifyProspect
		/// 2.1 Create a Custom Opportunity based on current Prospect
		/// 2.2 Change current Prospect's status to "Qualified"
		/// 2.3 Make current Prospect to Inactive state
		/// 3. delete this Prospect and Custom Opportunity
		/// </summary>
		[TestMethod()]
		public void UnitTest__QualifyProspect()
		{
			//create a Prospect
			Entity prospect = new Entity("new_coprospect");
			Guid prospectId = Guid.Empty;
			string firstName = Utils.GetRandomString(5, 10);
			string lastName = Utils.GetRandomString(5, 10);
			prospect.Attributes.Add("new_firstname", firstName);
			prospect.Attributes.Add("new_lastname", lastName);
			prospect.Attributes.Add("new_name", firstName + " " + lastName);
			prospectId = Proxy.Create(prospect);

			//set OrganizationRequest for CustomOperation
			EntityReference target = new EntityReference("new_coprospect", prospectId);
			OrganizationRequest req = new OrganizationRequest("new_QualifyProspect");
			req.Parameters["Target"] = target;

			//execute request
			
			TestContext.BeginTimer("QualifyProspect Unit Test");
			try
			{
				//invoke Custom Operation
				Proxy.Execute(req);
				//add EndTimer inside try block as we don't want to count in the execution time in the final block below
				TestContext.EndTimer("QualifyProspect Unit Test");
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
		}
	}
}
