﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting task entity
	/// </summary>
	[TestClass]
	public class TaskCRUDUnitTest : UnitTestBase
	{
		#region Create a task
		/// <summary>
		/// Test creating an task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_Task()
		{
			//create an task
			Guid taskId = Guid.Empty;
			Entity task = new Entity("task");
			task["subject"] = Utils.GetRandomString(5, 20);

			TestContext.BeginTimer("Task Create Unit Test");
			try
			{
				taskId = Proxy.Create(task);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task Create Unit Test");
			
			//add the task to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Tasks, g, new string[] { "OwnerId", "ActivityID", "EntityManagerOwningUser" }, new string[] { m_user["systemuserid"], taskId.ToString(), g.ToString() });
		}
		#endregion

		#region Retrieve a task
		/// <summary>
		/// Test retrieving a task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_Task()
		{
			CRMEntity m_task = RetrieveTestEntity(m_user, EntityNames.Tasks);
			Entity task = new Entity("task");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "activityid", "subject" });
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Task Retrieve Unit Test");
			try
			{
				task = Proxy.Retrieve(task.LogicalName, new Guid(m_task["activityid"]), attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task Retrieve Unit Test");
		}
		#endregion

		#region Update a task
		/// <summary>
		/// Test updating an task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_Task()
		{
			Entity task = new Entity("task");
			//find a CRM Entity for update test
			//create a dummy task for update
			task["subject"] = Utils.GetRandomString(5, 20);
			Guid taskId = Proxy.Create(task);

			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "subject"});
			//get the task in CRM
			task = Proxy.Retrieve(task.LogicalName, taskId, attributes);
			//update task subject value
			task["subject"] = Utils.GetRandomString(10, 20);
			//update the task
			TestContext.BeginTimer("Task Update Unit Test");
			try
			{
				Proxy.Update(task);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task Update Unit Test");
		}
		#endregion

		#region Delete a task 
		/// <summary>
		/// Test deleting an task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_Task()
		{
			//create a dummy task for deletion
			Entity task = new Entity("task");
			task["subject"] = Utils.GetRandomString(5, 20);
			Guid taskId = Proxy.Create(task);

			TestContext.BeginTimer("Task Delete Unit Test");
			try
			{
				Proxy.Delete("task", taskId);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.ToString());
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task Delete Unit Test");
		}
		#endregion

		#region Retrieve multiple tasks
		/// <summary>
		/// Test retrieving multiple task records
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_task()
		{
			Entity task = new Entity("task");
			var queryExpression = new QueryExpression()
			{
				Distinct = false,
				EntityName = task.LogicalName,
				ColumnSet = new ColumnSet("activityid"),

				Criteria =
				{
					Filters = 
						{
							new FilterExpression
							{
								FilterOperator = LogicalOperator.And,
								Conditions = 
								{
									new ConditionExpression("new_attribute4", ConditionOperator.GreaterEqual, "90000"),
									new ConditionExpression("new_attribute5", ConditionOperator.LessThan, "80000"),
								},
							}

						   
						}
				}
			};


			EntityCollection results;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Task RetrieveMultiple Unit Test");
			try
			{
				results = Proxy.RetrieveMultiple(queryExpression);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Task RetrieveMultiple Unit Test");
		}
		#endregion
	}
}
