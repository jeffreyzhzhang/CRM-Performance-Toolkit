﻿using System;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class RollupJobUnitTests : UnitTestBase
	{
		// For updating Bootstrap job properties
		string UpdateRollupPropertiesQuery= "update rolluppropertiesbase set initialvaluecalculationstatus = 0, bootstrapstepnumber=1, bootstrapretrycount=0, bootstrapcurrentdepth=1,bootstraptargetpointer=0 where rollupattributelogicalname ='{0}'";
		string UpdateAsyncOperationBaseQuery="update AsyncOperationBase set postponeuntil = getutcdate() where asyncoperationid in (select {0} from rolluppropertiesbase nolock where rollupattributelogicalname='{1}')";
		// For updating Increamental job properties
		string UpdateAsyncOperationBaseForIncrementalJobQuery = "update AsyncOperationBase set RecurrencePattern ='FREQ=MINUTELY;INTERVAL=15' where asyncoperationid in (select {0} from rolluppropertiesbase nolock where rollupattributelogicalname='{1}')";

		string RollupBootstrapJob = "RollupBootstrapJob";
		string RollupIncrementalJob = "RollupIncrementalJob";
		string ActualRevenue = "new_actualrevenue";
		string EstimatedRevenue = "new_estimatedrevenue";
		string OpportunityCount = "new_opportunitycount";

		[TestInitialize]
		public override void Initialize()
		{
			base.Initialize();
		}

		[TestMethod()]
		public void UnitTest__Bootstrap_ActualRevenue()
		{
			UpdateJobProperties(RollupBootstrapJob, ActualRevenue);
		}

		[TestMethod()]
		public void UnitTest__Bootstrap_EstimatedRevenue()
		{
			UpdateJobProperties(RollupBootstrapJob, EstimatedRevenue);
		}

		[TestMethod()]
		public void UnitTest__Bootstrap_OpportunityCount()
		{
			UpdateJobProperties(RollupBootstrapJob, OpportunityCount);
		}

		[TestMethod()]
		public void UnitTest__IncrementalJob_ActualRevenue()
		{
			UpdateJobProperties(RollupIncrementalJob, ActualRevenue);
		}

		[TestMethod()]
		public void UnitTest__IncrementalJob_EstimatedRevenue()
		{
			UpdateJobProperties(RollupIncrementalJob, EstimatedRevenue);
		}

		[TestMethod()]
		public void UnitTest__IncrementalJob_OpportunityCount()
		{
			UpdateJobProperties(RollupIncrementalJob, OpportunityCount);
		}

		private void UpdateJobProperties(string jobName, string attributeName)
		{
			if (!CheckIfBootstrapJobIsRunning(attributeName))
			{
				var orgInfo = EntityManager.Organizations.FirstOrDefault(o => o.OrganizationId.Equals(EntityManager.Instance.GetRandomOrg()));
				if (orgInfo != null && orgInfo.ServerInfo != null)
				{
					using (SqlConnection sqlConnection = new SqlConnection(orgInfo.ServerInfo.SQLCNN))
					{
						sqlConnection.Open();

						//Build the SQL for the current request
						SqlCommand sqlCommand = new SqlCommand();
						sqlCommand.Connection = sqlConnection;
						string asycJobId = string.Empty;
						if (jobName == RollupBootstrapJob)
						{
							asycJobId = "bootstraprollupasyncjobid";
							sqlCommand.CommandText = string.Format(UpdateAsyncOperationBaseQuery, asycJobId, attributeName);
						}
						else if (jobName == RollupIncrementalJob)
						{
							asycJobId = "incrementalrollupasyncjobid";
							sqlCommand.CommandText = string.Format(UpdateAsyncOperationBaseForIncrementalJobQuery, asycJobId, attributeName);
						}
						int numberOfAffectedRows = sqlCommand.ExecuteNonQuery();
						if (numberOfAffectedRows == 0)
						{
							throw new Exception("Error while updating rollup job properties.");
						}
						if (jobName == RollupBootstrapJob)
						{
							sqlCommand = new SqlCommand();
							sqlCommand.Connection = sqlConnection;
							sqlCommand.CommandText = string.Format(UpdateRollupPropertiesQuery, attributeName);
							int numberOfRowsAffected = sqlCommand.ExecuteNonQuery();
							if (numberOfRowsAffected == 0)
							{
								throw new Exception("Error while updating rollup job properties.");
							}
						}
					}
				}
			}
		}

		private bool CheckIfBootstrapJobIsRunning(string attributeName)
		{ 
			bool isRollupJobRunning = false;
			var orgInfo = EntityManager.Organizations.FirstOrDefault(o => o.OrganizationId.Equals(EntityManager.Instance.GetRandomOrg()));
			if (orgInfo != null && orgInfo.ServerInfo != null)
			{
				using (SqlConnection sqlConnection = new SqlConnection(orgInfo.ServerInfo.SQLCNN))
				{
					sqlConnection.Open();
					//Build the SQL for the current request
					SqlCommand sqlCommand = new SqlCommand();
					sqlCommand.Connection = sqlConnection;					
					string selectQuery = "SELECT * FROM rolluppropertiesbase  WHERE rollupattributelogicalname ='{0}' AND initialvaluecalculationstatus=1";
					sqlCommand.CommandText = string.Format(selectQuery, attributeName);
					SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
					System.Data.DataTable table = new System.Data.DataTable();
					table.Load(sqlDataReader);

					if (table.Rows.Count > 0)
					{
						isRollupJobRunning = true;
					}
				}
			}
			return isRollupJobRunning;
		}
	}
}
