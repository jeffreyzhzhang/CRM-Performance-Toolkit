﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;


namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// test WinOpportunityRequest
	/// 1. create a dummy opportunity
	/// 2. set the status of the dummy opportunity to WON
	/// 3. delete the dummy opportunity after test
	/// </summary>
	[TestClass]
	public class WinOpportunityRequestUnitTest : UnitTestBase
	{
		#region Win an opoortunity
		/// <summary>
		/// Test winnning an opportunity request
		/// </summary>
		[TestMethod()]
		public void UnitTest__WinOpportunityRequest()
		{
			CRMEntity m_account = RetrieveTestEntity(m_user, EntityNames.Accounts);
			CRMEntity  m_pricelevel = RetrieveTestEntity(m_user, EntityNames.PriceLevels);
			//create a dummy opportunity
			Guid opportunityId = Guid.Empty;
			Entity opportunity = new Entity("opportunity");
			opportunity.Attributes.Add("customerid", new EntityReference(EntityNames.Accounts.ToLower(), new Guid(m_account["accountId"])));
			opportunity.Attributes.Add("pricelevelid", new EntityReference(EntityNames.PriceLevels.ToLower(), new Guid(m_pricelevel["pricelevelId"])));
			opportunity.Attributes.Add("discountpercentage", 0.50m);
			opportunity.Attributes.Add("name", Utils.GetRandomString(5, 10));
			opportunityId = Proxy.Create(opportunity);
			//set the status of the opportunity just created to WON status
			WinOpportunityRequest req = new WinOpportunityRequest();
			Entity opportunityClose = new Entity("opportunityclose");
			opportunityClose.Attributes.Add("opportunityid", new EntityReference("opportunity", opportunityId));
			opportunityClose.Attributes.Add("ownerid", new EntityReference("systemuser", new Guid(m_user["systemuserid"])));
			opportunityClose.Attributes.Add("subject", "Win the Opportunity!");
			req.OpportunityClose = opportunityClose;
			req.Status = new OptionSetValue(3);

			//execute request
			TestContext.BeginTimer("WinOpportunityRequest Unit Test");
			try
			{
				WinOpportunityResponse resp = (WinOpportunityResponse)Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			finally
			{
				//delete the opportunity created
				if (opportunityId != null)
				{
					Proxy.Delete(opportunity.LogicalName, opportunityId);
				}
			}
			TestContext.EndTimer("WinOpportunityRequest Unit Test");
		}
		#endregion
	}
}
