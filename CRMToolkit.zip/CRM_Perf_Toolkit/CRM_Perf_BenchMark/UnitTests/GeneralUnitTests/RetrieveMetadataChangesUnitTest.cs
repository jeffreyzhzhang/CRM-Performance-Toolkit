﻿using System;
using System.Diagnostics;
using System.IO;
using System.ServiceModel;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Web.Services.Protocols;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata.Query;
using Microsoft.Xrm.Sdk;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class RetrieveMetadataChangesUnitTest : UnitTestBase
	{
		#region Query for metadata
		/// <summary>
		/// Test metadata query
		/// </summary>
		[TestMethod]
		public void UnitTest_QueryForMetadata()
		{
			var entityQuery = new EntityQueryExpression();
			entityQuery.Criteria = new MetadataFilterExpression();
			entityQuery.Criteria.Conditions.Add(new MetadataConditionExpression("logicalname", MetadataConditionOperator.In, new[] { "contact", "opportunity", "lead", "account" }));

			var attributeQuery = new AttributeQueryExpression();
			attributeQuery.Criteria = new MetadataFilterExpression(Microsoft.Xrm.Sdk.Query.LogicalOperator.Or);
			attributeQuery.Criteria.Conditions.Add(new MetadataConditionExpression("logicalname", MetadataConditionOperator.Equals, "name"));
			attributeQuery.Criteria.Conditions.Add(new MetadataConditionExpression("logicalname", MetadataConditionOperator.Equals, "fullname"));

			entityQuery.AttributeQuery = attributeQuery;

			var request = new RetrieveMetadataChangesRequest();
			request.Query = entityQuery;

			TestContext.BeginTimer("RetrieveMetadataChanges UnitTest");
			try
			{
				var response = Proxy.Execute(request);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveMetadataChanges UnitTest");
		}
		#endregion
	}
}
