﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit Testcases for creating Account entity using Execute Multiple
	/// </summary>
	[TestClass]
	public sealed class ExecuteMultipleUnitTest : UnitTestBase
	{
		private List<ExecuteMultipleProxyRequestList> m_proxyRequestLists;

		//test creating an account using Execute Multiple
		public ExecuteMultipleUnitTest()
		{
			m_proxyRequestLists = new List<ExecuteMultipleProxyRequestList>();
			System.Net.ServicePointManager.DefaultConnectionLimit = 100;
		}


		//initialization with sub-properties requirement
		//for instance, require name contains keyword of 'deletable'
		public void init(string filter)
		{
			int totalEntitiesPerThread = ConfigSettings.Default.ExecuteMultipleTestSettings.TotalEntities / ConfigSettings.Default.ExecuteMultipleTestSettings.BatchSize;
			int totalIterationsPerThread = totalEntitiesPerThread / ConfigSettings.Default.ExecuteMultipleTestSettings.MaxThreads;


			for (int i = 0; i < totalIterationsPerThread; i++)
			{
				ExecuteMultipleProxyRequestList proxyList = new ExecuteMultipleProxyRequestList();
				for (int y = 0; y < ConfigSettings.Default.ExecuteMultipleTestSettings.MaxThreads; y++)
				{
					ExeuteMultipleProxyRequest proxyRequest = new ExeuteMultipleProxyRequest();
					base.Initialize();
					ExecuteMultipleRequest request = CreateMultipleAccountRequest(ConfigSettings.Default.ExecuteMultipleTestSettings.BatchSize);

					proxyRequest.Proxy = Proxy;
					proxyRequest.Request = request;
					proxyList.Add(proxyRequest);
				}
				m_proxyRequestLists.Add(proxyList);
			}
		}

		//default initialization which with no sub-properties requirement 
		public void init()
		{
			string temp = string.Empty;
			init(temp);
		}
		/// <summary>
		/// Test creating an account
		/// </summary>
		[TestMethod()]
		public void UnitTest__ExecuteMultiple_Create_Account()
		{
			init();

			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("ExecuteMultiple UnitTest");

			List<ExecuteMultipleProxyResponse> responses = new List<ExecuteMultipleProxyResponse>();
			foreach (var proxyRequestList in m_proxyRequestLists)
			{
				Parallel.ForEach(proxyRequestList, (request) =>
				{
					ExecuteMultipleProxyResponse executeMultipleResponse = new ExecuteMultipleProxyResponse();
					executeMultipleResponse.Request = request.Request;

					try
					{
						executeMultipleResponse.Response = request.Proxy.Execute(request.Request) as ExecuteMultipleResponse;
					}
					catch (FaultException fe)
					{
						Trace.WriteLine(fe.Message);
						Trace.WriteLine(fe.StackTrace);
						executeMultipleResponse.Exception = fe;
					}
					catch (SoapException se)
					{
						Trace.WriteLine(se.Detail);
						Trace.WriteLine(se.StackTrace);
						executeMultipleResponse.Exception = se;
					}
					responses.Add(executeMultipleResponse);
				});
			}

			DateTime end = DateTime.UtcNow;
			TestContext.EndTimer("ExecuteMultiple UnitTest");
			TimeSpan duration = (end - start);

			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));

			foreach (ExecuteMultipleProxyResponse proxyResponse in responses)
			{
				if (proxyResponse.Exception != null)
				{
					FaultException fe = proxyResponse.Exception as FaultException;
					if (fe != null)
					{
						Trace.WriteLine(fe.Message);
						Trace.WriteLine(fe.StackTrace);
					}
					SoapException se = proxyResponse.Exception as SoapException;
					if (se != null)
					{
						Trace.WriteLine(se.Detail);
						Trace.WriteLine(se.StackTrace);
					}
				}
				foreach (ExecuteMultipleResponseItem responseItem in proxyResponse.Response.Responses)
				{
					if (responseItem.Response != null)
					{
						Guid accountId = (Guid)responseItem.Response["id"];
						Entity sourceAccount = proxyResponse.Request.Requests[responseItem.RequestIndex]["Target"] as Entity;
						if (sourceAccount != null)
						{
							String accountName = sourceAccount["name"] as String;

							//add the account to EMDB
							EntityManager.Instance.AddEntity(EntityNames.Accounts, g,
															 new string[] { "OwnerId", "AccountID", "name", "EntityManagerOwningUser" },
															 new string[]
															 {
																 m_user["systemuserid"], accountId.ToString(), accountName,
																 g.ToString()
															 });
						}
					}
					else
					{
						OrganizationServiceFault fe = responseItem.Fault;
						if (fe != null)
						{
							Trace.WriteLine(fe.Message);
							Trace.WriteLine(fe.TraceText);
						}
					}
				}
			}
		}

		private ExecuteMultipleRequest CreateMultipleAccountRequest(int batchSize)
		{
			ExecuteMultipleRequest request = new ExecuteMultipleRequest();
			request.Requests = new OrganizationRequestCollection();
			request.Settings = new ExecuteMultipleSettings();

			for (int i = 0; i < batchSize; i++)
			{
				request.Requests.Add(AccountCreateRequest());
			}

			request.Settings.ReturnResponses = true;
			request.Settings.ContinueOnError = true;


			return request;
		}
		private static OrganizationRequest AccountCreateRequest()
		{

			var accountCreateRequest = new OrganizationRequest { RequestName = "Create" };
			Entity account = new Entity("account");
			account["name"] = Utils.GetRandomString(5, 30);
			accountCreateRequest.Parameters["Target"] = account;
			accountCreateRequest.RequestId = Guid.NewGuid();
			return accountCreateRequest;
		}
	}
	internal sealed class ExecuteMultipleProxyRequestList : List<ExeuteMultipleProxyRequest>
	{

	}
	internal sealed class ExeuteMultipleProxyRequest
	{
		internal IOrganizationService Proxy { get; set; }
		internal ExecuteMultipleRequest Request { get; set; }
	}
	internal sealed class ExecuteMultipleProxyResponse
	{
		internal ExecuteMultipleRequest Request { get; set; }
		internal ExecuteMultipleResponse Response { get; set; }
		internal Exception Exception { get; set; }
		internal Boolean ExpectedException { get; set; }
		internal DateTime StartTime { get; set; }
		internal DateTime EndTime { get; set; }

		internal Double Throughput { get; set; }
	}
}
