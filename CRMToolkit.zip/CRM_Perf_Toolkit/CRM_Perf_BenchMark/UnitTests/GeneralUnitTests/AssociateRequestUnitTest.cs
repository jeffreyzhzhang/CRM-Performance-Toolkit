﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Test AssociateRequest by associating a contact to an account 
	/// </summary>
	[TestClass]
	public class AssociateRequestUnitTest : UnitTestBase
	{

		#region Associate request
		/// <summary>
		/// associate request unit test case
		/// </summary>
		[TestMethod()]
		public void UnitTest__AssociateRequest()
		{
			CRMEntity m_account = RetrieveTestEntity(m_user, EntityNames.Accounts);
			CRMEntity m_contact = RetrieveTestEntity(m_user, EntityNames.Contacts);
			//create an associate request which links an account to a contact
			Microsoft.Xrm.Sdk.Messages.AssociateRequest associateRequest = new Microsoft.Xrm.Sdk.Messages.AssociateRequest();
			associateRequest.Target = new EntityReference("account", new Guid(m_account["accountid"]));
			associateRequest.RelatedEntities = new EntityReferenceCollection();
			associateRequest.RelatedEntities.Add(new EntityReference("contact", new Guid(m_contact["contactid"])));
			associateRequest.Relationship = new Relationship("contact_customer_accounts");

			//execute the associate request
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Associate Request Unit Test");
			try
			{
				Proxy.Execute(associateRequest);
			}
			catch (FaultException<IOrganizationService> fe)
			{
				Trace.WriteLine(fe.Detail);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Associate Request Unit Test");

		}
		#endregion


	}
}
