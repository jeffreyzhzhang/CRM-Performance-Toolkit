﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	//test RetrieveUserSettingsSystemUserRequest
	[TestClass]
	public class RetrieveUserSettingsSystemUserRequestUnitTest : UnitTestBase
	{
		#region Retrieve user settings
		/// <summary>
		/// Test retrieving system user settings
		/// </summary>
		[TestMethod]
		public void UnitTest__RetrieveUserSettingsSystemUserRequest()
		{
			//create RetrieveUserSettingsSystemUserRequest
			RetrieveUserSettingsSystemUserRequest req = new RetrieveUserSettingsSystemUserRequest();
			req.ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet(true);
			req.EntityId = new Guid(m_user["systemuserid"]);
			//execute the request
			TestContext.BeginTimer("RetrieveUserSettingsSystemUserRequest Unit Test");
			try
			{
				Proxy.Execute(req);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveUserSettingsSystemUserRequest Unit Test");
		}
		#endregion
	}
}
