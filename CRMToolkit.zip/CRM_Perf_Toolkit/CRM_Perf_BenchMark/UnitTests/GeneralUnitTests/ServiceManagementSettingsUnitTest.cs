﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;
using System.Diagnostics;
using System.Globalization;
using System.ServiceModel;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for updating case record such that sla gets reevaluated.
	/// </summary>
	[TestClass]
	public class ServiceManagementSettingsUnitTest : UnitTestBase
	{
		//this is the workflow imported from SLA solution
		private const string slaWorkflowId = "1c168ae9-82a6-4f88-8464-65ed46bc869f";
		#region Initialize
		[TestInitialize]
		public override void Initialize()
		{
			base.Initialize();
			//Creates a Default SLA if not already exists.
			//UnitTest__Create_SLA();
		}
		#endregion

		#region Update a case so that SLA gets reevaluated
		/// <summary>
		/// Update a case with default SLA applied
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_Case()
		{
			Entity Case = new Entity("incident");
			//find a case with normal priority that can be updated to reevaluate SLA
			System.Collections.Hashtable filter = new System.Collections.Hashtable()
			{
				{"prioritycode", "2"}
			};
			CRMEntity m_case = RetrieveTestEntity(m_user, EntityNames.Incidents, filter);
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "title", "ownerid", "prioritycode" });
			//get the case in CRM
			Case = Proxy.Retrieve(Case.LogicalName, new Guid(m_case[EntityIDNames.Incident]), attributes);
			if (Case != null)
			{
				//update case priority 
				Case["title"] = "Updated For SLA" + Utils.GetRandomString(10, 50);
				Case["prioritycode"] = new OptionSetValue(1);
				//update the case
				TestContext.BeginTimer("Case Update UnitTest");
				try
				{
					Proxy.Update(Case);

				}
				catch (FaultException fe)
				{
					Trace.WriteLine(fe.Message);
					Trace.WriteLine(fe.StackTrace);
					throw;
				}
			}

			TestContext.EndTimer("Case Update UnitTest");
		}
		#endregion

		// keeping this code only to assist revert in case required for somemacro runs
		
		//#region Create a default SLA
		/// <summary>
		/// Creates a default SLA with wf imported from solution
		/// </summary>
		//private void UnitTest__Create_SLA()
		//{
		//    //Check if default SLA exists
		//    if (UnitTest__HasDefaultSLA())
		//    {
		//        return;
		//    }
		//    //create a SLA
		//    Guid slaID = Guid.Empty;
		//    Entity sla = new Entity("sla");
		//    sla["name"] = Utils.GetRandomString(5, 10);
		//    sla["description"] = Utils.GetRandomString(5, 10);
		//    sla["applicablefrom"] = "createdon";
		//    TestContext.BeginTimer("SLA Create Unit Test");
		//    try
		//    {
		//        slaID = Proxy.Create(sla);
		//    }
		//    catch (FaultException fe)
		//    {
		//        Trace.WriteLine(fe.Message);
		//        Trace.WriteLine(fe.StackTrace);
		//        throw;
		//    }
		//    TestContext.EndTimer("SLA Create Unit Test");

		//    //Retrieve the Workflow id- this is the workflow id imported in SLA solution
		//    Guid workFlowId = new Guid(slaWorkflowId);

		//    //Update the SLA with workflow id
		//    UnitTest__Update_Sla(slaID, workFlowId);

		//}

		/// <summary>
		/// Updates default SLA with workflow
		/// </summary>
		/// <param name="slaId"></param>
		/// <param name="workflowid"></param>
		//private void UnitTest__Update_Sla(Guid slaId, Guid workflowid)
		//{
		//    Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "name", "workflowid" });

		//    //get the sla in CRM
		//    Entity sla = Proxy.Retrieve("sla", slaId, attributes);

		//    //update sla's workflow
		//    sla["workflowid"] = new EntityReference("workflow", workflowid);

		//    //update the sla
		//    TestContext.BeginTimer("SLA Update Unit Test");
		//    try
		//    {
		//        Proxy.Update(sla);

		//    }
		//    catch (FaultException fe)
		//    {
		//        Trace.WriteLine(fe.Message);
		//        Trace.WriteLine(fe.StackTrace);
		//        throw;
		//    }
		//    TestContext.EndTimer("SLA Update Unit Test");

		//    //set the state of the sla
		//    SetStateRequest req = new SetStateRequest();
		//    req.EntityMoniker = new EntityReference("sla", slaId);
		//    //set the state to 
		//    req.State = new OptionSetValue(1);
		//    req.Status = new OptionSetValue(2);
		//    //execute the request
		//    DateTime start = DateTime.UtcNow;
		//    DateTime end;
		//    TestContext.BeginTimer("SetState Request Unit Test");
		//    try
		//    {
		//        Proxy.Execute(req);
		//        TestContext.EndTimer("SetState Request Unit Test");
		//        end = DateTime.UtcNow;
		//    }
		//    catch (FaultException fe)
		//    {
		//        Trace.WriteLine(fe.Message);
		//        Trace.WriteLine(fe.StackTrace);
		//        throw;
		//    }

		//    //update sla as default
		//    sla["isdefault"] = true;

		//    //update the sla
		//    TestContext.BeginTimer("SLA Update Unit Test");
		//    try
		//    {
		//        Proxy.Update(sla);

		//    }
		//    catch (FaultException fe)
		//    {
		//        Trace.WriteLine(fe.Message);
		//        Trace.WriteLine(fe.StackTrace);
		//        throw;
		//    }


		//}
		//#endregion

		//#region Check Active Default SLA
		//public bool UnitTest__HasDefaultSLA()
		//{
		//    Entity sla = new Entity("sla");

		//    var queryExpression = new QueryExpression()
		//    {
		//        Distinct = false,
		//        EntityName = "sla",
		//        ColumnSet = new ColumnSet("slaid", "name", "isdefault"),

		//        Criteria =
		//        {
		//            Filters = 
		//            {
		//                new FilterExpression
		//                {
		//                    FilterOperator = LogicalOperator.And,
		//                    Conditions = 
		//                    {
		//                    new ConditionExpression("isdefault", ConditionOperator.Equal, "true")
								
		//                    },
		//                    }
		//                }
		//        }
		//    };

		//    EntityCollection results;
		//    TestContext.BeginTimer("SLA RetrieveMultiple Unit Test");
		//    try
		//    {
		//        results = Proxy.RetrieveMultiple(queryExpression);
		//        TestContext.EndTimer("SLA RetrieveMultiple Unit Test");
		//        if (results != null && results.Entities.Count > 0)
		//            return true;
		//        else return false;

		//    }
		//    catch (FaultException fe)
		//    {
		//        Trace.WriteLine(fe.Message);
		//        Trace.WriteLine(fe.StackTrace);
		//        throw;
		//    }


		//}
	}
}
