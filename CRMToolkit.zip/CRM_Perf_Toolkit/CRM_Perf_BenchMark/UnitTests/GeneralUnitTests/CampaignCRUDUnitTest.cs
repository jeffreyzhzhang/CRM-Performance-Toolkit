﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting campaign entity
	/// </summary>
	[TestClass]
	public class CampaignCRUDUnitTest : UnitTestBase
	{
		#region Create an campaign
		/// <summary>
		/// Test creating an campaign
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_campaign()
		{
			//create an campaign
			Guid campaignId = Guid.Empty;
			Entity campaign = new Entity("campaign");
			campaign["name"] = Utils.GetRandomString(5, 30);

			TestContext.BeginTimer("Campaign Create Unit Test");
			try
			{
				campaignId = Proxy.Create(campaign);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			
			TestContext.EndTimer("Campaign Create Unit Test");
			
			//add the campaign to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Campaigns, g, new string[] { "OwnerId", "campaignID", "EntityManagerOwningUser" }, new string[] { m_user["systemuserid"], campaignId.ToString(), g.ToString() });

		}
		#endregion

		#region Retrieve campaign
		/// <summary>
		/// Retrieve campaign
		/// </summary>
		[TestMethod()]
		public void UnitTest__Retrieve_campaign()
		{
			CRMEntity m_campaign = RetrieveTestEntity(m_user, EntityNames.Campaigns);
			Entity campaign = new Entity("campaign");
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "name" });
			DateTime start = DateTime.UtcNow;
			Guid campaignId = new Guid(m_campaign["campaignId"]);
			TestContext.BeginTimer("Campaign Retrieve Unit Test");
			try
			{
				campaign = Proxy.Retrieve(campaign.LogicalName, campaignId, attributes);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			
			TestContext.EndTimer("Campaign Retrieve Unit Test");
			
		}
		#endregion

		#region Update campaign
		/// <summary>
		/// Test retrieving and updating an campaign
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_campaign()
		{
			CRMEntity m_campaign = RetrieveTestEntity(m_user, EntityNames.Campaigns);
			Entity campaign = new Entity("campaign");
			//find a CRM Entity for update test
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "name" });
			//get the campaign in CRM
			campaign = Proxy.Retrieve(campaign.LogicalName, new Guid(m_campaign["campaignId"]), attributes);
			//update campaign address city value

			campaign["name"] = Utils.GetRandomString(5, 10);
			//update the campaign
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Campaign Update Unit Test");
			try
			{
				Proxy.Update(campaign);

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Campaign Update Unit Test");

		}
		#endregion

		#region Delete campaign
		/// <summary>
		/// Delete campaign
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_campaign()
		{
			CRMEntity m_campaign = RetrieveTestEntity(m_user, EntityNames.Campaigns);
			TestContext.BeginTimer("Campaign Delete Unit Test");
			try
			{
				Proxy.Delete("campaign", new Guid(m_campaign["campaignId"]));

			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("Campaign Delete Unit Test");
			
			//delete the campaign from EMDB
			EntityManager.Instance.DeleteEntity(m_campaign);

		}
		#endregion

		#region Retrieve multiple campaign
		/// <summary>
		/// Retrieve multiple campaign
		/// </summary>
		[TestMethod()]
		public void UnitTest__RetrieveMultiple_Campaign()
		{
			Entity campaign = new Entity("campaign");
			var queryExpression = new QueryExpression()
			{
				Distinct = false,
				EntityName = campaign.LogicalName,
				ColumnSet = new ColumnSet("name", "createdon"),

				Criteria =
				{
					Filters = 
						{
							new FilterExpression
							{
								FilterOperator = LogicalOperator.And,
								Conditions = 
								{
									new ConditionExpression("budgetedcost", ConditionOperator.GreaterEqual, "50"),
									new ConditionExpression("expectedrevenue", ConditionOperator.GreaterThan, "100")
								   
								},
							},

							new FilterExpression
							{
								FilterOperator = LogicalOperator.Or,
								Conditions =
								{
									new ConditionExpression("createdon", ConditionOperator.LastXDays, "50"),
									new ConditionExpression("proposedstart", ConditionOperator.LastMonth)
								}
							}
							
						   
						}
				}
			};


			EntityCollection results;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer("Campaign RetrieveMultiple Unit Test");
			try
			{
				results = Proxy.RetrieveMultiple(queryExpression);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			
			TestContext.EndTimer("Campaign RetrieveMultiple Unit Test");


		}

		#endregion

	}
}
