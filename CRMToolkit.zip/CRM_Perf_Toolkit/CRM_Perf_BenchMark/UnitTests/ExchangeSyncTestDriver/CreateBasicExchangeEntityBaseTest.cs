﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using CRM_Perf_BenchMark.Utilities;

namespace CRM_Perf_BenchMark.UnitTests
{

	/// <summary>
	/// Base Class for All Exchange Entity CUD
	/// </summary>
	public abstract class CreateBasicExchangeEntityBaseTest : CreateBasicEntityBaseTest
	{       
		protected ExchangeProvider exchange;

		protected override string DeleteIdentifier
		{
			get { return this.FilterAppendable + " exchange del"; }
		}

		protected override string UpdateIdentifier
		{
			get { return this.FilterAppendable + " exchange update"; }
		}

		public CreateBasicExchangeEntityBaseTest():base()
		{}



		/// <summary>
		/// Intializes the Exchange Base Entity
		/// </summary>
		/// <param name="props">A dictionary of all the terms to Search for in the EMDB</param>
		public void Init(Dictionary<string,string> props, string entityMessage)
		{
			System.Collections.Hashtable props2 = new System.Collections.Hashtable();
			System.Collections.Hashtable sub_props = new System.Collections.Hashtable();            

			if (props != null)
			{
				foreach (string ob in props.Keys)
				{
					sub_props.Add(ob, props[ob]);
				}
			}
			props2.Add(EntityName, sub_props);
			base.Init(props2, entityMessage);
		}


		/// <summary>
		/// Creates the Entity in exchange and logs the result with the timer name provided
		/// </summary>
		/// <param name="entity"></param>
		/// <param name="timerName"></param>
		/// <returns></returns>
		public string CreateEntityInExchange(Entity entity, string timerName)
		{
			if (this.exchange == null)
			{
				this.exchange = new ExchangeProvider(this.m_user);
			}

			string returnGuid = String.Empty;
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer(timerName);
					try
			{
				returnGuid = exchange.CreateItem(entity).UniqueId;
			}
				catch (FaultException fe)
				{
					Trace.WriteLine(fe.Message);
					Trace.WriteLine(fe.StackTrace);
					throw;
				}
				catch (SoapException se)
				{
					Trace.WriteLine(se.Detail);
					Trace.WriteLine(se.StackTrace);
					throw;
				}
				TestContext.EndTimer(timerName);
				DateTime end = DateTime.UtcNow;
				TimeSpan duration = (end - start);

				lock (typeof(StreamWriter))
				{
					StreamWriter logWriter = new StreamWriter(this.SummaryFile);
					logWriter.WriteLine("Logging test result for Creating " + this.EntityName + " test ...");
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine(this.EntityName + " id created in this test is " + returnGuid.ToString());
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine(this.PrintEntityData(entity));
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine("Test started at " + start);
					logWriter.WriteLine("-----------------------------------------");
					logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
					logWriter.WriteLine("-----------------------------------------");
					logWriter.Flush();
					logWriter.Close();
				}
				return returnGuid;
		}

		/// <summary>
		/// Updates the Entity in Exchange and logs the result with the timer name provided
		/// </summary>
		/// <param name="entityLogicalName"></param>
		/// <param name="entity"></param>
		/// <param name="timerName"></param>
		/// <param name="updateValue"></param>
		public void UpdateEntityInExchange(string entityLogicalName, CRMEntity entity, string timerName, string updateValue)
		{
			if (this.exchange == null)
			{
				this.exchange = new ExchangeProvider(this.m_user);
			}

			//update the Phone Call
			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer(timerName);
			try
			{
			   exchange.UpdateItem(entityLogicalName , entity["exchangeid"].ToString(), updateValue);
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer(timerName);
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Updating " + this.EntityName + " test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the " + this.EntityName + " retrieved in this test is " + entity["exchangeid"].ToString());
				logWriter.WriteLine("-----------------------------------------");
				//logWriter.WriteLine(this.PrintEntityData(entity));
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}            
		}

		/// <summary>
		/// Deletes the Entity in Exchange and logs the result with the timer name provided
		/// </summary>
		/// <param name="logicalName"></param>
		/// <param name="entity"></param>
		/// <param name="timerName"></param>
		public void DeleteEntityInExchange(string logicalName,CRMEntity entity, string timerName)
		{

			if (this.exchange == null)
			{
				this.exchange = new ExchangeProvider(this.m_user);
			}

			DateTime start = DateTime.UtcNow;
			TestContext.BeginTimer(timerName);
			try
			{
				exchange.DeleteItem(entity["exchangeid"].ToString());                
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			catch (SoapException se)
			{
				Trace.WriteLine(se.Detail);
				Trace.WriteLine(se.StackTrace);
				throw;
			}
			TestContext.EndTimer(timerName);
			DateTime end = DateTime.UtcNow;
			TimeSpan duration = (end - start);

			lock (typeof(StreamWriter))
			{
				StreamWriter logWriter = new StreamWriter(SummaryFile);
				logWriter.WriteLine("Logging test result for Deleting contact test ...");
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("The ID of the contact deleted in this test is " + m_contact["contactId"]);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test started at " + start);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.WriteLine("Test takes {0} millisecond", duration.TotalMilliseconds);
				logWriter.WriteLine("-----------------------------------------");
				logWriter.Flush();
				logWriter.Close();
			}
			//delete the contact from EMDB
			EntityManager.Instance.DeleteEntity(m_contact);
		}
	}
}
