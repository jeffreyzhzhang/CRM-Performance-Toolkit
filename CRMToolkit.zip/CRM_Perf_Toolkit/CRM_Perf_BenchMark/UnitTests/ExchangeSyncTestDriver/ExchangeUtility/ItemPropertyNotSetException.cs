﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Diagnostics.CodeAnalysis;

namespace CRM_Perf_BenchMark.Utilities
{
	/// <summary>
	/// ItemPropertyNotSetException to be used if an Expected Mapi Property is not Set on Item after Sync
	/// </summary>
	[SuppressMessage("Microsoft.Security", "CA9881:ClassesShouldBeSealed", Justification = "Class has protected member", MessageId = "")]
	[Serializable]
	public class ItemPropertyNotSetException : System.Exception
	{
		/// <summary>
		/// Default Constructor
		/// </summary>
		public ItemPropertyNotSetException()
			: base()
		{
		}

		/// <summary>
		/// Constructs exception with message
		/// </summary>
		/// <param name="message">Message to pass</param>
		public ItemPropertyNotSetException(string message)
			: base(message)
		{
		}
		/// <summary>
		/// Constructs exception with message and inner exception
		/// </summary>
		/// <param name="message">Message to pass</param>
		/// <param name="innerException">Exception to include</param>
		public ItemPropertyNotSetException(string message, System.Exception innerException)
			: base(message, innerException)
		{
		}
		/// <summary>
		/// Serilization constructor
		/// </summary>
		/// <param name="serializationInfo"></param>
		/// <param name="sc"></param>
		protected ItemPropertyNotSetException(SerializationInfo serializationInfo, StreamingContext sc)
			:
			base(serializationInfo, sc)
		{
		}
	}
}
