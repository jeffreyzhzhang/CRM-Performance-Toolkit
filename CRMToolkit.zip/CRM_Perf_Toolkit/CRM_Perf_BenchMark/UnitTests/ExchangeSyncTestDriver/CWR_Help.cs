﻿using Microsoft.Xrm.Sdk;
using ServiceCreator;
using System;
using System.Collections;
using System.IO;
using System.Collections.Generic;


namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	///help class that generates organization service proxy and initializes the related test properties
	/// </summary>
	class CWR_Help
	{
		CRMEntity m_user;
		string m_userName = string.Empty;
		string m_domain = string.Empty;
		string m_password = string.Empty;
		string m_organization = string.Empty;
		string m_crmticket = string.Empty;
		Hashtable m_Entities;
		string[] m_Props;
		public static string resultDir = Environment.SystemDirectory.Split(new char[] { '\\' }, 2)[0] + @"\PerfResult";
		public IOrganizationService m_proxy;

		//construct with the list of entities to be returned 
		//usage: if need to create account and contact Entities, the props parameter will be like {EntityName.Accounts, EntityName.Contacts} 
		//it also takes an optional parameter for returning an admin user
		public CWR_Help(string[] props, bool requireAdminRights = false)
		{
			m_Entities = new Hashtable();
			m_Props = props;
			//if results dir doesn't exist, create one
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
			}
			init(requireAdminRights);
		}

		/// <summary>
		/// constructor with list of entities and the entities's sub-property list
		/// </summary>
		/// <param name="props">props</param>
		/// <param name="requireAdminRights">requireAdminRights</param>
		public CWR_Help(bool requireAdminRights = false)
		{
			m_Entities = new Hashtable();
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
			}
			init(requireAdminRights);
		}

		/// <summary>
		/// initialzation of the all the entities properties needed for test
		/// individual entity can be queried based on specified criteria
		/// </summary>
		/// <param name="props">props</param>
		/// <param name="requireAdminRights">requireAdminRights</param>
		public void init(bool requireAdminRights)
		{
			// Get the User and initialize services
			if (m_user == null)
			{
				EntityRequest er = new EntityRequest();
				er.Type = EntityNames.Users;
				er.ReturnAs = EntityNames.Users;
				er.ParentID = EntityManager.Instance.GetRandomExchangeOrg();
				Hashtable userProps = new Hashtable();
				if (requireAdminRights)
				{
					userProps.Add("role", "system administrator");
				}
				userProps.Add("EnabledForACT", "1");
				er.Props = userProps;
				m_Entities = EntityManager.Instance.GetEntities(er);
				m_user = (CRMEntity)m_Entities[EntityNames.Users];

				if (m_user == null)
				{
					m_user = EntityManager.Instance.GetNextUser();
				}
			}
			m_proxy = EntityManager.Instance.GetTestUserProxy(m_user);
		}

		public IOrganizationService Proxy
		{
			get
			{
				return m_proxy;
			}
		}

		public void GetEntitiesForUser(Hashtable props, bool isExchange)
		{
			if (props != null)
			{
				foreach (var item in props.Keys)
				{
					EntityRequest req = new EntityRequest();
					req.Type = item.ToString();
					Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]),
																 new Guid(m_user["OrganizationId"]));
					req.ParentID = g;
					req.ReturnAs = item.ToString();
					//get the specified criteria for the entity
					req.Props = (Hashtable)props[item];
					if (!isExchange)
					{
						m_Entities.Add(item.ToString(), EntityManager.Instance.GetEntities(req)[item.ToString()]);
					}
					else
					{
						m_Entities.Add(item.ToString(), EntityManager.Instance.GetExchangeEntities(req)[item.ToString()]);
					}
				}
			}
		}


		/// <summary>
		/// retrieve all the entities needed for test
		/// </summary>
		/// <returns>Hashtable</returns>
		public Hashtable getEntities()
		{
			return m_Entities;
		}
	}
}
