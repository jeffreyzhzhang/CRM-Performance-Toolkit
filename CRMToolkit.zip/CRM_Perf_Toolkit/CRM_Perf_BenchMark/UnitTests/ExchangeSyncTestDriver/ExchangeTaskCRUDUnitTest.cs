﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting task entity
	/// </summary>
	[TestClass]
	public class ExchangeTaskCRUDUnitTest : CreateBasicExchangeEntityBaseTest
	{

		public override string EntityName
		{
			get { return EntityNames.ExchangeTask; }
		}


		public override string PrintEntityData(Entity entity)
		{
			return String.Format("{0} subject={1}", EntityName, entity["subject"].ToString());
		}


		public override void CreateEntity(string name)
		{
			string timerName = "Task Create Unit Test";

			Entity task = new Entity("task");
			task["subject"] = Utils.GetRandomString(5, 20) + " " + name;
			string taskId = this.CreateEntityInExchange(task, timerName);

			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntityWithoutId(EntityNames.ExchangeTask, g, new string[] { "OwnerId", "ExchangeID", "EntityManagerOwningUser", "Subject" }, new string[] { m_user["systemuserid"], taskId, g.ToString(), task.Attributes["subject"].ToString() });
		}

		/// <summary>
		/// Test creating an task
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_ExchangeTask()
		{
			if (!this.Init())
			{
				//create a task
				this.CreateEntity(this.DeleteIdentifier);
			}
		}

		//test retrieving and updating an task
		[TestMethod()]
		public void UnitTest__Update_ExchangeTask()
		{
			string timer = "Task Update Unit Test";
			Entity task = new Entity("task");
			//find a CRM Entity for update test
			Init("subject", this.UpdateIdentifier,true);
			this.UpdateEntityInExchange(this.EntityName, m_contact, timer, Utils.GetRandomString(5, 10) + " " + this.UpdateIdentifier);
		}

		//test deleting a task
		[TestMethod()]
		public void UnitTest__Delete_ExchangeTask()
		{
			//find a CRM Entity for update test
			if (!Init("subject", this.DeleteIdentifier,true))
			{
				DeleteEntityInExchange(this.EntityName, m_contact, " Delete Exchange Task Entity");
			}
			else
			{
				Trace.WriteLine(" Couldn't Find a Task to Delete so Created one");
			}
		}
	}
}
