﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

using System.Diagnostics;
using System.Globalization;

using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;

namespace CRM_Perf_BenchMark.UnitTests
{
	/// <summary>
	/// Unit testcases for creating, updating, retrieving and deleting Contact entity
	/// </summary>
	[TestClass]
	public class ContactCRUDUnitTest :  CreateBasicEntityBaseTest
	{
		public override string EntityName
		{
			get
			{
				return EntityNames.Contacts;
			}
		}

		public override string PrintEntityData(Entity entity)
		{
			return String.Format("{0} subject={1}", EntityName, entity["lastname"].ToString());
		}

		public override void CreateEntity(string name)
		{
			
			Entity contact = new Entity("contact");
			contact["firstname"] = Utils.GetRandomString(5, 10);
			contact["lastname"] = Utils.GetRandomString(5, 10) + " " + name;

			Guid contactId = this.CreateEntityInCRM(contact, "Create Contact In CRM");
			//add the contact to EMDB
			Guid g = EntityManager.GetOwnerGuid(new Guid(m_user[EntityIDNames.User]), new Guid(m_user["OrganizationId"]));
			EntityManager.Instance.AddEntity(EntityNames.Contacts, g, new string[] { "OwnerId", "ContactID", "EntityManagerOwningUser", "LastName" }, new string[] { m_user["systemuserid"], contactId.ToString(), g.ToString(), contact["lastname"].ToString() });
		}


		#region Create a Contact
		/// <summary>
		/// Test creating an contact
		/// </summary>
		[TestMethod()]
		public void UnitTest__Create_Contact()
		{
			Init();
			this.CreateEntity(this.DeleteIdentifier);
		}
		#endregion

		#region Update an account
		/// <summary>
		/// Test retrieving and updating an contact
		/// </summary>
		[TestMethod()]
		public void UnitTest__Update_Contact()
		{
			string timer = "Contact Update Unit Test";
			Entity contact = new Entity("contact");
			//find a CRM Entity for update test
			//find a CRM Entity for update test
			Init("LastName", this.UpdateIdentifier);
			Microsoft.Xrm.Sdk.Query.ColumnSet attributes = new Microsoft.Xrm.Sdk.Query.ColumnSet(new String[] { "firstname", "lastname" });
			//get the contact in CRM
			contact = proxy.Retrieve(contact.LogicalName, new Guid(m_contact["contactId"]), attributes);
			//update contact address city value
			contact["jobtitle"] = Utils.GetRandomString(3, 10);
			//update the contact
			
			this.UpdateEntityInCRM(contact,timer);
			
		}
		#endregion

		#region Delete an account
		
		/// <summary>
		/// test deleting an contact
		/// </summary>
		[TestMethod()]
		public void UnitTest__Delete_Contact()
		{
			Entity task = new Entity("contact");

			if (!Init("lastname", this.DeleteIdentifier))
			{
				DeleteEntityInCRM("contactid", task, "Delete Contact");
			}
			else
			{
				Trace.WriteLine(" Couldn't Find a Contact to Delete so Created one");
			}
		}
		#endregion

	}
}
