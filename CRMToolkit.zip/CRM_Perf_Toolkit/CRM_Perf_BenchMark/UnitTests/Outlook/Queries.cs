﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace CRM_Perf_BenchMark
{
	internal sealed class QueriesRetriever
	{
		private static Dictionary<string, Collection<Entity>> _savedQueriesByEntityType = new Dictionary<string, Collection<Entity>>();
		private static Dictionary<string, Collection<Entity>> _userQueriesByEntityType = new Dictionary<string, Collection<Entity>>();

		public static Dictionary<string, Collection<Entity>> GetSavedQueriesFromEntityType(string[] entityTypes, IOrganizationService context)
		{
			bool synchUpdateNeeded = false;
			foreach (string entityType in entityTypes)
			{
				if (!_savedQueriesByEntityType.ContainsKey(entityType))
				{
					// if the cache is missing any of the view sets, we need to update synchronously
					synchUpdateNeeded = true;
					break;
				}
			}

			// Call GetAllViews to make sure we have the latest query definitions
			if (synchUpdateNeeded)
			{
				GetAllViews(entityTypes, context);
			}

			Dictionary<string, Collection<Entity>> savedQueries = new Dictionary<string, Collection<Entity>>();

			foreach (string entityType in entityTypes)
			{
				savedQueries.Add(entityType, _savedQueriesByEntityType[entityType]);
			}

			return savedQueries;
		}

		public static Dictionary<string, Collection<Entity>> GetUserQueriesFromEntityType(string[] entityTypes, IOrganizationService context)
		{
			bool synchUpdateNeeded = false;
			foreach (string entityType in entityTypes)
			{
				if (!_userQueriesByEntityType.ContainsKey(entityType))
				{
					// if the cache is missing any of the view sets, we need to update synchronously
					synchUpdateNeeded = true;
					break;
				}
			}

			// Call GetAllViews to make sure we have the latest query definitions
			if (synchUpdateNeeded)
			{
				GetAllViews(entityTypes, context);
			}

			Dictionary<string, Collection<Entity>> userQueries = new Dictionary<string, Collection<Entity>>();

			foreach (string entityType in entityTypes)
			{
				userQueries.Add(entityType, _userQueriesByEntityType[entityType]);
			}

			return userQueries;
		}

		private static void GetAllViews(string[] entityTypes, IOrganizationService context)
		{
			QueryExpression qe = new QueryExpression("savedquery");//EntityNames.SavedQuery);
			qe.ColumnSet = new ColumnSet(true);// new AllColumns();
			OrderExpression order = new OrderExpression();
			order.AttributeName = "name";
			order.OrderType = OrderType.Ascending;
			qe.Orders.Add(order);
			qe.Criteria.Conditions.Add(new ConditionExpression("statecode", ConditionOperator.Equal, 0));

			// create dictionaries to organize the queries by entity type
			Dictionary<string, Collection<Entity>> savedQueries = new Dictionary<string, Collection<Entity>>();
			Dictionary<string, Collection<Entity>> userQueries = new Dictionary<string, Collection<Entity>>();

			foreach (string entityType in entityTypes)
			{
				// allocate the collections to ensure we know that we've asked for these queries
				savedQueries.Add(entityType, new Collection<Entity>());
				userQueries.Add(entityType, new Collection<Entity>());
			}

			// add a condition for all entity types
			qe.Criteria.AddCondition(new ConditionExpression("returnedtypecode", ConditionOperator.In, entityTypes));

			// only get main application views
			//qe.Criteria.AddCondition(new ConditionExpression("querytype", ConditionOperator.Equal, 0));//SavedQueryType.MainApplicationView));

			// Query for system views first
			EntityCollection response = context.RetrieveMultiple(qe);

			foreach (Entity query in response.Entities)
			{
				// read the entity type in the query
				string entityType = (string)query["returnedtypecode"];

				savedQueries[entityType].Add(query);
			}

			// Get all user queries
			qe.EntityName = "userquery";  //EntityNames.UserQuery;

			response = context.RetrieveMultiple(qe);

			foreach (Entity query in response.Entities)
			{
				// read the entity type in the query
				string entityType = (string)query["returnedtypecode"];

				userQueries[entityType].Add(query);
			}

			// compare what we've retrieved with the cached versions to see if we need to update the versions in the cache
			foreach (string entityType in entityTypes)
			{
				// if the view lists haven't been cached at all, cache them now
				if (!_savedQueriesByEntityType.ContainsKey(entityType) && !_userQueriesByEntityType.ContainsKey(entityType))
				{
					// add the lists to the cache
					_savedQueriesByEntityType.Add(entityType, savedQueries[entityType]);
					_userQueriesByEntityType.Add(entityType, userQueries[entityType]);
				}
				// if the view lists are present, check to see if the new view lists are the same
				else if ((_savedQueriesByEntityType.ContainsKey(entityType) && !AreViewListsIdentical(_savedQueriesByEntityType[entityType], savedQueries[entityType])) ||
						(_userQueriesByEntityType.ContainsKey(entityType) && !AreViewListsIdentical(_userQueriesByEntityType[entityType], userQueries[entityType])))
				{
					// something with the views has changed, so replace the cached views
					if (_savedQueriesByEntityType.ContainsKey(entityType))
					{
						_savedQueriesByEntityType.Remove(entityType);
					}

					if (_userQueriesByEntityType.ContainsKey(entityType))
					{
						_userQueriesByEntityType.Remove(entityType);
					}

					// add the lists to the cache
					_savedQueriesByEntityType.Add(entityType, savedQueries[entityType]);
					_userQueriesByEntityType.Add(entityType, userQueries[entityType]);
				}
			}
		}

		private static bool AreViewListsIdentical(Collection<Entity> oldList, Collection<Entity> newList)
		{
			// check the list counts
			if (oldList.Count != newList.Count)
				return false;

			// go through the lists and make sure the versions are the same
			for (int i = 0; i < oldList.Count; i++)
			{
				if ((DateTime)oldList[i]["modifiedon"] != (DateTime)newList[i]["modifiedon"])
					return false;
			}

			// None of the views have changed
			return true;
		}
	}
}
