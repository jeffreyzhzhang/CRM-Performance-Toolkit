﻿using System;
using System.IO;
using System.Net;
using Microsoft.Win32;
using System.Web.Services;
using System.Reflection;
using System.Xml;
using System.Xml.XPath;
using System.Web.Services.Protocols;

using System.Runtime.InteropServices;
using System.Globalization;
using System.Security.Principal;
using Microsoft.Crm;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages.Internal;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CRM_Perf_BenchMark;

using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;

using Microsoft.Crm.Sdk;
using Microsoft.Crm.Sdk.Utility;
using Microsoft.Crm.Extensibility;
using System.Text;

namespace CRM_Perf_BenchMark
{
	[TestClass]
	public class TrackInCrm : OutlookTestBaseClass
	{
		CRMEntity account = null;
		string externalUser = "TestUsrNum@externaldomain.com";

		#region Test init
		[TestInitialize]
		public override void Initialize()
		{
			try
			{
				base.Initialize();
				CreateRegistryForUser(m_nc);
				// Get an existing account from entityManager to set regarding in the current org
				account = RetrieveTestEntity(m_user, EntityNames.Accounts);
			}
			catch (Exception ex)
			{
				base.Cleanup();
				throw ex;
			}
		}
		#endregion

		#region Individual Test Cases

		[TestMethod]
		public void TrackInCrmEmailWithRegardingTM()
		{
			if (m_user == null)
				return;
			try
			{
				Random random = new Random();

				// Step1: Promote the email to CRM.
				Microsoft.Crm.Sdk.Messages.DeliverPromoteEmailRequest deliverEmailRequest = new Microsoft.Crm.Sdk.Messages.DeliverPromoteEmailRequest();
				// Set all required fields
				deliverEmailRequest.Subject = GenerateRandomText(5);
				deliverEmailRequest.To = ConstructAddressList(new CRMEntity[] { m_user });
				deliverEmailRequest.From = externalUser.Replace("Num", random.Next().ToString());
				deliverEmailRequest.Bcc = externalUser.Replace("Num", random.Next().ToString());
				deliverEmailRequest.Cc = externalUser.Replace("Num", random.Next().ToString());

				deliverEmailRequest.Importance = "high";
				deliverEmailRequest.Body = GenerateRandomText(10);
				deliverEmailRequest.MessageId = Guid.NewGuid().ToString();
				deliverEmailRequest.ReceivedOn = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Local);
				deliverEmailRequest.SubmittedBy = deliverEmailRequest.To;

				// We will not attach a file to the e-mail, but the Attachments property is required.
				deliverEmailRequest.Attachments = new EntityCollection();
				deliverEmailRequest.Attachments.EntityName = "activitymimeattachment";

				IOrganizationService orgService = serviceCreator.OrganizationService;

				TestContext.BeginTimer("TrackInCrmEmail:CreateInCrmWithRegarding");

				// Execute the request to promote an email to CRM
				DeliverPromoteEmailResponse deliverEmailResponse = (DeliverPromoteEmailResponse)orgService.Execute(deliverEmailRequest);

				// Step2: Set the regarding field of the email to an existing account in CRM
				UpdateRequest rgdReq = new UpdateRequest();
				rgdReq.RequestId = deliverEmailResponse.EmailId;
				rgdReq.Target = new Entity("email");
				rgdReq.Target["activityid"] = deliverEmailResponse.EmailId;
				rgdReq.Target["regardingobjectid"] = new EntityReference("account", new Guid(account["accountid"]));

				UpdateResponse regardingResponse = new UpdateResponse();
				regardingResponse = (UpdateResponse)orgService.Execute(rgdReq);

				TestContext.EndTimer("TrackInCrmEmail:CreateInCrmWithRegarding");

				// Step3 : Retrieve the item back from crm to update the form reqion
				ColumnSet deliveredMailColumns = new ColumnSet(new string[] { "regardingobjectid", "from", "to", "cc" });
				TestContext.BeginTimer("TrackInCrmEmail:RetrieveFormRegion");
				Entity emailEntity = orgService.Retrieve(EntityName.email.ToString(), deliverEmailResponse.EmailId, deliveredMailColumns);
				TestContext.EndTimer("TrackInCrmEmail:RetrieveFormRegion");

				System.Diagnostics.Trace.WriteLine("User:" + m_userName + " TrackInCrmEmailWith Regarding Completed at:" + DateTime.Now.ToString());
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}

		}

		[TestMethod]
		public void TrackInCrmAppointmentWithRegardingTM()
		{
			if (m_user == null)
				return;

			try
			{
				TestContext.BeginTimer("TrackInCrmAppointment:CreateInCrmWithregarding");

				IOrganizationService orgService = serviceCreator.OrganizationService;

				// Step1: Book an appointment in CRM               

				Entity appointment = new Entity("appointment");
				appointment["subject"] = GenerateRandomText(3) + ExchangeSyncLoadMapper.CreateAppointmentAppendable();
				appointment["location"] = GenerateRandomText(1);
				appointment["description"] = GenerateRandomText(10);

				Random r1 = new Random();
				DateTime startDate = DateTime.Now.AddDays(r1.Next(50));

				appointment["scheduledstart"] = startDate;
				appointment["scheduledend"] = startDate;

				DateTime start = DateTime.Now.AddHours(r1.Next(11));
				DateTime end = start.AddHours(1);

				appointment["starttime"] = start;
				appointment["endtime"] = end;

				Entity organizer = new Entity("activityparty");
				organizer["partyid"] = new EntityReference("systemuser", new Guid(m_user["systemuserid"]));
				appointment["organizer"] = new Entity[] { organizer };

				Entity party = new Entity("activityparty");
				party["partyid"] = new EntityReference("account", new Guid(account["accountid"]));
				appointment["requiredattendees"] = new Entity[] { party };

				BookRequest m_request = new BookRequest();
				m_request.Target = appointment;

				// Execute the request.
				Microsoft.Crm.Sdk.Messages.BookResponse booked = (BookResponse)orgService.Execute(m_request);


				//Step 2: Update the regarding object for the appointment

				UpdateRequest rgdReq = new UpdateRequest();
				rgdReq.RequestId = booked.ValidationResult.ActivityId;
				rgdReq.Target = new Entity("appointment");
				rgdReq.Target["activityid"] = booked.ValidationResult.ActivityId;
				rgdReq.Target["regardingobjectid"] = new EntityReference("account", new Guid(account["accountid"]));


				UpdateResponse regardingResponse = new UpdateResponse();
				regardingResponse = (UpdateResponse)orgService.Execute(rgdReq);

				TestContext.EndTimer("TrackInCrmAppointment:CreateInCrmWithregarding");

				// Step3 : Retrieve the item back from crm to update the form reqion
				TestContext.BeginTimer("TrackInCrmAppointment:RetrieveFormRegion");

				ColumnSet deliveredAptColumns = new ColumnSet(new string[] { "regardingobjectid", "organizer", "requiredattendees" });

				Entity deliveredApt = orgService.Retrieve(EntityName.appointment.ToString(), booked.ValidationResult.ActivityId, deliveredAptColumns);

				TestContext.EndTimer("TrackInCrmAppointment:RetrieveFormRegion");

				System.Diagnostics.Trace.WriteLine(string.Format("User: {0} TrackInCrmAppointmentWithRegarding completed at: {1}", m_userName, DateTime.Now.ToString()));
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}

		}

		[TestMethod]
		public void TrackInCrmContactWithRegardingTM()
		{
			if (m_user == null)
				return;

			try
			{
				IOrganizationService orgService = serviceCreator.OrganizationService;

				// Create the contact object.

				Entity entity = new Entity("contact");

				String Address = GenerateRandomText(3).Trim();
				String singleRandomWord = GenerateRandomText(1).Trim();

				entity["firstname"] = singleRandomWord;
				entity["lastname"] = singleRandomWord + ExchangeSyncLoadMapper.CreateContactAppendable();
				entity["address1_line1"] = Address;
				entity["address1_line2"] = Address;
				entity["address1_city"] = singleRandomWord;
				entity["address1_stateorprovince"] = singleRandomWord;
				entity["emailaddress1"] = externalUser.Replace("Num", new Random().Next().ToString());

				entity["parentcustomerid"] = new EntityReference("account", new Guid(account["accountid"]));

				TestContext.BeginTimer("TrackInCrmContact:CreateInCrm");

				// Create the contact in Microsoft Dynamics CRM.				
				Guid entityId = orgService.Create(entity);

				TestContext.EndTimer("TrackInCrmContact:CreateInCrm");

				System.Diagnostics.Trace.WriteLine(string.Format("User: {0} TrackInCrmContactWithRegarding completed at: {1}", m_userName, DateTime.Now.ToString()));
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
		}

		[TestMethod]
		public void TrackInCrmTaskWithRegardingTM()
		{
			if (m_user == null)
				return;

			try
			{
				IOrganizationService orgService = serviceCreator.OrganizationService;

				// Step1: Create the contact object with regarding object set to an existing account in crm               
				Entity entity = new Entity("task");
				entity["subject"] = GenerateRandomText(2) + ExchangeSyncLoadMapper.CreateTaskAppendable();
				entity["description"] = GenerateRandomText(10);
				entity["regardingobjectid"] = new EntityReference("account", new Guid(account["accountid"]));

				TestContext.BeginTimer("TrackInCrmAppointment:CreateInCrm");

				// Create the contact in CRM.				
				Guid entityId = orgService.Create(entity);

				TestContext.EndTimer("TrackInCrmAppointment:CreateInCrm");

				System.Diagnostics.Trace.WriteLine(string.Format("User:{0}TrackInCrmTaskWithRegarding completed at {1}", m_userName, DateTime.Now.ToString()));
			}
			catch (SoapException e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.Detail.InnerXml);
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}
			catch (Exception e)
			{
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} Begin Got SOAP exception", m_userName));
				System.Diagnostics.Trace.WriteLine(e.ToString());
				System.Diagnostics.Trace.WriteLine(string.Format("SyncToOutlook:User: {0} End Got SOAP exception", m_userName));
				throw e;
			}

		}

		#endregion

		#region Private Methods

		private void CreateRegistryForUser(System.Net.NetworkCredential nc)
		{
			string userId = m_user["systemuserid"];
			string businessId = m_user["businessunitid"];

			RegistryKey userRegKey = Registry.CurrentUser.OpenSubKey(m_clientKeyPath, true);
			if (userRegKey == null)
				userRegKey = Registry.CurrentUser.CreateSubKey(m_clientKeyPath);

			//we need to create - BusinessId, UserId, ServerUrl
			userRegKey.SetValue("BusinessId", "{" + businessId + "}", RegistryValueKind.String);
			userRegKey.SetValue("UserId", "{" + userId + "}", RegistryValueKind.String);
			userRegKey.SetValue("ServerUrl", m_CrmServer + "/MSCRMServices", RegistryValueKind.String);
		}

		/// <summary>
		/// Generates a random Text
		/// </summary>
		/// <param name="words">Number of words</param>
		/// <returns>Random text created with the number of words passed in </returns>
		public static string GenerateRandomText(int numWords)
		{
			StringBuilder subject = new StringBuilder();

			for (int i = 0; i < numWords; i++)
			{
				subject.Append(Guid.NewGuid().ToString());

				subject.Append(" ");
			}

			return subject.ToString();
		}

		/// <summary>
		/// Constructs an address list
		/// </summary>
		/// <param name="users">user list</param>
		/// <returns>User address lists</returns>
		private static string ConstructAddressList(CRMEntity[] users)
		{
			StringBuilder address = new StringBuilder();

			for (int i = 0; i < users.Length; i++)
			{
				address.Append(users[i]["InternalEmailAddress"]);
				address.Append(";");
			}
			return address.ToString();
		}

		#endregion
	}
}