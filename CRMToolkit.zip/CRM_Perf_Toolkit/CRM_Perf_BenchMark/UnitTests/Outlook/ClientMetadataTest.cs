﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Globalization;
using System.Linq;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages.Internal;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// A test class for rich client metadata
	/// </summary>
	[TestClass]
	public sealed class ClientMetadataTest : OutlookTestBaseClass
	{
		private static readonly object locker = new object();
		private static readonly Dictionary<Guid, DateTime> checkedNotificationPerUser = new Dictionary<Guid, DateTime>();
		private static readonly Dictionary<Guid, DateTime> metadataDiffLastUpdatePerUser = new Dictionary<Guid, DateTime>();
		private static readonly Dictionary<Guid, long> metadataDiffVersionPerUser = new Dictionary<Guid, long>();
		private static readonly Dictionary<Guid, int> languagePerUser = new Dictionary<Guid, int>();
		private static string organizationVersion;

		#region test initialization
		[TestInitialize]
		public override void Initialize()
		{
			EntityManager.Instance.IsPerUserPerRun = true;
			base.Initialize();

			// populate initial values in thread-safe manner
			try
			{
				lock (locker)
				{
					if (!checkedNotificationPerUser.ContainsKey(UserId))
					{
						checkedNotificationPerUser.Add(UserId, (DateTime)SqlDateTime.MinValue);
						metadataDiffLastUpdatePerUser.Add(UserId, DateTime.MinValue);
						metadataDiffVersionPerUser.Add(UserId, 0);

						int languageId = RetrieveProvisionedLanguages().FirstOrDefault();
						languagePerUser.Add(UserId, languageId);

						if (string.IsNullOrWhiteSpace(organizationVersion))
						{
							organizationVersion = RetrieveOrganizationVersion();
						}
					}
				}
			}
			catch (Exception ex)
			{
				base.Cleanup();
				throw ex;
			}
		}
		#endregion

		#region Individual Test Cases

		/// <summary>
		/// Check for notifications for rich client, saves last timestamp of notification for future tests
		/// </summary>
		/// <remarks>
		/// One of the ways CRM client checks for metadata updates - the other one is RetrieveTimeStampRichClient.
		/// Applicable to CRM 2011 client and future versions
		/// </remarks>
		[TestMethod]
		public void CheckNotificationsRichClient()
		{
			IOrganizationService organizationService = serviceCreator.OrganizationService;
			CheckNotificationsRequest request = new CheckNotificationsRequest();
			request.Events = new int[] { };
			request.LastChecked = checkedNotificationPerUser[UserId];
			CheckNotificationsResponse response = (CheckNotificationsResponse)organizationService.Execute(request);

			DataCollection<Entity> notifications = response.EntityCollection.Entities;
			if (notifications != null && notifications.Count > 0)
			{
				lock (locker)
				{
					checkedNotificationPerUser[UserId] = notifications.Max(notification => (DateTime)notification["createdon"]);
				}
			}
		}

		/// <summary>
		/// Retrieve timestamp to verify if metadata update is needed, called during loading metadata cache (boot) and go offline (v5 client)
		/// </summary>
		/// <remarks>
		/// Applicable to CRM 2011 client only, future version will use CheckNotificationsRichClient
		/// </remarks>
		[TestMethod]
		public void RetrieveTimeStampRichClient()
		{
			IOrganizationService organizationService = serviceCreator.OrganizationService;
			OrganizationRequest request = new OrganizationRequest("RetrieveTimestamp");
			OrganizationResponse response = organizationService.Execute(request);
		}

		/// <summary>
		/// Retrieve full metadadata xml used in the rich client (v5 client)
		/// </summary>
		[TestMethod]
		public void RetrieveFullMetadataForRichClient()
		{
			IOrganizationService organizationService = serviceCreator.OrganizationService;
			OrganizationRequest request = new OrganizationRequest("RetrieveMetadataForRichClient");
			OrganizationResponse response = organizationService.Execute(request);
			byte[] decompressedData = (byte[])response["Metadata"];
		}

		/// <summary>
		/// Call to retrieve metadata using diff based API for rich client
		/// Will happen when: new timestamp >= old timestamp
		/// </summary>
		[TestMethod]
		public void RetrieveMetadataChangesForRichClientDiffSync()
		{
			long version = metadataDiffVersionPerUser[UserId];
			DateTime syncTime = version <= 0 ? DateTime.MinValue : metadataDiffLastUpdatePerUser[UserId];
			RetrieveMetadataDiffBased(version, syncTime, languagePerUser[UserId], organizationVersion);
		}

		/// <summary>
		/// Call to retrieve metadata using diff based API for rich client, including labels
		/// Will happen when: old timestamp >= new timespamp and user language != server language
		/// </summary>
		[TestMethod]
		public void RetrieveMetadataChangesForRichClientChangeLanguage()
		{
			long version = metadataDiffVersionPerUser[UserId];
			DateTime syncTime = version <= 0 ? DateTime.MinValue : metadataDiffLastUpdatePerUser[UserId];
			int language = RetrieveProvisionedLanguages().LastOrDefault();
			RetrieveMetadataDiffBased(version, syncTime, language, organizationVersion);
		}

		/// <summary>
		/// Call to retrieve metadata using diff based API for rich client (full sync)
		/// Will happen when: old timestamp == 0 or old timestamp > 365 days old
		/// </summary>
		[TestMethod]
		public void RetrieveMetadataChangesForRichClientFullSync()
		{
			long version = 0;
			DateTime syncTime = version <= 0 ? DateTime.MinValue : metadataDiffLastUpdatePerUser[UserId];
			RetrieveMetadataDiffBased(version, syncTime, languagePerUser[UserId], organizationVersion);
		}

		#endregion

		#region Private Methods

		private void RetrieveMetadataDiffBased(long lastTimeStamp, DateTime lastSyncTime, int lastUserLanguage, string metadataVersion)
		{
			IOrganizationService organizationService = serviceCreator.OrganizationService;
			OrganizationRequest organizationRequest = new OrganizationRequest("RetrieveMetadataChangesForRichClient");
			organizationRequest["LastTimestamp"] = lastTimeStamp;
			organizationRequest["LastSyncTime"] = lastSyncTime;
			organizationRequest["LastUserLanguage"] = lastUserLanguage;
			organizationRequest["MetadataVersion"] = organizationVersion;
			OrganizationResponse organizationResponse = organizationService.Execute(organizationRequest);
			lock (locker)
			{
				metadataDiffVersionPerUser[UserId] = Convert.ToInt64(organizationResponse["NewTimestamp"], CultureInfo.InvariantCulture); //Save off the Time Stamp to be used for inserts into the tables.
				metadataDiffLastUpdatePerUser[UserId] = Convert.ToDateTime(organizationResponse["NewSyncTime"], CultureInfo.InvariantCulture);
			}
		}

		private IList<int> RetrieveProvisionedLanguages()
		{
			RetrieveProvisionedLanguagesRequest request = new RetrieveProvisionedLanguagesRequest();
			RetrieveProvisionedLanguagesResponse response = (RetrieveProvisionedLanguagesResponse)serviceCreator.OrganizationService.Execute(request);

			if (response != null && response.RetrieveProvisionedLanguages != null)
			{
				return response.RetrieveProvisionedLanguages;
			}

			return new int[] { };
		}

		private string RetrieveOrganizationVersion()
		{
			RetrieveVersionRequest request = new RetrieveVersionRequest();
			RetrieveVersionResponse response = (RetrieveVersionResponse)this.serviceCreator.OrganizationService.Execute(request);
			if (response != null && !string.IsNullOrWhiteSpace(response.Version))
			{
				return response.Version;
			}

			return string.Empty;
		}

		#endregion
	}
}
