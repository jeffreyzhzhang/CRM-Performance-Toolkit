﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Crm;
using Microsoft.Crm.Outlook;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CRM_Perf_BenchMark
{
	internal sealed class TestDataCache
	{
		int maxItemsToKeep = 200;

		public string EntityType { get; set; }
		public string CacheName { get; set; }

		string primaryId;
		string fetchXml;

		DateTime _lastInclusionUpdateTime = DateTime.Now;
		long _lastInclusionUpdateMinActiveRowVersion = 0;

		DateTime _lastExclusionUpdateTime = DateTime.Now;
		Guid _lastExclusionUpdateItemId;

		const int ExclusionUpdatePageSize = 50;

		List<Guid> table;

		private TestContext m_testContext;
		public TestContext TestContext
		{
			get { return m_testContext; }
			set { m_testContext = value; }
		}
		
		internal TestDataCache(string fetchXml, string entityType, string primaryId, string cacheName)
		{
			this.EntityType = entityType;
			this.primaryId = primaryId;
			this.CacheName = cacheName;

			table = new List<Guid>(maxItemsToKeep);

			this.fetchXml = fetchXml;
		}


		internal RetrieveMultipleRequest FetchIncrementalInclusionData_GetRequest()
		{
			// trim extra items if there're too many of them
			if (table.Count > maxItemsToKeep)
			{
				table.RemoveRange(0, table.Count - maxItemsToKeep);
			}

			// Construct fetch
			FetchType fetch;
			using (XmlReader xmlReader = SharedUtil.CreateXmlReader(fetchXml))
			{
				fetch = (FetchType)new XmlSerializer(typeof(FetchType)).Deserialize(xmlReader);
			}
			fetch.count = 0.ToString(CultureInfo.InvariantCulture);
			fetch.page = 0.ToString(CultureInfo.InvariantCulture);
			fetch.pagingcookie = null;
			fetch.minactiverowversion = true;

			// Create the helper filters for "versionNumber>=N"
			filter versionNumberGEfilter = new filter();
			{
				condition condition = new condition();
				condition.attribute = "versionnumber";
				condition.@operator = @operator.ge;
				condition.value = XmlConvert.ToString(_lastInclusionUpdateMinActiveRowVersion);
				versionNumberGEfilter.Items = new object[] { condition };
			}

			// The last retrieve: all inner joins has no versionNumber conditions and the direct entity has the "versionNumber>=N" one
			List<object> fetchItems = new List<object>(((FetchEntityType)fetch.Items[0]).Items);
			fetchItems.Add(versionNumberGEfilter);
			((FetchEntityType)fetch.Items[0]).Items = fetchItems.ToArray();
			string expr = XSerialize(fetch);
			FetchExpression fetchExpression = new FetchExpression(expr);

			RetrieveMultipleRequest request = new RetrieveMultipleRequest();
			request.Query = fetchExpression;
			return request;
		}

		internal int FetchIncrementalInclusionData_Post(EntityCollection collection)
		{
			int itemsFetched = 0;
			foreach (Entity entity in collection.Entities)
			{
				Guid id = entity.Id;

				// do not add more than max number of items
				if ((table.Count < maxItemsToKeep) && (!table.Contains(id)))
				{
					table.Add(entity.Id);
					itemsFetched++;
				}
			}

			long newInclusionUpdateMinActiveRowVersion;
			if (long.TryParse(collection.MinActiveRowVersion, out newInclusionUpdateMinActiveRowVersion))
			{
				_lastInclusionUpdateMinActiveRowVersion = newInclusionUpdateMinActiveRowVersion;
			}
			_lastInclusionUpdateTime = DateTime.Now;

			return itemsFetched;
		}

		internal int FetchIncrementalExclusionData(IOrganizationService service)
		{
			int itemsFetched = 0;

			IEnumerable<Guid> Ids;
			int lastUpdateIndex = table.IndexOf(_lastExclusionUpdateItemId);
			Ids = (lastUpdateIndex >= 0) ? table.Skip(lastUpdateIndex).Take(ExclusionUpdatePageSize) : new List<Guid>();

			//Select the next page worth of item IDs from the existing rows (sorted by the item IDs) and perform a UpdateFromCacheDb with that ID list
			if (Ids.Count() >= ExclusionUpdatePageSize)
			{
				_lastExclusionUpdateItemId = Ids.Last();
			}
			else
			{
				_lastExclusionUpdateItemId = Guid.Empty;
			}
			_lastExclusionUpdateTime = DateTime.Now;

			if (Ids.Count() > 0)
			{
				// Construct fetch
				FetchType fetch;
				using (XmlReader xmlReader = SharedUtil.CreateXmlReader(fetchXml))
				{
					fetch = (FetchType)new XmlSerializer(typeof(FetchType)).Deserialize(xmlReader);
				}
				fetch.count = 0.ToString(CultureInfo.InvariantCulture);
				fetch.page = 0.ToString(CultureInfo.InvariantCulture);
				fetch.pagingcookie = null;
				fetch.minactiverowversion = false;

				filter filter = new filter();
				condition ce = new condition();
				// the instanceids will always be for the main record type, so per-user sources need to filter by objectid
				ce.attribute = primaryId;
				ce.@operator = @operator.@in;
				ce.Items = Ids.Count() > 0 ? Ids.Select(id => new conditionValue { Value = id.ToString() }).ToArray() : new conditionValue[] { new conditionValue { Value = Guid.Empty.ToString() } };
				filter.Items = new object[] { ce };

				List<object> fetchItems = new List<object>(((FetchEntityType)fetch.Items[0]).Items);
				fetchItems.Add(filter);
				((FetchEntityType)fetch.Items[0]).Items = fetchItems.ToArray();
				string expr = XSerialize(fetch);
				FetchExpression fetchExpression = new FetchExpression(expr);

				RetrieveMultipleRequest request = new RetrieveMultipleRequest();
				request.Query = fetchExpression;

				EntityCollection collection = ((RetrieveMultipleResponse)service.Execute(request)).EntityCollection;
				List<Guid> returnedIds = collection.Entities.Select(obj => obj.Id).ToList();
				List<Guid> toDelete = Ids.Except(returnedIds).ToList();
				foreach (Guid id in toDelete)
				{
					if (table.Remove(id))
					{
						itemsFetched++;
					}
				}
			}
			return itemsFetched;
		}

		private static XmlSerializer fetchTypeSerializer = new XmlSerializer(typeof(FetchType));
		internal static string XSerialize(object o)
		{
			StringBuilder xml = new StringBuilder();
			XmlWriterSettings settings = new XmlWriterSettings();
			settings.OmitXmlDeclaration = true;
			settings.Indent = false;
			using (XmlWriter xmlWriter = XmlWriter.Create(xml, settings))
			{
				XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
				namespaces.Add("", "");
				fetchTypeSerializer.Serialize(xmlWriter, o, namespaces);
			}
			return xml.ToString();
		}
	}
}
