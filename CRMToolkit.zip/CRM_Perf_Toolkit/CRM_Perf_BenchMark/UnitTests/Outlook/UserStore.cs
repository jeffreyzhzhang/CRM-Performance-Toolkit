﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Crm.Outlook;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Static class containing all active caches for all users
	/// </summary>
	internal sealed class UserStore
	{
		/// <summary>
		/// This is the common representation of mapi folders: entitytype viewname
		/// </summary>
		public static List<Tuple<string, string>> MapiFolders;

		public static Dictionary<Guid, Dictionary<Tuple<string, string>, TestDataCache>> TestCache;

		private UserStore()
		{
		}

		static UserStore()
		{
			// create a list of folders that are going to be pinned during test case execution
			MapiFolders = new List<Tuple<string, string>>();
			MapiFolders.Add(Tuple.Create("contact", "Active Contacts"));
			MapiFolders.Add(Tuple.Create("contact", "My Active Contacts"));
			MapiFolders.Add(Tuple.Create("account", "Active Accounts"));
			MapiFolders.Add(Tuple.Create("account", "My Active Accounts"));
			MapiFolders.Add(Tuple.Create("opportunity", "My Open Opportunities"));
			MapiFolders.Add(Tuple.Create("opportunity", "Open Opportunities"));
			MapiFolders.Add(Tuple.Create("salesorder", "My Orders"));
			MapiFolders.Add(Tuple.Create("quote", "My Quotes"));
			MapiFolders.Add(Tuple.Create("lead", "My Open Leads"));
			MapiFolders.Add(Tuple.Create("lead", "Open Leads"));

			TestCache = new Dictionary<Guid, Dictionary<Tuple<string, string>, TestDataCache>>();
		}

		public static void AddCache(Guid userId, Tuple<string, string> mapiFolder, TestDataCache cache)
		{
			if (!TestCache.ContainsKey(userId))
			{
				TestCache.Add(userId, new Dictionary<Tuple<string, string>, TestDataCache>());
			}

			// cache already exists
			if (TestCache[userId].ContainsKey(mapiFolder))
			{
				return;
			}

			TestCache[userId].Add(mapiFolder, cache);
		}

		public static TestDataCache GetCache(Guid userId, Tuple<string, string> mapiFolder)
		{
			if ((!TestCache.ContainsKey(userId)) &&
				(!TestCache[userId].ContainsKey(mapiFolder)))
			{
				throw new ArgumentException("No such cache exists.");
			}

			return TestCache[userId][mapiFolder];
		}

		/// <summary>
		/// Get the next Mapi folder that has not been pinned (made active)
		/// </summary>
		/// <param name="userId">User guid</param>
		/// <returns>Folder to be made active</returns>
		public static Tuple<string, string> GetNextMapiFolderToPin(Guid userId)
		{
			if (!TestCache.ContainsKey(userId))
			{
				TestCache.Add(userId, new Dictionary<Tuple<string, string>, TestDataCache>());
			}

			return MapiFolders.Except(TestCache[userId].Keys).FirstOrDefault();
		}

		/// <summary>
		/// Return all active caches for the user, or null if there are no caches
		/// </summary>
		/// <param name="userId">User guid</param>
		/// <returns>Collection of active caches</returns>
		public static ICollection<TestDataCache> GetUserCaches(Guid userId)
		{
			if (!TestCache.ContainsKey(userId))
			{
				return null;
			}
			else
			{
				return TestCache[userId].Values;
			}
		}
	}
}
