﻿using System;
using System.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk.Client;
using ServiceCreator;

namespace CRM_Perf_BenchMark
{
	/// <summary>
	/// Abstract base class for all Outlook test cases
	/// </summary>
	[TestClass]
	public abstract class OutlookTestBaseClass : UnitTestBase
	{
		[TestInitialize()]
		public override void Initialize()
		{
			try
			{
				isOutlookUser = true;
				base.Initialize();
			}
			catch (Exception ex)
			{
				base.Cleanup();
				throw ex;
			}
				
		}

	}
}
