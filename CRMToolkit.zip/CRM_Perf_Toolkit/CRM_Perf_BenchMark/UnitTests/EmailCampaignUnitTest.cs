﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class EmailCampaignUnitTest : UnitTestBase
	{
		public EmailCampaignUnitTest()
			: base()
		{}

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		[ClassInitialize()]
		public static void ClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
			}
		}
		#endregion

		/// <summary>
		/// Sends Email Campaign of size 100.
		/// </summary>
		[TestMethod]
		public void SendEmailCampaignOfSizeHundred()
		{
			DateTime startTime = DateTime.Now;
			string orgName = m_user["organizationname"];
			List<Guid> contactIds = ServerSideSyncHelper.GetValidContacts(orgName, 100);

			QueryExpression query = new QueryExpression("contact");
			query.ColumnSet = new ColumnSet("contactid");
			query.Criteria = new FilterExpression();
			FilterExpression filter = query.Criteria.AddFilter(LogicalOperator.Or);
			foreach (Guid contactId in contactIds)
			{
				filter.AddCondition("contactid", ConditionOperator.Equal, contactId);
			}

			Entity emailRecord = new Entity();
			emailRecord.LogicalName = "email";
			emailRecord["subject"] = "ServerSideSyncCampaign " + Utils.GetRandomString(15, 20);

			PropagateByExpressionRequest quickCampaignRequest = new PropagateByExpressionRequest();
			quickCampaignRequest.Activity = emailRecord;
			quickCampaignRequest.ExecuteImmediately = true;
			quickCampaignRequest.FriendlyName = "Server Side sync Quick Campaign";
			quickCampaignRequest.Owner = new EntityReference("systemuser", new Guid(m_user["systemuserid"]));
			quickCampaignRequest.OwnershipOptions = PropagationOwnershipOptions.Caller;
			quickCampaignRequest.PostWorkflowEvent = true;
			quickCampaignRequest.QueryExpression = query;
			quickCampaignRequest.SendEmail = true;
			quickCampaignRequest.TemplateId = new Guid("07B94C1D-C85F-492F-B120-F0A743C540E6");

			if (Proxy == null)
			{
				throw new Exception("Proxy is null");
			}
			PropagateByExpressionResponse quickCampaignResponse = (PropagateByExpressionResponse)Proxy.Execute(quickCampaignRequest);
		}
	}
}
