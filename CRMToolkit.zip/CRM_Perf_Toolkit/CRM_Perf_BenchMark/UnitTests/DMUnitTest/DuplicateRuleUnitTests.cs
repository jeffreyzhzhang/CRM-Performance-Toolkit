	using System.Text;
	using System.Collections.Generic;
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using System.Xml;
	using System.Net;
	using System.IO;
	using System.Web.Services.Protocols;
	using System;
	  
	using Microsoft.Win32;
	
using Microsoft.Xrm.Sdk;
using ServiceCreator;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
	
	namespace CRM_Perf_BenchMark.DMUnitTest
	{
		/// <summary>
		/// Summary description for DMUnitTest1
		/// </summary>
		[TestClass]
		public class DuplicateRuleUnitTests : UnitTestBase
		{
			private static string resultDir =  string.Format(@"{0}\PerfResult", Environment.SystemDirectory.Split(new char[] { '\\' }, 2)[0]);
	
			#region Additional test attributes
			//
			// You can use the following additional attributes as you write your tests:
			//
			// Use ClassInitialize to run code before running the first test in the class
			[ClassInitialize()]
			public static void MyClassInitialize(TestContext testContext)
			{
				//this is the directory where all perf results are stored
				if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
				{
					Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
				}
				EntityManager.Instance.IsPerUserPerRun = true;
			}
			
			
			#endregion
	
			#region Individual Test Cases


			[TestMethod()]
			public void DMUnitTest_PublishSingleEntityRuleOnContacts()
			{
				PerfTestPublishRuleForAGivenRuleName("Rule5");
			}
	
			[TestMethod()]
			public void DMUnitTest_PublishCrossEntityRuleOnContactsAndAccount()
			{
				PerfTestPublishRuleForAGivenRuleName("Rule4");
			}
	
			[TestMethod()]
			public void DMUnitTest_BulkDetectDuplicates()
			{
				try
				{
					QueryExpression query = new QueryExpression();
					query.EntityName = "contact";
	
					//submit job to async
					DateTime startTime = DateTime.UtcNow;
					string SummaryFile = resultDir + @"\BulkDetectDuplicate_" + startTime.Ticks.ToString() + ".log";
					Guid asyncJobID = BulkDetectDup(query);
	
					StreamWriter logWriter = new StreamWriter(SummaryFile);
					lock (logWriter)
					{
						logWriter.WriteLine("Logging test reult for Bulk De-dup ...");
						logWriter.WriteLine("-----------------------------------------");
						logWriter.WriteLine("Bulk de-dup job id " + asyncJobID);
						logWriter.WriteLine("Test started at " + startTime);
						logWriter.Flush();
						logWriter.Close();
					}
				}
				catch (Exception e)
				{
					System.Diagnostics.Trace.WriteLine(e.Message);
					throw e;
				}
			}
	
			#endregion
	
			#region Private Methodes
	
			private void PerfTestPublishRuleForAGivenRuleName(string Rulename)
			{
				Guid dupruleID = Guid.Empty;
				try
				{
					DateTime oDateTime = System.DateTime.UtcNow;
					string timestamp = oDateTime.ToString();
					string randomnametoappend = oDateTime.Millisecond.ToString();
					timestamp = timestamp.Replace('/', '_');
					timestamp = timestamp.Replace(':', '_');
					string SummaryFile = resultDir + @"\PerfRulePublishSummary" + timestamp + ".log";
	
					DateTime before = System.DateTime.Now;
	
					dupruleID = CreateDuplicateRule(Rulename);
					Guid rulePublishJobId = PublishRule(dupruleID);
	
					StreamWriter logWriter = new StreamWriter(SummaryFile);
					lock (logWriter)
					{
						logWriter.WriteLine("Logging test reult for Single EntityRule Publish ...");
						logWriter.WriteLine("----------------------------------------------------");
						logWriter.WriteLine("Rule publish job id " + rulePublishJobId);
						logWriter.WriteLine("Test started at " + oDateTime);
						logWriter.Flush();
						logWriter.Close();
					}
	
				}
				catch (Exception e)
				{
					System.Diagnostics.Trace.WriteLine(e.Message);
					throw e;
				}
			}
	
			private Guid CreateDuplicateRule(string ruleNodeName)
			{
				
				string configDirKeyPath = "SOFTWARE\\Wow6432Node\\Microsoft\\MSCRMToolkit";
				string configDir = null;

				if (Registry.LocalMachine.OpenSubKey(configDirKeyPath) != null)
				{
					RegistryKey regKey = Registry.LocalMachine.OpenSubKey(configDirKeyPath);
					configDir = (string)regKey.GetValue("CRM_Perf_Toolkit_ConfigDir", Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles");
				}
				else
				{
					//setting the default directory of configsettings.xml
					configDir = Path.GetPathRoot(Environment.CurrentDirectory) + "\\CRMToolkit\\ConfigFiles";
				}
				var xmlFilePath = string.Format(@"{0}\DuplicateRules_Perf.xml", configDir);
				var reader = Utils.GetXmlReaderForXmlFile(xmlFilePath);
				var doc = new XmlDocument();
				doc.Load(reader);

				XmlElement root = doc.DocumentElement;
				XmlNode rulenode = root.SelectSingleNode("/DuplicateRules/" + ruleNodeName);
				XmlNode ruleAttribList = rulenode.FirstChild;
				string name, desc, baseEnt, crossEnt, baseAttrib, crossAttrib, param, casesen, opercode;
				int dupruleoper = 0;

				Entity entity = new Entity("duplicaterule");
				Entity[] rulecondn = null;
				name = ruleAttribList.Attributes.GetNamedItem("name").InnerText;
				entity["name"] = name.Equals("") ? null : name;

				desc = ruleAttribList.Attributes.GetNamedItem("desc").InnerText;
				entity["description"] = desc.Equals("") ? null : desc;

				System.Diagnostics.Trace.WriteLine("Creating Rule:" + entity["description"]);

				baseEnt = ruleAttribList.Attributes.GetNamedItem("baseentity").InnerText;
				entity["baseentityname"] = baseEnt.Equals("") ? null : baseEnt;

				crossEnt = ruleAttribList.Attributes.GetNamedItem("matchingentity").InnerText;
				entity["matchingentityname"] = crossEnt.Equals("") ? null : crossEnt;

				casesen = ruleAttribList.Attributes.GetNamedItem("operatorcase").InnerText;
				if (!casesen.Equals(""))
				{
					entity["iscasesensitive"] = bool.Parse(casesen);
				}

				WhoAmIRequest uReq = new WhoAmIRequest();
				WhoAmIResponse uResp;

				try
				{
					uResp = (WhoAmIResponse)Proxy.Execute(uReq);
				}
				catch (Exception e)
				{
					throw e;
				}
			   
				entity["ownerid"] = new EntityReference("systemuser", uResp.UserId);

				Guid ruleid = Guid.Empty;
				int totalTimeToCreateRule = 0;
				try
				{
					DateTime before = DateTime.Now;
					ruleid = Proxy.Create(entity);
					DateTime after = DateTime.Now;
					totalTimeToCreateRule += Convert.ToInt32(((TimeSpan)(after - before)).TotalMilliseconds);
					System.Diagnostics.Trace.WriteLine("DuplicateRule " + ruleid + " created");
				}
				catch (Exception e)
				{
					System.Diagnostics.Trace.WriteLine("SoapException when creating duplicaterule :" + e.ToString());
					return Guid.Empty;
				}

				XmlNode ruleconditions = ruleAttribList.NextSibling;

				if (ruleconditions != null && ruleconditions.HasChildNodes)
				{
					rulecondn = new Entity[ruleconditions.ChildNodes.Count];
					for (int i = 0; i < ruleconditions.ChildNodes.Count; i++)
					{
						rulecondn[i] = new Entity("duplicaterulecondition");

						baseAttrib = ruleconditions.ChildNodes[i].Attributes.GetNamedItem("baseattribute").InnerText;
						rulecondn[i]["baseattributename"] = baseAttrib.Equals("") ? null : baseAttrib;

						crossAttrib = ruleconditions.ChildNodes[i].Attributes.GetNamedItem("matchingattribute").InnerText;
						rulecondn[i]["matchingattributename"] = crossAttrib.Equals("") ? null : crossAttrib;

						opercode = ruleconditions.ChildNodes[i].Attributes.GetNamedItem("operatorcode").InnerText;
						switch (opercode)
						{
							case "Equals":
								dupruleoper = 0;
								break;
							case "FirstN":
								dupruleoper = 1;
								break;
							case "LastN":
								dupruleoper = 2;
								break;
							case "EqualsDateOnly":
								dupruleoper = 3;
								break;
							case "EqualsDateAndTime":
								dupruleoper = 4;
								break;

						}
							
						rulecondn[i]["operatorcode"] = opercode.Equals("") ? null : new OptionSetValue((int)dupruleoper);
						param = ruleconditions.ChildNodes[i].Attributes.GetNamedItem("operatorparam").InnerText;
						if (param != "")
						{
							rulecondn[i]["operatorparam"] = int.Parse(param);
						}

						rulecondn[i]["regardingobjectid"] = new EntityReference("duplicaterule", ruleid);
						try
						{
							DateTime before = DateTime.Now;
							Guid condid = Proxy.Create(rulecondn[i]);
							DateTime after = DateTime.Now;
							totalTimeToCreateRule += Convert.ToInt32(((TimeSpan)(after - before)).TotalMilliseconds);
							System.Diagnostics.Trace.WriteLine("DuplicateRule Condition " + condid + " created");
						}
						catch (Exception e)
						{
							System.Diagnostics.Trace.WriteLine("Exception creating DuplicateRuleCondition :" + e.ToString());
						}
					}
				}

				DateTime startTime = DateTime.Now;
				string SummaryFile = resultDir + @"\DuplicateRuleCreate_" + startTime.Ticks.ToString() + ".log";

				StreamWriter logWriter = new StreamWriter(SummaryFile);
				lock (logWriter)
				{
					logWriter.WriteLine("Logging test reult for Rule Create ...");
					logWriter.WriteLine("--------------------------------------");
					logWriter.WriteLine("Rule Create took {0} milisecond", totalTimeToCreateRule);
					logWriter.Flush();
					logWriter.Close();
				}

				return ruleid;
			}
		 /// <summary>
		 /// 
		 /// </summary>
		 /// <param name="dupruleID">Rule id to be published</param>
		 /// <returns>Rule publish job id</returns>
			private Guid PublishRule(Guid dupruleID)
			{
				//publish rule
				PublishDuplicateRuleRequest reqPublish = new PublishDuplicateRuleRequest();
				reqPublish.DuplicateRuleId = dupruleID;
				PublishDuplicateRuleResponse resPublish;
				try
				{
					resPublish = (PublishDuplicateRuleResponse)Proxy.Execute(reqPublish);
				}
				catch (Exception e)
				{
					throw e;
				}
				System.Diagnostics.Trace.WriteLine("Publishing Rule with an async job");
				System.Diagnostics.Trace.WriteLine("Returned Job Id by Async Job: " + resPublish.JobId.ToString("B"));

				return resPublish.JobId;
			}
	
			private Guid BulkDetectDup(QueryExpression query)
			{
				BulkDetectDuplicatesRequest request = new BulkDetectDuplicatesRequest();
				request.Query = query;
				request.JobName = "PerfJob_" + System.DateTime.Now.Millisecond.ToString();
				request.SendEmailNotification = false;
				request.TemplateId = Guid.Empty;
				request.ToRecipients = new Guid[0];
				request.CCRecipients = new Guid[0];
				request.RecurrencePattern = string.Empty;
				request.RecurrenceStartTime = DateTime.Now;
										
				BulkDetectDuplicatesResponse response;
				try
				{
					response = (BulkDetectDuplicatesResponse)Proxy.Execute(request);
				}
				catch (Exception e)
				{
					throw e;
				}
				System.Diagnostics.Trace.WriteLine("Bulk detect duplicates returned async job id: " + response.JobId.ToString("B"));

				//poll async job for completion
				System.Diagnostics.Trace.WriteLine("Polling Async job for completion");
				Entity asyncjob = null;
				ColumnSet cs = new ColumnSet(new string[] { "statecode" });
				asyncjob = (Entity)Proxy.Retrieve("asyncoperation", response.JobId, cs);
				System.Diagnostics.Trace.WriteLine("Async Job State is " + asyncjob["statecode"]);

				return response.JobId;
			}
	
			
			#endregion
		}    
	}