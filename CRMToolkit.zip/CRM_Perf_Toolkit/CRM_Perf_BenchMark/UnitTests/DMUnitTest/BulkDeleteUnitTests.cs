using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;

//using Microsoft.Crm.Sdk.Proxy;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages.Internal;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;


namespace CRM_Perf_BenchMark
{
	[TestClass]
	public class BulkDeleteUnitTests : UnitTestBase
	{
		private static string resultDir = Environment.SystemDirectory.Split(new char[] { '\\' }, 2)[0] + @"\PerfResult";

		#region Additional test attributes
		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		[ClassInitialize()]
		public static void ClassInitialize(TestContext testContext)
		{
			//this is the directory where all perf results are stored
			if (!Directory.Exists(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult"))
			{
				Directory.CreateDirectory(Path.GetPathRoot(Environment.CurrentDirectory) + @"PerfResult");
			}
			EntityManager.Instance.IsPerUserPerRun = true;
		}
		#endregion

		#region Individual Test Cases


		[TestMethod()]
		public void DMUnitTest_BulkDelete_LeadsFromQuery()
		{
			DeleteLeadsFromQuery();
		}

		
		#endregion

		#region Test Case Registration

		private void DeleteLeadsFromQuery()
		{
			QueryExpression query = new QueryExpression();
			query.EntityName = "lead";
			FilterExpression fe = new FilterExpression();

			ConditionExpression conditionOwner = new ConditionExpression();
			conditionOwner.AttributeName = "ownerid";
			conditionOwner.Operator = ConditionOperator.Equal;
			conditionOwner.Values.Add(m_user["systemuserid"]);
				
			ConditionExpression conditionStatus = new ConditionExpression();
			conditionStatus.AttributeName = "statuscode";
			conditionStatus.Operator = ConditionOperator.Equal;
			conditionStatus.Values.Add(1);

			ConditionExpression conditionFirstName = new ConditionExpression();
			conditionFirstName.AttributeName = "firstname";
			conditionFirstName.Operator = ConditionOperator.Equal;
			conditionFirstName.Values.Add("First Name Delete");

			ConditionExpression conditionLastName = new ConditionExpression();
			conditionLastName.AttributeName = "lastname";
			conditionLastName.Operator = ConditionOperator.Equal;
			conditionLastName.Values.Add("Last Name Delete");

			ConditionExpression conditionMiddleName = new ConditionExpression();
			conditionMiddleName.AttributeName = "middlename";
			conditionMiddleName.Operator = ConditionOperator.Equal;
			conditionMiddleName.Values.Add("Middle Name Delete");

			FilterExpression f1 = new FilterExpression();
			f1.Conditions.Add(conditionFirstName);
			f1.Conditions.Add(conditionLastName);
			f1.FilterOperator = LogicalOperator.And;

			FilterExpression f2 = new FilterExpression();
			f2.Conditions.Add(conditionMiddleName);
			f2.Filters.Add(f1);
			f2.FilterOperator = LogicalOperator.Or;

			FilterExpression f3 = new FilterExpression();
			f3.Conditions.Add(conditionStatus);
			f3.Filters.Add(f2);
			f3.FilterOperator = LogicalOperator.And;

			FilterExpression f4 = new FilterExpression();
			f4.Conditions.Add(conditionOwner);
			f4.Filters.Add(f3);
			f4.FilterOperator = LogicalOperator.And;

			query.Criteria = f4;
			ColumnSet cs = new ColumnSet(true);
			query.ColumnSet = cs;

			Guid bulkDeleteJobId = BulkDeleteWithNoRecurrence(new QueryExpression[] { query }, "Bulk Delete Leads With Conditions", false, new Guid[] { Guid.Empty }, new Guid[] { Guid.Empty }, Proxy);

			//lock (typeof(StreamWriter))
			//{
			//    StreamWriter logWriter = new StreamWriter(SummaryFile);
			//    logWriter.WriteLine("Logging test reult for Bulk Delete ...");
			//    logWriter.WriteLine("--------------------------------------");
			//    logWriter.WriteLine("Bulk Delete Id for this test is " + bulkDeleteJobId.ToString());
			//    logWriter.WriteLine("Test started at " + startTime);
			//    logWriter.Flush();
			//    logWriter.Close();
			//}
		}

		#endregion

		#region Test Case Helper Methodes

		
		/// <summary>
		/// Calls bulk-detect-duplicates with E-mail confirmation for the query exp passed
		/// </summary>
		/// <param name="query">Query exp for which bulk detect duplicates is desired</param>
		/// <param name="toRecipients">users to whom mail is to be sent</param>
		/// <param name="ccRecipients">users to whom mail is be 'cc-ed'</param>
		/// <param name="templateID">template to be used for sending mail</param>
		/// <returns>Job id of the bulk de-detect job</returns>
		private Guid BulkDeleteWithNoRecurrence(QueryExpression[] query, string jobName, bool sendEmailNotification, Guid[] toRecipients, Guid[] ccRecipients, IOrganizationService Proxy)
		{
			BulkDeleteRequest request = new BulkDeleteRequest()
			{
				QuerySet = query,
				JobName = jobName,
				SendEmailNotification = sendEmailNotification,
				ToRecipients = toRecipients,
				CCRecipients = ccRecipients,
				RecurrencePattern = string.Empty,
				StartDateTime = DateTime.Now
			};
		  //  request.RecurrenceStartTime = CrmDateTime.Now;

			BulkDeleteResponse response;
			TestContext.BeginTimer("Bulk delete leads" );
			try
			{
				if (Proxy == null)
				{
					throw new Exception("Proxy is null");
				}
				response = (BulkDeleteResponse)Proxy.Execute(request);
			}
			catch (Exception e)
			{
				throw e;
			}
			TestContext.EndTimer("Bulk delete leads");
	  
			return response.JobId;
		}

		 #endregion
	}

}
