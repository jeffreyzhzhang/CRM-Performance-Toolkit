﻿namespace CRM_Perf_BenchMark.CrmRequests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;

	public class OrganizationServiceDeleteRequest : OrganizationServiceRequest
	{
		public OrganizationServiceDeleteRequest(CRMEntity user, string templateName, Dictionary<string, string> templateParameters = null)
			: base(user, templateName, templateParameters)
		{
		}
		
		public override string OrgServiceMethodName
		{
			get { return "Delete"; }
		}
	}
}
