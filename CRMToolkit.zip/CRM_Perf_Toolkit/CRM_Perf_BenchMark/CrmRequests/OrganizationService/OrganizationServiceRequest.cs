﻿namespace CRM_Perf_BenchMark.CrmRequests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using Microsoft.VisualStudio.TestTools.WebTesting;
	using System.Reflection;
	using System.IO;
	
	public abstract class OrganizationServiceRequest : CrmRequest
	{
		private const string url = "/XRMServices/2011/Organization.svc/web";

		private const string AssemblyNamespace = "CRM_Perf_BenchMark";
		private const string TemplateFileExtension = ".txt";

		private StringHttpBody requestBody;
		protected string TemplateName { get; set; }
		protected Dictionary<string, string> TemplateParameters = new Dictionary<string,string>();

		public OrganizationServiceRequest(CRMEntity user, string templateName, Dictionary<string, string> templateParameters)
			: base(url, user)
		{
			this.Name = templateName;
			this.TemplateName = templateName;
			if (templateParameters != null)
			{
				this.TemplateParameters = templateParameters;
			}

			// Add known parameters
			if (!this.TemplateParameters.ContainsKey("USER_ID"))
			{
				this.TemplateParameters.Add("USER_ID", user["systemuserid"]);
			}

			this.Method = "POST";
			requestBody = new StringHttpBody();
			requestBody.ContentType = "text/xml; charset=utf-8";
			this.Body = requestBody;

			this.RefreshBody();

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/" + this.OrgServiceMethodName;
			Headers.Add(addSoapToHeaderForRequest);
		}

		protected virtual void RefreshBody()
		{
			requestBody.BodyString = GetTemplate(this.TemplateName, this.TemplateParameters);
		}

		public abstract string OrgServiceMethodName { get; }

		private string AppPath
		{
			get
			{
				return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
			}
		}

		private string GetTemplate(string templateName, Dictionary<string, string> templateParameters)
		{
			var resourceName = GetResourceNameFromTemplateName(templateName);

			var template = GetResource(resourceName);
			if (templateParameters != null)
			{
				foreach (var param in templateParameters)
				{
					var placeholder = string.Format("{{{0}}}", param.Key);
					var replacement = param.Value;
					if (replacement.StartsWith("###") && replacement.EndsWith("###"))
					{
						replacement = this.GetTemplate(replacement.Trim('#'), templateParameters);
						templateParameters[param.Key] = replacement; // update with the value, so we don't do this again
					}

					template = template.Replace(placeholder, replacement);
				}
			}

			return template;
		}

		public static string GetResourceNameFromTemplateName(string templateName)
		{
			// Replace any slashes with dots
			templateName = templateName.Replace("\\", ".");

			bool needsAssemblyNamespace = !templateName.StartsWith(AssemblyNamespace);
			bool needsExtension = !templateName.EndsWith(".") && !templateName.EndsWith(TemplateFileExtension);

			return (needsAssemblyNamespace ? AssemblyNamespace : string.Empty) + templateName + (needsExtension ? TemplateFileExtension : string.Empty);
		}

		private string GetResource(string resourceName)
		{
			var assembly = Assembly.GetExecutingAssembly();
			using (Stream stream = assembly.GetManifestResourceStream(resourceName))
			{
				if (stream != null)
				{
					using (StreamReader reader = new StreamReader(stream))
					{
						return reader.ReadToEnd();
					}
				}
			}

			throw new Exception(string.Format("Failed to load '{0}' embedded resource.", resourceName));
		}

		public static IEnumerable<string> GetResourceNames(string resourcePath)
		{
			List<string> resourceNames = new List<string>();

			var assembly = Assembly.GetExecutingAssembly();
			foreach (var resourceName in assembly.GetManifestResourceNames())
			{
				if (resourceName.ToLowerInvariant().StartsWith(resourcePath.ToLowerInvariant()))
				{
					resourceNames.Add(resourceName);
				}
			}

			// Order using standard string compare
			resourceNames.Sort();

			return resourceNames;
		}
	}
}
