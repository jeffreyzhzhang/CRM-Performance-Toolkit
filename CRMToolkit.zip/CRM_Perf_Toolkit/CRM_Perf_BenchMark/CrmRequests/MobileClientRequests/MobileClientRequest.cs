﻿namespace CRM_Perf_BenchMark.CrmRequests.MobileClientRequests
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using System.Net;
	
	public class MobileClientRequest : CrmRequest
	{
		public MobileClientRequest(string url, CRMEntity user)
			: base(url, user)
		{
			this.ParseDependentRequests = false;
		}
	}
}
