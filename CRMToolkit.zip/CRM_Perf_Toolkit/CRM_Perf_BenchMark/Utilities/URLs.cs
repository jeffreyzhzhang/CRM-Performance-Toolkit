namespace CRM_Perf_BenchMark
{
	using System;
	using System.Text;
	using Microsoft.VisualStudio.TestTools.WebTesting;

	[Serializable]
	public class _activities_attachment_edit_aspx : CrmRequest
	{
		//server URL
		public const string url = "/activities/attachment/edit.aspx";

		//querystring parameters
		public string pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString(), false);
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public Guid Id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString());
			}
		}

		public bool cw
		{
			set
			{
				AddQueryStringParameter("cw", value.ToString());
			}
		}

		public int refreshGrid
		{
			set
			{
				AddQueryStringParameter("refreshGrid", value.ToString());
			}
		}

		public int rg
		{
			set
			{
				AddQueryStringParameter("rg", value.ToString());
			}
		}

		public _activities_attachment_edit_aspx()
			: base(url)
		{
		}
		public _activities_attachment_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class Activities_Attachment_upload_aspx : CrmRequest
	{
		//server URL
		public const string url = "/Activities/Attachment/upload.aspx";

		public Activities_Attachment_upload_aspx()
			: base(url)
		{
		}
		public Activities_Attachment_upload_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class AdvancedFind_AdvFind_aspx : CrmRequest
	{
		// server URL
		private const string url = "/AdvancedFind/AdvFind.aspx";

		// querystring parameters
		public int EntityCode
		{
			set
			{
				AddQueryStringParameter("EntityCode", value.ToString());
			}
		}

		public Guid QueryId
		{
			set
			{
				AddQueryStringParameter("QueryId", value.ToString("B"));
			}
		}

		public int ViewType
		{
			set
			{
				AddQueryStringParameter("ViewType", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value);
			}
		}

		public AdvancedFind_AdvFind_aspx()
			: base(url)
		{
		}

		public AdvancedFind_AdvFind_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MobileOfflineSyncTestRequest : WebTestRequest
	{
		public WebTestResponse lastResponse = null;
		protected FormPostHttpBody formBody = null;

		public MobileOfflineSyncTestRequest(string MobileOfflineSyncEndPoint, CRMEntity user)
			: base(MobileOfflineSyncEndPoint)
		{
			// Constructing Norsync url 
			this.Url = Utils.UrlPathCombine(MobileOfflineSyncEndPoint, user["organizationname"]);
			this.Url = Utils.UrlPathCombine(this.Url, user["systemuserid"]);
			this.Url = Utils.UrlPathCombine(this.Url, user["mobileofflinedeviceid"]);

			//required to attach validate function 
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(SyncRequest_ValidateResponse);
		}

		public string Refresh
		{
			set
			{
				if (value != null)
				{
					AddQueryStringParameter("refresh", value.ToString());
				}
				else
				{
					throw new Exception("Expecting non null value for paramters");
				}
			}
		}

		public string Model
		{
			set
			{
				if (value != null)
				{
					AddQueryStringParameter("model", value.ToString());
				}
				else
				{
					throw new Exception("Expecting non null value for paramters");
				}

			}
		}

		public string RuleVersion
		{
			set
			{
				if (value != null)
				{
					AddQueryStringParameter("ruleVersion", value.ToString());
				}
				else
				{
					throw new Exception("Expecting non null value for paramters");
				}
			}
		}

		public string ModelVersion
		{
			set
			{
				if (value != null)
				{
					AddQueryStringParameter("modelVersion", value.ToString());
				}
				else
				{
					throw new Exception("Expecting non null value for paramters");
				}
			}
		}

		public string PrevSid
		{
			set
			{
				if (value != null)
				{
					AddQueryStringParameter("prevSID", value.ToString());
				}
				else
				{
					throw new Exception("Expecting non null value for paramters");
				}
			}
		}

		public string InputSid
		{
			set
			{
				if (value != null)
				{
					AddQueryStringParameter("inputSID", value.ToString());
				}
				else
				{
					throw new Exception("Expecting non null value for paramters");
				}
			}
		}

		public QueryStringParameter AddQueryStringParameter(string name, string value)
		{
			QueryStringParameter queryStringParameter = new QueryStringParameter(name, value);
			this.QueryStringParameters.Add(queryStringParameter); 
			return queryStringParameter;
		}

		public void RequestTypePost()
		{
			formBody = new FormPostHttpBody();
			Method = "POST";
			Body = formBody;
		}

		public void SyncRequest_ValidateResponse(object sender, ValidationEventArgs e)
		{
			e.IsValid = false;
			lastResponse = e.Response;

			// Passing test case only when we have all expected values
			if (lastResponse != null && !string.IsNullOrEmpty(lastResponse.Headers["NorsyncSID"]))
			{
				e.IsValid = true;
			}
		}
	}

	[Serializable]
	public class AdvancedFind_Advancedfind_htc_aspx : CrmRequest
	{
		// server URL
		private const string url = "/AdvancedFind/AdvancedFind.htc.aspx";

		// querystring parameters
		public int ver
		{
			set
			{
				AddQueryStringParameter("ver", value.ToString());
			}
		}

		public AdvancedFind_Advancedfind_htc_aspx()
			: base(url)
		{
		}

		public AdvancedFind_Advancedfind_htc_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class workplace_home_dashboards_aspx : CrmRequest
	{
		// server URL
		private const string url = "/workplace/home_dashboards.aspx";

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value);
			}
		}

		public workplace_home_dashboards_aspx()
			: base(url)
		{
		}

		public workplace_home_dashboards_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class dashboards_dashboard_aspx : CrmRequest
	{
		// server URL
		private const string url = "/dashboards/dashboard.aspx";

		public Guid dashboardId
		{
			set
			{
				AddQueryStringParameter("dashboardId", value.ToString("B"));
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public int dashboardType
		{
			set
			{
				AddQueryStringParameter("dashboardType", value.ToString());
			}
		}

		public dashboards_dashboard_aspx()
			: base(url)
		{
		}

		public dashboards_dashboard_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _common_windowinformation_windowinformation_aspx : CrmRequest
	{
		private const string url = "/_common/windowinformation/windowinformation.js.aspx";

		public _common_windowinformation_windowinformation_aspx()
			: base(url)
		{
		}

		public _common_windowinformation_windowinformation_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _Common_icon_aspx : CrmRequest
	{
		private const string url = "/_Common/icon.aspx";

		//QueryStringParameters
		public int objectTypeCode
		{
			set
			{
				AddQueryStringParameter("objectTypeCode", value.ToString());
			}
		}

		public string iconType
		{
			set
			{
				AddQueryStringParameter("iconType", value);
			}
		}

		public int inProduction
		{
			set
			{
				AddQueryStringParameter("inProduction", value.ToString());
			}
		}

		public int cache
		{
			set
			{
				AddQueryStringParameter("cache", value.ToString());
			}
		}

		public _Common_icon_aspx()
			: base(url)
		{
		}

		public _Common_icon_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _common_styles_fonts_aspx : CrmRequest
	{
		private const string url = "/_common/styles/fonts.aspx";

		public _common_styles_fonts_aspx()
			: base(url)
		{
		}

		public _common_styles_fonts_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class AdvancedFind_fetchData_aspx : CrmRequest
	{
		private const string url = "/AdvancedFind/fetchData.aspx";

		public AdvancedFind_fetchData_aspx()
			: base(url)
		{
		}

		public AdvancedFind_fetchData_aspx(CRMEntity user)
			: base(url, user)
		{
		}

		public string PageMode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string SiteMapPath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value);
			}
		}

		// querystring parameters
		public int ListMemberType
		{
			set
			{
				AddQueryStringParameter("ListMemberType", value.ToString());
			}
		}

		public Guid ListId
		{
			set
			{
				AddQueryStringParameter("ListId", value.ToString("B"));
			}
		}

		public string InvokeType
		{
			set
			{
				AddQueryStringParameter("InvokeType", value);
			}
		}

		public string invoker
		{
			set
			{
				AddQueryStringParameter("invoker", value);
			}
		}

		public int restrictOtherEntities
		{
			set
			{
				AddQueryStringParameter("restrictOtherEntities", value.ToString());
			}
		}

		public bool dispActions
		{
			set
			{
				AddQueryStringParameter("dispActions", value.ToString());
			}
		}

		// form body parameters
		public string FetchXml
		{
			set
			{
				AddFormParameter("FetchXml", value);
			}
		}

		public string LayoutXml
		{
			set
			{
				AddFormParameter("LayoutXml", value);
			}
		}

		public string EntityName
		{
			set
			{
				AddFormParameter("EntityName", value);
			}
		}

		public Guid ViewId
		{
			set
			{
				AddFormParameter("ViewId", value.ToString("B"));
			}
		}

		public int ViewType
		{
			set
			{
				AddFormParameter("ViewType", value.ToString());
			}
		}

		public string SortCol
		{
			set
			{
				AddFormParameter("SortCol", value);
			}
		}

		public bool SortDescend
		{
			set
			{
				AddFormParameter("SortDescend", value.ToString());
			}
		}

		public int otc
		{
			set
			{
				AddFormParameter("otc", value.ToString());
			}
		}

		public Guid DefaultAdvFindViewId
		{
			set
			{
				AddFormParameter("DefaultAdvFindViewId", value.ToString("B"));
			}
		}

		public Guid QueryId
		{
			set
			{
				AddQueryStringParameter("QueryId", value.ToString("B"));
			}
		}

		public int EntityCode
		{
			set
			{
				AddQueryStringParameter("EntityCode", value.ToString());
			}
		}
	}

	[Serializable]
	public class visualization_visualization_aspx : CrmRequest
	{
		// server URL
		public const string url = "/Visualization/visualization.aspx";

		public string uniqueId
		{
			set
			{
				AddQueryStringParameter("uniqueId", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddQueryStringParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddQueryStringParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public string vizXml
		{
			set
			{
				AddFormParameter("vizXml", value);
			}
		}

		public string vizFetchXml
		{
			set
			{
				AddFormParameter("vizFetchXml", value);
			}
		}

		public Guid visualizationId
		{
			set
			{
				AddFormParameter("visualizationId", value.ToString("B"));
			}
		}

		public Guid viewid
		{
			set
			{
				AddFormParameter("viewid", value.ToString("B"));
			}
		}

		public int viewtype
		{
			set
			{
				AddFormParameter("viewtype", value.ToString());
			}
		}

		public int visType
		{
			set
			{
				AddFormParameter("visType", value.ToString());
			}
		}

		public string viewBy
		{
			set
			{
				AddFormParameter("viewBy", value);
			}
		}

		public string chartType
		{
			set
			{
				AddFormParameter("chartType", value);
			}
		}

		public string xValue
		{
			set
			{
				AddFormParameter("xValue", value);
			}
		}

		public string x1Value
		{
			set
			{
				AddFormParameter("x1Value", value.ToString());
			}
		}

		public string drillDownChartTitle
		{
			set
			{
				AddFormParameter("drillDownChartTitle", value);
			}
		}

		public string alreadyViewByAttr
		{
			set
			{
				AddFormParameter("alreadyViewByAttr", value);
			}
		}

		public string formattedXValue
		{
			set
			{
				AddFormParameter("formattedXValue", value);
			}
		}

		public int seriesIndex
		{
			set
			{
				AddFormParameter("seriesIndex", value.ToString());
			}
		}

		public string yColumnName
		{
			set
			{
				AddFormParameter("yColumnName", value);
			}
		}

		public string aggregatedFetchXml
		{
			set
			{
				AddFormParameter("aggregatedFetchXml", value);
			}
		}

		public string presentationXml
		{
			set
			{
				AddFormParameter("presentationXml", value);
			}
		}

		public bool isDrillDown
		{
			set
			{
				AddFormParameter("isDrillDown", value.ToString());
			}
		}

		public bool enableDrillDown
		{
			set
			{
				AddFormParameter("enableDrillDown", value.ToString());
			}
		}

		public bool backNavigation
		{
			set
			{
				AddFormParameter("backNavigation", value.ToString());
			}
		}

		public bool isDashboardComponent
		{
			set
			{
				AddFormParameter("isDashboardComponent", value.ToString());
			}
		}

		public string layoutSize
		{
			set
			{
				AddFormParameter("layoutSize", value);
			}
		}

		public string viewType
		{
			set
			{
				AddFormParameter("viewType", value);
			}
		}

		public int paneContentWidth
		{
			set
			{
				AddFormParameter("paneContentWidth", value.ToString());
			}
		}

		public int paneContentHeight
		{
			set
			{
				AddFormParameter("paneContentHeight", value.ToString());
			}
		}

		public visualization_visualization_aspx()
			: base(url)
		{
		}

		public visualization_visualization_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _root_homepage_aspx : CrmRequest
	{
		// server URL
		private const string url = "/_root/homepage.aspx";

		// querystring parameters
		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string etn
		{
			set
			{
				AddQueryStringParameter("etn", value);
			}
		}


		public int layout
		{
			set
			{
				AddQueryStringParameter("layout", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string type
		{
			set
			{
				AddQueryStringParameter("type", value);
			}
		}

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value);
			}
		}

		public Guid visualizationId
		{
			set
			{
				AddQueryStringParameter("visualizationId", value.ToString("B"));
			}
		}

		public int visualizationPaneMode
		{
			set
			{
				AddQueryStringParameter("visualizationPaneMode", value.ToString());
			}
		}

		public int visualizationType
		{
			set
			{
				AddQueryStringParameter("visualizationType", value.ToString());
			}
		}

		public Guid viewid
		{
			set
			{
				AddQueryStringParameter("viewid", value.ToString("B"));
			}
		}

		public int viewtype
		{
			set
			{
				AddQueryStringParameter("viewtype", value.ToString());
			}
		}

		public _root_homepage_aspx()
			: base(url)
		{
		}

		public _root_homepage_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _help_default_aspx : CrmRequest
	{
		public const string url = "/help/default.aspx";

		public string ver
		{
			set
			{
				AddQueryStringParameter("ver", value.ToString());
			}
		}

		public int user_lcid
		{
			set
			{
				AddQueryStringParameter("user_lcid", value.ToString());
			}
		}

		public string helpVisorToc
		{
			set
			{
				AddQueryStringParameter("helpVisorToc", value.ToString());
			}
		}

		public _help_default_aspx()
			: base(url)
		{
		}

		public _help_default_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}


	[Serializable]
	public class _root_hierarchy_aspx : CrmRequest
	{
		// server URL
		private const string url = "/_root/hierarchy.aspx";

		// querystring parameters
		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public _root_hierarchy_aspx()
			: base(url)
		{
		}

		public _root_hierarchy_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _common_windowinformation_windowinformation_js_aspx : CrmRequest
	{
		public const string url = "/_common/windowinformation/windowinformation.js.aspx";

		public int ver
		{
			set
			{
				AddQueryStringParameter("ver", value.ToString());
			}
		}

		public _common_windowinformation_windowinformation_js_aspx()
			: base(url)
		{
		}

		public _common_windowinformation_windowinformation_js_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_accts_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/accts/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		// formbody parameters

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}

		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("CrmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public bool CrmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public int _gridType
		{
			set
			{
				AddQueryStringParameter("_gridType", value.ToString());
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public sfa_accts_edit_aspx()
			: base(url)
		{
		}

		public sfa_accts_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_comps_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/comps/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		// formbody parameters

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}

		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public bool CrmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public sfa_comps_edit_aspx()
			: base(url)
		{
		}

		public sfa_comps_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class connections_connections_edit_aspx : CrmRequest
	{
		public const string url = "/connections/connections/edit.aspx";

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid appSolutionId
		{
			set
			{
				AddFormParameter("appSolutionId", value.ToString());
			}
		}

		public connections_connections_edit_aspx()
			: base(url)
		{
		}

		public connections_connections_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class main_aspx : CrmRequest
	{
		// server URL
		public const string url = "/main.aspx";

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string etn
		{
			set
			{
				AddQueryStringParameter("etn", value);
			}
		}

		public string extraqs
		{
			set
			{
				AddQueryStringParameter("extraqs", value);
			}
		}

		public string pagetype
		{
			set
			{
				AddQueryStringParameter("pagetype", value);
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public bool rof
		{
			set
			{
				AddQueryStringParameter("rof", value.ToString());
			}
		}

		public int activitytypecode
		{
			set
			{
				AddQueryStringParameter("activitytypecode", value.ToString());
			}
		}

		public Guid formid
		{
			set
			{
				AddQueryStringParameter("formid", value.ToString("B"));
			}
		}
		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString());
			}
		}
		public string pName
		{
			set
			{
				AddQueryStringParameter("pname", value.ToString());
			}
		}
		public int pType
		{
			set
			{
				AddQueryStringParameter("pname", value.ToString());
			}
		}

		public string navbar
		{
			set
			{
				AddQueryStringParameter("navbar", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}


		public main_aspx()
			: base(url)
		{
		}

		public main_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class data_aspx : CrmRequest
	{
		// server URL
		public const string url = "/form/Data.aspx";

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public Guid oid
		{
			set
			{
				AddQueryStringParameter("oid", value.ToString("B"));
			}
		}

		public Guid formid
		{
			set
			{
				AddQueryStringParameter("formid", value.ToString("B"));
			}
		}

		public Guid _CreateFromId
		{
			set
			{
				AddQueryStringParameter("_CreateFromId", value.ToString("B"));
			}
		}

		public int _CreateFromType
		{
			set
			{
				AddQueryStringParameter("_CreateFromType", value.ToString());
			}
		}

		public bool showglobalquickcreate
		{
			set
			{
				AddQueryStringParameter("showglobalquickcreate", value.ToString());
			}
		}

		public Guid process
		{
			set
			{
				AddQueryStringParameter("process", value.ToString("B"));
			}
		}

		public string extraqs
		{
			set
			{
				AddQueryStringParameter("extraqs", value);
			}
		}

		public string pagetype
		{
			set
			{
				AddQueryStringParameter("pagetype", value);
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public data_aspx()
			: base(url)
		{
		}

		public data_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class userdefined_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/userdefined/areas.aspx";

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());
			}
		}

		public int security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());
			}
		}

		public int inlineedit
		{
			set
			{
				AddQueryStringParameter("inlineEdit", value.ToString());
			}
		}


		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value);
			}
		}

		public int createdfromcode
		{
			set
			{
				AddQueryStringParameter("createdfromcode", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public string formId
		{
			set
			{
				AddQueryStringParameter("formId", value);
			}
		}

		public string navItemName
		{
			set
			{
				AddQueryStringParameter("navItemName", value);
			}
		}

		public int inlineEdit
		{
			set
			{
				AddQueryStringParameter("inlineEdit", value.ToString());
			}
		}

		public bool rof
		{
			set
			{
				AddQueryStringParameter("rof", value.ToString());
			}
		}

		public string theme
		{
			set
			{
				AddQueryStringParameter("theme", value.ToString());
			}
		}

		public userdefined_areas_aspx()
			: base(url)
		{
		}

		public userdefined_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class userdefined_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/userdefined/edit.aspx";

		// querystring parameters
		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public Guid pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString("B"));
			}
		}

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString());
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public string pName
		{
			set
			{
				AddQueryStringParameter("pName", value);
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public int _gridType
		{
			set
			{
				AddQueryStringParameter("_gridType", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value);
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public int _CreateFromType
		{
			set
			{
				AddQueryStringParameter("_CreateFromType", value.ToString());
			}
		}

		public Guid _CreateFromId
		{
			set
			{
				AddQueryStringParameter("_CreateFromId", value.ToString("B"));
			}
		}

		public DateTime _StartTime
		{
			set
			{
				AddQueryStringParameter("_StartTime", value.ToString("s"));
			}
		}

		public int locked
		{
			set
			{
				AddQueryStringParameter("locked", value.ToString());
			}
		}

		public int contactInfo
		{
			set
			{
				AddQueryStringParameter("contactInfo", value.ToString());
			}
		}

		public string partyaddressused
		{
			set
			{
				AddQueryStringParameter("partyaddressused", value.ToString());
			}
		}

		public Guid partyid
		{
			set
			{
				AddQueryStringParameter("partyid", value.ToString());
			}
		}

		public string partyname
		{
			set
			{
				AddQueryStringParameter("partyname", value.ToString());
			}
		}

		public int partytype
		{
			set
			{
				AddQueryStringParameter("partytype", value.ToString());
			}
		}

		// formbody parameters

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}

		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public bool qlShowNew
		{
			set
			{
				AddFormParameter("qlShowNew", value.ToString());
			}
		}

		public bool qlCreateAccount
		{
			set
			{
				AddFormParameter("qlCreateAccount", value.ToString());
			}
		}

		public bool qlCreateContact
		{
			set
			{
				AddFormParameter("qlCreateContact", value.ToString());
			}
		}

		public bool qlCreateOpportunity
		{
			set
			{
				AddFormParameter("qlCreateOpportunity", value.ToString());
			}
		}

		public Guid qlOppCurrencyId
		{
			set
			{
				AddFormParameter("qlOppCurrencyId", value.ToString("B"));
			}
		}

		public int qlOpportunityParentType
		{
			set
			{
				AddFormParameter("qlOpportunityParentType", value.ToString());
			}
		}

		public Guid qlOpportunityParentId
		{
			set
			{
				AddFormParameter("qlOpportunityParentId", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmCmdId
		{
			set
			{
				AddFormParameter("crmCmdId", value.ToString());
			}
		}

		public string appSolutionId
		{
			set
			{
				AddFormParameter("appSolutionId", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public userdefined_edit_aspx()
			: base(url)
		{
		}

		public userdefined_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_accts_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/accts/areas.aspx";

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());
			}
		}

		public long security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());
			}
		}

		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value);
			}
		}

		public sfa_accts_areas_aspx()
			: base(url)
		{
		}

		public sfa_accts_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_quotes_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/quotes/areas.aspx";

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());
			}
		}

		public long security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());
			}
		}

		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value);
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public sfa_quotes_areas_aspx()
			: base(url)
		{
		}

		public sfa_quotes_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_opps_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/opps/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public sfa_opps_edit_aspx()
			: base(url)
		{
		}

		public sfa_opps_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}


	[Serializable]
	public class tools_documentmanagement_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/documentmanagement/areas.aspx";

		// querystring parameters
		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));

			}
		}

		public bool autocreatelocation
		{
			set
			{
				AddQueryStringParameter("autocreatelocation", value.ToString());
			}
		}

		public string defaultLocationId
		{
			set
			{
				AddQueryStringParameter("defaultLocationId", value);
			}
		}

		public string defaultLocationName
		{
			set
			{
				AddQueryStringParameter("defaultLocationName", value);
			}
		}

		public string defaultLocationType
		{
			set
			{
				AddQueryStringParameter("defaultLocationType", value);
			}
		}

		public string defaultLocationUrl
		{
			set
			{
				AddQueryStringParameter("defaultLocationUrl", value);
			}
		}

		public string entityLogicalName
		{
			set
			{
				AddQueryStringParameter("entityLogicalName", value);
			}
		}

		public string folderName
		{
			set
			{
				AddQueryStringParameter("folderName", value);
			}
		}

		public string siteCollectionUrl
		{
			set
			{
				AddQueryStringParameter("siteCollectionUrl", value);
			}
		}

		// formbody parameters
		public string oName
		{
			set
			{
				AddQueryStringParameter("oName", value);
			}
		}

		public string parentUrl
		{
			set
			{
				AddQueryStringParameter("parentUrl", value);

			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());

			}
		}


		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);

			}
		}

		public tools_documentmanagement_areas_aspx()
			: base(url)
		{
		}

		public tools_documentmanagement_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_documentmanagement_addlocation_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/documentmanagement/addlocation.aspx";

		// querystring parameters
		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));

			}
		}

		public string mode
		{
			set
			{
				AddQueryStringParameter("mode", value.ToString());
			}
		}

		public string defaultLocationId
		{
			set
			{
				AddQueryStringParameter("defaultLocationId", value);
			}
		}

		public string defaultLocationName
		{
			set
			{
				AddQueryStringParameter("defaultLocationName", value);
			}
		}

		public string defaultLocationType
		{
			set
			{
				AddQueryStringParameter("defaultLocationType", value);
			}
		}

		public string defaultLocationUrl
		{
			set
			{
				AddQueryStringParameter("defaultLocationUrl", value);
			}
		}

		public string entityLogicalName
		{
			set
			{
				AddQueryStringParameter("entityLogicalName", value);
			}
		}

		public string folderName
		{
			set
			{
				AddQueryStringParameter("folderName", value);
			}
		}

		public string siteCollectionUrl
		{
			set
			{
				AddQueryStringParameter("siteCollectionUrl", value);
			}
		}

		// formbody parameters
		public string oName
		{
			set
			{
				AddQueryStringParameter("oName", value);
			}
		}

		public string parentUrl
		{
			set
			{
				AddQueryStringParameter("parentUrl", value);

			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());

			}
		}


		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);

			}
		}

		public tools_documentmanagement_addlocation_aspx()
			: base(url)
		{
		}
		public tools_documentmanagement_addlocation_aspx(CRMEntity user)
			: base(url, user)
		{
		}

	}


	[Serializable]
	public class crmgrid_createfolder_aspx : SPRequest
	{
		// server URL
		public const string url = "/crmgrid/createfolder.aspx";

		// querystring parameters
		public string locationUrl
		{
			set
			{
				AddQueryStringParameter("locationUrl", value.ToString());

			}
		}


		public string langId
		{
			set
			{
				AddQueryStringParameter("langId", value);
			}
		}

		public string serverUrl
		{
			set
			{
				AddQueryStringParameter("serverUrl", value);
			}
		}

		public string dlName
		{
			set
			{
				AddQueryStringParameter("dlName", value);
			}
		}

		public string ecName
		{
			set
			{
				AddQueryStringParameter("ecName", value);
			}
		}

		public string ecLogicalName
		{
			set
			{
				AddQueryStringParameter("ecLogicalName", value);
			}
		}

		public string folderName
		{
			set
			{
				AddQueryStringParameter("folderName", value);
			}
		}



		public crmgrid_createfolder_aspx()
			: base(url)
		{
		}
		public crmgrid_createfolder_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public crmgrid_createfolder_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}

	}









	[Serializable]
	public class _layouts_crmgrid_crmgridpage_aspx : SPRequest
	{
		// server URL
		public const string url = "/crmgrid/crmgridpage.aspx";

		// querystring parameters
		public Guid listId
		{
			set
			{
				AddQueryStringParameter("listId", value.ToString("B"));

			}
		}

		public string langId
		{
			set
			{
				AddQueryStringParameter("langId", value);

			}
		}

		public string locationUrl
		{
			set
			{
				AddQueryStringParameter("locationUrl", value);
			}
		}


		// formbody parameters
		public string oName
		{
			set
			{
				AddQueryStringParameter("oName", value);

			}
		}

		public string parentUrl
		{
			set
			{
				AddQueryStringParameter("parentUrl", value);

			}
		}


		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));

			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());

			}
		}

		public string security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());

			}
		}

		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value);

			}
		}


		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);

			}
		}

		public string pageSize
		{
			set
			{
				AddQueryStringParameter("pageSize", value.ToString());
			}
		}


		public _layouts_crmgrid_crmgridpage_aspx()
			: base(url)
		{
		}
		public _layouts_crmgrid_crmgridpage_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public _layouts_crmgrid_crmgridpage_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
	}

	[Serializable]
	public class _layouts_crmgrid_dialogcontainerpage_aspx : SPRequest
	{
		// server URL
		public const string url = "/crmgrid/dialogcontainerpage.aspx";

		public string listId
		{
			set
			{
				AddQueryStringParameter("listId", value.ToString());

			}
		}


		// querystring parameters
		public string listid
		{
			set
			{
				AddQueryStringParameter("listid", value.ToString());

			}
		}


		public string itemid
		{
			set
			{
				AddQueryStringParameter("itemid", value);

			}
		}

		public string RootFolder
		{
			set
			{
				AddQueryStringParameter("RootFolder", value);

			}
		}

		public string fileUrl
		{
			set
			{
				AddQueryStringParameter("fileUrl", value);

			}
		}

		public string locationUrl
		{
			set
			{
				AddQueryStringParameter("locationUrl", value);

			}
		}

		public string langId
		{
			set
			{
				AddQueryStringParameter("langId", value);

			}
		}



		public string pageType
		{
			set
			{
				AddQueryStringParameter("pageType", value);

			}
		}



		public _layouts_crmgrid_dialogcontainerpage_aspx()
			: base(url)
		{
		}
		public _layouts_crmgrid_dialogcontainerpage_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public _layouts_crmgrid_dialogcontainerpage_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
	}

	[Serializable]
	public class _layouts_checkin_aspx : SPRequest
	{
		// server URL
		public const string url = "/_layouts/checkin.aspx";


		// querystring parameters
		public string IsDlg
		{
			set
			{
				AddQueryStringParameter("IsDlg", value.ToString());

			}
		}

		public string List
		{
			set
			{
				AddQueryStringParameter("List", value);

			}
		}

		public string FileName
		{
			set
			{
				AddQueryStringParameter("FileName", value);

			}
		}

		public string fileUrl
		{
			set
			{
				AddQueryStringParameter("fileUrl", value);

			}
		}

		public string locationUrl
		{
			set
			{
				AddQueryStringParameter("locationUrl", value);

			}
		}

		public string langId
		{
			set
			{
				AddQueryStringParameter("langId", value);

			}
		}

		public string pageType
		{
			set
			{
				AddQueryStringParameter("pageType", value);

			}
		}



		public _layouts_checkin_aspx()
			: base(url)
		{
		}
		public _layouts_checkin_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public _layouts_checkin_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
	}


	[Serializable]
	public class _layouts_Upload_aspx : SPRequest
	{
		// server URL
		public const string url = "/_layouts/Upload.aspx";

		// querystring parameters
		public string List
		{
			set
			{
				AddQueryStringParameter("List", value);

			}
		}


		public string RootFolder
		{
			set
			{
				AddQueryStringParameter("RootFolder", value);

			}
		}



		public string IsDlg
		{
			set
			{
				AddQueryStringParameter("IsDlg", value);

			}
		}



		public _layouts_Upload_aspx()
			: base(url)
		{
		}
		public _layouts_Upload_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public _layouts_Upload_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
	}

	[Serializable]
	public class crmgrid_scripts_DialogContainer_js : SPRequest
	{
		// server URL
		public const string url = "/crmgrid/scripts/DialogContainer.js ";

		// querystring parameters
		public Guid List
		{
			set
			{
				AddQueryStringParameter("List", value.ToString("B"));

			}
		}


		public string RootFolder
		{
			set
			{
				AddQueryStringParameter("RootFolder", value);

			}
		}



		public string IsDlg
		{
			set
			{
				AddQueryStringParameter("IsDlg", value);

			}
		}



		public crmgrid_scripts_DialogContainer_js()
			: base(url)
		{
		}
		public crmgrid_scripts_DialogContainer_js(CRMEntity user)
			: base(url, user)
		{
		}
		public crmgrid_scripts_DialogContainer_js(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
	}

	[Serializable]
	public class _layouts_SubNew_aspx : SPRequest
	{
		// server URL
		public const string url = "/_layouts/SubNew.aspx";

		// querystring parameters
		public string list
		{
			set
			{
				AddQueryStringParameter("list", value);

			}
		}


		public string ID
		{
			set
			{
				AddQueryStringParameter("ID", value);

			}
		}



		public string IsDlg
		{
			set
			{
				AddQueryStringParameter("IsDlg", value);

			}
		}



		public _layouts_SubNew_aspx()
			: base(url)
		{
		}
		public _layouts_SubNew_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public _layouts_SubNew_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
	}

	[Serializable]
	public class Forms_EditForm_aspx : SPRequest
	{
		// server URL
		public const string url = "/Forms/EditForm.aspx";

		// querystring parameters
		public string Mode
		{
			set
			{
				AddQueryStringParameter("Mode", value);

			}
		}


		public string CheckInComment
		{
			set
			{
				AddQueryStringParameter("CheckInComment", value);

			}
		}



		public string ID
		{
			set
			{
				AddQueryStringParameter("ID", value);

			}
		}

		public string RootFolder
		{
			set
			{
				AddQueryStringParameter("RootFolder", value);

			}
		}

		public string ContentTypeId
		{
			set
			{
				AddQueryStringParameter("ContentTypeId", value);

			}
		}

		public string IsDlg
		{
			set
			{
				AddQueryStringParameter("IsDlg", value);

			}
		}

		public Forms_EditForm_aspx()
			: base(url)
		{
		}
		public Forms_EditForm_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public Forms_EditForm_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
		public Forms_EditForm_aspx(CRMEntity user, string siteURL, string entityName)
			: base(url, user, siteURL, entityName)
		{
		}
	}

	[Serializable]
	public class forms_DispForm_aspx : SPRequest
	{
		// server URL
		public const string url = "/forms/DispForm.aspx";

		// querystring parameters



		public string ID
		{
			set
			{
				AddQueryStringParameter("ID", value);

			}
		}




		public string IsDlg
		{
			set
			{
				AddQueryStringParameter("IsDlg", value);

			}
		}

		public forms_DispForm_aspx()
			: base(url)
		{
		}
		public forms_DispForm_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public forms_DispForm_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
		public forms_DispForm_aspx(CRMEntity user, string siteURL, string entityName)
			: base(url, user, siteURL, entityName)
		{
		}
	}

	[Serializable]
	public class _layouts_Versions_aspx : SPRequest
	{
		// server URL
		public const string url = "/_layouts/Versions.aspx";

		// querystring parameters
		public string FileName
		{
			set
			{
				AddQueryStringParameter("FileName", value);

			}
		}


		public string list
		{
			set
			{
				AddQueryStringParameter("list", value);

			}
		}

		public string ID
		{
			set
			{
				AddQueryStringParameter("ID", value);

			}
		}


		public string IsDlg
		{
			set
			{
				AddQueryStringParameter("IsDlg", value);

			}
		}

		public _layouts_Versions_aspx()
			: base(url)
		{
		}
		public _layouts_Versions_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public _layouts_Versions_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
		public _layouts_Versions_aspx(CRMEntity user, string siteURL, string entityName)
			: base(url, user, siteURL, entityName)
		{
		}
	}

	[Serializable]
	public class _layouts_crmgrid_CrmGridActionsPage_aspx : SPRequest
	{
		// server URL
		public const string url = "/crmgrid/CrmGridActionsPage.aspx";



		// queryarameters
		public int action
		{
			set
			{
				AddQueryStringParameter("action", value.ToString(), false);

			}
		}

		public string documentUrl
		{
			set
			{

				AddQueryStringParameter("documentUrl", value, false);

			}
		}
		//form parameters
		public string __REQUESTDIGEST
		{
			set
			{

				AddFormParameter("__REQUESTDIGEST", value);
			}
		}

		public string __VIEWSTATE
		{
			set
			{
				AddFormParameter("__VIEWSTATE", value);
			}
		}

		public string gridXml
		{
			set
			{
				AddFormParameter("gridXml", value);
			}
		}


		public string checkinComment
		{
			set
			{
				AddFormParameter("checkinComment", value);
			}
		}

		public string locationUrl
		{
			set
			{
				AddQueryStringParameter("locationUrl", value);
			}
		}

		public string langId
		{
			set
			{
				AddQueryStringParameter("langId", value);
			}
		}



		public _layouts_crmgrid_CrmGridActionsPage_aspx()
			: base(url)
		{
		}
		public _layouts_crmgrid_CrmGridActionsPage_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public _layouts_crmgrid_CrmGridActionsPage_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
	}

	[Serializable]
	public class Forms_AllItems_aspx : SPRequest
	{
		// server URL
		public const string url = "/Forms/AllItems.aspx";



		// queryarameters
		public string RootFolder
		{
			set
			{
				AddQueryStringParameter("RootFolder", value, false);

			}
		}

		public string FolderCTID
		{
			set
			{

				AddQueryStringParameter("FolderCTID", value, false);

			}
		}
		//form parameters
		public string __REQUESTDIGEST
		{
			set
			{

				AddFormParameter("__REQUESTDIGEST", value);
			}
		}

		public string __VIEWSTATE
		{
			set
			{
				AddFormParameter("__VIEWSTATE", value);
			}
		}

		public string gridXml
		{
			set
			{
				AddFormParameter("gridXml", value);
			}
		}


		public string checkinComment
		{
			set
			{
				AddFormParameter("checkinComment", value);
			}
		}

		public Forms_AllItems_aspx()
			: base(url)
		{
		}
		public Forms_AllItems_aspx(CRMEntity user)
			: base(url, user)
		{
		}
		public Forms_AllItems_aspx(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}

		public Forms_AllItems_aspx(CRMEntity user, string siteURL, string entityName)
			: base(url, user, siteURL, entityName)
		{
		}
	}

	[Serializable]
	public class _vti_bin__vti_aut_author_dll : SPRequest
	{
		// server URL
		public const string url = "/_vti_bin/_vti_aut/author.dll";



		// form parameter
		public string method
		{
			set
			{
				AddFormParameter("method", value.ToString());

			}
		}

		public string service_name
		{
			set
			{

				AddFormParameter("service_name", value);

			}
		}
		//form parameters
		public string document_name
		{
			set
			{

				AddFormParameter("document_name", value);
			}
		}

		public string force
		{
			set
			{
				AddFormParameter("force", value);
			}
		}

		public string timeout
		{
			set
			{
				AddFormParameter("timeout", value);
			}
		}

		public string url_list
		{
			set
			{
				AddFormParameter("url_list", value);
			}
		}

		public string listHiddenDocs
		{
			set
			{
				AddFormParameter("listHiddenDocs", value);
			}
		}

		public string listLinkInfo
		{
			set
			{
				AddFormParameter("listLinkInfo", value);
			}
		}

		public _vti_bin__vti_aut_author_dll()
			: base(url)
		{
		}
		public _vti_bin__vti_aut_author_dll(CRMEntity user)
			: base(url, user)
		{
		}
		public _vti_bin__vti_aut_author_dll(CRMEntity user, string siteURL)
			: base(url, user, siteURL)
		{
		}
	}

	[Serializable]
	public class sfa_leads_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/leads/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}


		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public bool qlShowNew
		{
			set
			{
				AddFormParameter("qlShowNew", value.ToString());
			}
		}

		public bool qlCreateAccount
		{
			set
			{
				AddFormParameter("qlCreateAccount", value.ToString());
			}
		}

		public bool qlCreateContact
		{
			set
			{
				AddFormParameter("qlCreateContact", value.ToString());
			}
		}

		public bool qlCreateOpportunity
		{
			set
			{
				AddFormParameter("qlCreateOpportunity", value.ToString());
			}
		}

		public Guid qlOppCurrencyId
		{
			set
			{
				AddFormParameter("qlOppCurrencyId", value.ToString("B"));
			}
		}

		public int qlOpportunityParentType
		{
			set
			{
				AddFormParameter("qlOpportunityParentType", value.ToString());
			}
		}

		public Guid qlOpportunityParentId
		{
			set
			{
				AddFormParameter("qlOpportunityParentId", value.ToString());
			}
		}


		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}


		public sfa_leads_edit_aspx()
			: base(url)
		{
		}
		public sfa_leads_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_leads_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/leads/areas.aspx";

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());
			}
		}

		public long security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());
			}
		}

		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value);
			}
		}

		public sfa_leads_areas_aspx()
			: base(url)
		{
		}
		public sfa_leads_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_quotes_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/quotes/edit.aspx";

		// querystring parameters
		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public bool qlShowNew
		{
			set
			{
				AddFormParameter("qlShowNew", value.ToString());
			}
		}

		public bool qlCreateAccount
		{
			set
			{
				AddFormParameter("qlCreateAccount", value.ToString());
			}
		}

		public bool qlCreateContact
		{
			set
			{
				AddFormParameter("qlCreateContact", value.ToString());
			}
		}

		public bool qlCreateOpportunity
		{
			set
			{
				AddFormParameter("qlCreateOpportunity", value.ToString());
			}
		}

		public int qlOpportunityParentType
		{
			set
			{
				AddFormParameter("qlOpportunityParentType", value.ToString());
			}
		}

		public Guid qlOpportunityParentId
		{
			set
			{
				AddFormParameter("qlOpportunityParentId", value.ToString());
			}
		}


		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}

		public bool fromSave
		{
			set
			{
				AddQueryStringParameter("fromSave", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public sfa_quotes_edit_aspx()
			: base(url)
		{
		}
		public sfa_quotes_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_quotedetail_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/quotedetail/edit.aspx";

		// querystring parameters

		public int _CreateFromType
		{
			set
			{
				AddQueryStringParameter("_CreateFromType", value.ToString());
			}
		}

		public Guid _CreateFromId
		{
			set
			{
				AddQueryStringParameter("_CreateFromId", value.ToString("B"));
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}


		public int isproductoverridden
		{
			set
			{
				AddQueryStringParameter("isproductoverridden", value.ToString());
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public bool qlShowNew
		{
			set
			{
				AddFormParameter("qlShowNew", value.ToString());
			}
		}

		public bool qlCreateAccount
		{
			set
			{
				AddFormParameter("qlCreateAccount", value.ToString());
			}
		}

		public bool qlCreateContact
		{
			set
			{
				AddFormParameter("qlCreateContact", value.ToString());
			}
		}

		public bool qlCreateOpportunity
		{
			set
			{
				AddFormParameter("qlCreateOpportunity", value.ToString());
			}
		}

		public int qlOpportunityParentType
		{
			set
			{
				AddFormParameter("qlOpportunityParentType", value.ToString());
			}
		}

		public Guid qlOpportunityParentId
		{
			set
			{
				AddFormParameter("qlOpportunityParentId", value.ToString());
			}
		}


		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}


		public sfa_quotedetail_edit_aspx()
			: base(url)
		{
		}
		public sfa_quotedetail_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_salesorders_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/salesorder/edit.aspx";

		// querystring parameters
		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}

		public bool fromSave
		{
			set
			{
				AddQueryStringParameter("fromSave", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public sfa_salesorders_edit_aspx()
			: base(url)
		{
		}
		public sfa_salesorders_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_salesorderdetail_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/salesorderdetail/edit.aspx";

		// querystring parameters

		public int _CreateFromType
		{
			set
			{
				AddQueryStringParameter("_CreateFromType", value.ToString());
			}
		}

		public Guid _CreateFromId
		{
			set
			{
				AddQueryStringParameter("_CreateFromId", value.ToString("B"));
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}


		public int isproductoverridden
		{
			set
			{
				AddQueryStringParameter("isproductoverridden", value.ToString());
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}


		public sfa_salesorderdetail_edit_aspx()
			: base(url)
		{
		}
		public sfa_salesorderdetail_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_invoices_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/invoice/edit.aspx";

		// querystring parameters
		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}

		public bool fromSave
		{
			set
			{
				AddQueryStringParameter("fromSave", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public sfa_invoices_edit_aspx()
			: base(url)
		{
		}
		public sfa_invoices_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_invoicedetail_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/invoicedetail/edit.aspx";

		// querystring parameters

		public int _CreateFromType
		{
			set
			{
				AddQueryStringParameter("_CreateFromType", value.ToString());
			}
		}

		public Guid _CreateFromId
		{
			set
			{
				AddQueryStringParameter("_CreateFromId", value.ToString("B"));
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}


		public int isproductoverridden
		{
			set
			{
				AddQueryStringParameter("isproductoverridden", value.ToString());
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}


		public sfa_invoicedetail_edit_aspx()
			: base(url)
		{
		}
		public sfa_invoicedetail_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_conts_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/conts/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		// formbody parameters

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}

		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public sfa_conts_edit_aspx()
			: base(url)
		{
		}
		public sfa_conts_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _controls_number_formatNumber_xsl : CrmRequest
	{
		// server URL
		private const string url = "/_controls/number/formatNumber.xsl";

		// querystring parameters
		public int ver
		{
			set
			{
				AddQueryStringParameter("ver", value.ToString());
			}
		}

		public _controls_number_formatNumber_xsl()
			: base(url)
		{
		}
		public _controls_number_formatNumber_xsl(string crmServer)
			: base(url)
		{
			this.Url = crmServer + this.Url;
			this.ParseDependentRequests = false;
			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
			//this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}
		public _controls_number_formatNumber_xsl(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class CRMReports_viewer_filterxmltosummary_xsl : CrmRequest
	{
		// server URL
		private const string url = "/CRMReports/viewer/filterxmltosummary.xsl";

		// querystring parameters


		public CRMReports_viewer_filterxmltosummary_xsl()
			: base(url)
		{
		}

		public CRMReports_viewer_filterxmltosummary_xsl(string crmServer)
			: base(url)
		{
			this.Url = crmServer + this.Url;
			this.ParseDependentRequests = false;
			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
		}

		public CRMReports_viewer_filterxmltosummary_xsl(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _controls_notes_notesdata_aspx : CrmRequest
	{
		// server URL
		private const string url = "/_controls/notes/notesdata.aspx";

		// querystring parameters
		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public int ParentEntity
		{
			set
			{
				AddQueryStringParameter("ParentEntity", value.ToString());
			}
		}

		public int NotesView
		{
			set
			{
				AddQueryStringParameter("NotesView", value.ToString());
			}
		}

		public bool EnableInlineEdit
		{
			set
			{
				AddQueryStringParameter("EnableInlineEdit", value.ToString());
			}
		}

		public bool EnableInsert
		{
			set
			{
				AddQueryStringParameter("EnableInsert", value.ToString());
			}
		}

		public bool ReadForm
		{
			set
			{
				AddQueryStringParameter("ReadForm", value.ToString());
			}
		}

		public bool Refresh
		{
			set
			{
				AddQueryStringParameter("Refresh", value.ToString());
			}
		}

		public _controls_notes_notesdata_aspx()
			: base(url)
		{
		}
		public _controls_notes_notesdata_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_confirm_delete_aspx : CrmRequest
	{
		public const string url = "/_grid/cmds/dlg_confirm_delete.aspx";

		public int ObjectTypeId
		{
			set
			{
				AddQueryStringParameter("ObjectTypeId", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public _grid_cmds_dlg_confirm_delete_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_confirm_delete_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_delete_aspx : CrmDelRequest
	{
		public const string url = "/_grid/cmds/dlg_delete.aspx";

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public string sSrcQueueId
		{
			set
			{
				AddQueryStringParameter("sSrcQueueId", value);
			}
		}

		public string sParentId
		{
			set
			{
				AddQueryStringParameter("sParentId", value);
			}
		}

		public string sCalendarId
		{
			set
			{
				AddQueryStringParameter("sCalendarId", value);
			}
		}

		public string sSubTypes
		{
			set
			{
				AddQueryStringParameter("sSubTypes", value);
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public string iId
		{
			set
			{
				AddQueryStringParameter("iId", value);
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public int iObjSubType
		{
			set
			{
				AddQueryStringParameter("iObjSubType", value.ToString());
			}
		}

		public string dummyPost
		{
			set
			{
				AddFormParameter("node", null);
			}
		}

		public int user_lcid
		{
			set
			{
				AddQueryStringParameter("user_lcid", value.ToString());
			}
		}

		public string client_type
		{
			set
			{
				AddQueryStringParameter("client_type", value);
			}
		}

		public _grid_cmds_dlg_delete_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_delete_aspx(CRMEntity user)
			: base(url, user)
		{
		}

	}

	[Serializable]
	public class _grid_cmds_dlg_delete_contact_aspx : CrmRequest
	{
		private const string url = "/_grid/cmds/dlg_delete_contact.aspx";

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public _grid_cmds_dlg_delete_contact_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_delete_contact_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_clonerole_aspx : CrmRequest
	{
		public const string url = "/_grid/cmds/dlg_clonerole.aspx";

		public Guid roleId
		{
			set
			{
				AddQueryStringParameter("roleId", value.ToString("B"));
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public string iId
		{
			set
			{
				AddQueryStringParameter("iId", value);
			}
		}

		//public string CRMWRPCToken
		//{
		//	  set
		//	  {
		//		  AddFormParameter("CRMWRPCToken", value);
		//	  }
		//}

		//public long CRMWRPCTokenTimeStamp
		//{
		//	  set
		//	  {
		//		  AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
		//	  }
		//}

		public _grid_cmds_dlg_clonerole_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_clonerole_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_deleteqoiproduct_aspx : CrmDelRequest
	{
		public const string url = "/_grid/cmds/dlg_deleteqoiproduct.aspx";

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public string sSrcQueueId
		{
			set
			{
				AddQueryStringParameter("sSrcQueueId", value);
			}
		}

		public string sParentId
		{
			set
			{
				AddQueryStringParameter("sParentId", value);
			}
		}

		public string sCalendarId
		{
			set
			{
				AddQueryStringParameter("sCalendarId", value);
			}
		}

		public string sSubTypes
		{
			set
			{
				AddQueryStringParameter("sSubTypes", value);
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public string iId
		{
			set
			{
				AddQueryStringParameter("iId", value);
			}
		}

		public string sId
		{
			set
			{
				AddQueryStringParameter("sId", value);
			}
		}

		public string iObjSubType
		{
			set
			{
				AddQueryStringParameter("iObjSubType", value);
			}
		}

		public string dummyPost
		{
			set
			{
				AddFormParameter("node", null);
			}
		}

		public _grid_cmds_dlg_deleteqoiproduct_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_deleteqoiproduct_aspx(CRMEntity user)
			: base(url, user)
		{
		}

	}

	[Serializable]
	public class _grid_cmds_dlg_role_aspx : CrmRequest
	{
		public const string url = "/_grid/cmds/dlg_role.aspx";

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public string sSrcQueueId
		{
			set
			{
				AddQueryStringParameter("sSrcQueueId", value);
			}
		}

		public string sParentId
		{
			set
			{
				AddQueryStringParameter("sParentId", value);
			}
		}

		public string sCalendarId
		{
			set
			{
				AddQueryStringParameter("sCalendarId", value);
			}
		}

		public string sSubTypes
		{
			set
			{
				AddQueryStringParameter("sSubTypes", value);
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public string iId
		{
			set
			{
				AddQueryStringParameter("iId", value);
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public string iObjSubType
		{
			set
			{
				AddQueryStringParameter("iObjSubType", value);
			}
		}

		public string dummyPost
		{
			set
			{
				AddFormParameter("node", null);
			}
		}

		public _grid_cmds_dlg_role_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_role_aspx(CRMEntity user)
			: base(url, user)
		{
		}

	}

	[Serializable]
	public class _SFA_opps_dlg_closeopp_aspx : CrmRequest
	{
		public const string url = "/SFA/opps/dlg_closeopp.aspx";

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public string pid
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString());
			}
		}

		public int PType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public string won
		{
			set
			{
				AddQueryStringParameter("won", value.ToString());
			}
		}

		public _SFA_opps_dlg_closeopp_aspx()
			: base(url)
		{
		}
		public _SFA_opps_dlg_closeopp_aspx(CRMEntity user)
			: base(url, user)
		{
		}

	}

	[Serializable]
	public class _sfa_quotes_dlg_products_aspx : CrmRequest
	{
		public const string url = "/sfa/quotes/dlg_products.aspx";

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public string name
		{
			set
			{
				AddQueryStringParameter("name", value.ToString());
			}
		}

		public int opportunityid
		{
			set
			{
				AddQueryStringParameter("opportunityid", value.ToString());
			}
		}

		public string transactioncurrencyid
		{
			set
			{
				AddQueryStringParameter("transactioncurrencyid", value.ToString());
			}
		}

		public _sfa_quotes_dlg_products_aspx()
			: base(url)
		{
		}
		public _sfa_quotes_dlg_products_aspx(CRMEntity user)
			: base(url, user)
		{
		}

	}
	[Serializable]
	public class _grid_cmds_getroles_aspx : CrmRequest
	{
		public const string url = "/_grid/cmds/getroles.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public string sSrcQueueId
		{
			set
			{
				AddQueryStringParameter("sSrcQueueId", value);
			}
		}

		public string sParentId
		{
			set
			{
				AddQueryStringParameter("sParentId", value);
			}
		}

		public string sCalendarId
		{
			set
			{
				AddQueryStringParameter("sCalendarId", value);
			}
		}

		public string sSubTypes
		{
			set
			{
				AddQueryStringParameter("sSubTypes", value);
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public string iId
		{
			set
			{
				AddQueryStringParameter("iId", value);
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public string iObjSubType
		{
			set
			{
				AddQueryStringParameter("iObjSubType", value);
			}
		}

		public string dummyPost
		{
			set
			{
				AddFormParameter("node", null);
			}
		}

		public _grid_cmds_getroles_aspx()
			: base(url)
		{
		}
		public _grid_cmds_getroles_aspx(CRMEntity user)
			: base(url, user)
		{
		}

	}

	[Serializable]
	public class _grid_cmds_dlg_changeparent_aspx : CrmRequest
	{
		public const string url = "/_grid/cmds/dlg_changeparent.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public string sSrcQueueId
		{
			set
			{
				AddQueryStringParameter("sSrcQueueId", value);
			}
		}

		public string sParentId
		{
			set
			{
				AddQueryStringParameter("sParentId", value);
			}
		}

		public string sCalendarId
		{
			set
			{
				AddQueryStringParameter("sCalendarId", value);
			}
		}

		public string sSubTypes
		{
			set
			{
				AddQueryStringParameter("sSubTypes", value);
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public string iId
		{
			set
			{
				AddQueryStringParameter("iId", value);
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public string iObjSubType
		{
			set
			{
				AddQueryStringParameter("iObjSubType", value);
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public _grid_cmds_dlg_changeparent_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_changeparent_aspx(CRMEntity user)
			: base(url, user)
		{
		}

	}

	[Serializable]
	public class workplace_home_activities_aspx : CrmRequest
	{
		// server URL
		private const string url = "/Workplace/home_activities.aspx";

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public workplace_home_activities_aspx()
			: base(url)
		{
		}
		public workplace_home_activities_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class workplace_home_workplace_aspx : CrmRequest
	{
		// server URL
		private const string url = "/Workplace/home_workplace.aspx";

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public workplace_home_workplace_aspx()
			: base(url)
		{
		}
		public workplace_home_workplace_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class activities_task_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/activities/task/edit.aspx";

		// querystring parameters
		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString());
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("ptype", value.ToString());
			}
		}

		public string pName
		{
			set
			{
				AddQueryStringParameter("pName", value);
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}


		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public activities_task_edit_aspx()
			: base(url)
		{
		}
		public activities_task_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class activities_email_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/activities/email/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString());
			}
		}

		public Guid partyid
		{
			set
			{
				AddQueryStringParameter("partyid", value.ToString());
			}
		}

		public int partytype
		{
			set
			{
				AddQueryStringParameter("partytype", value.ToString());
			}
		}

		public string partyname
		{
			set
			{
				AddQueryStringParameter("partyname", value);
			}
		}


		public int pType
		{
			set
			{
				AddQueryStringParameter("ptype", value.ToString());
			}
		}

		public string pName
		{
			set
			{
				AddQueryStringParameter("pName", value);
			}
		}


		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public activities_email_edit_aspx()
			: base(url)
		{
		}
		public activities_email_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class activities_appointment_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/activities/appointment/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString());
			}
		}

		public Guid partyid
		{
			set
			{
				AddQueryStringParameter("partyid", value.ToString());
			}
		}

		public int partytype
		{
			set
			{
				AddQueryStringParameter("partytype", value.ToString());
			}
		}

		public string partyname
		{
			set
			{
				AddQueryStringParameter("partyname", value);
			}
		}


		public int pType
		{
			set
			{
				AddQueryStringParameter("ptype", value.ToString());
			}
		}

		public string pName
		{
			set
			{
				AddQueryStringParameter("pName", value);
			}
		}


		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public activities_appointment_edit_aspx()
			: base(url)
		{
		}
		public activities_appointment_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class activities_fax_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/activities/fax/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString());
			}
		}

		public Guid partyid
		{
			set
			{
				AddQueryStringParameter("partyid", value.ToString());
			}
		}

		public int partytype
		{
			set
			{
				AddQueryStringParameter("partytype", value.ToString());
			}
		}

		public string partyname
		{
			set
			{
				AddQueryStringParameter("partyname", value);
			}
		}


		public int pType
		{
			set
			{
				AddQueryStringParameter("ptype", value.ToString());
			}
		}

		public string pName
		{
			set
			{
				AddQueryStringParameter("pName", value);
			}
		}


		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public activities_fax_edit_aspx()
			: base(url)
		{
		}
		public activities_fax_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class activities_letter_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/activities/letter/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString());
			}
		}

		public Guid partyid
		{
			set
			{
				AddQueryStringParameter("partyid", value.ToString());
			}
		}

		public int partytype
		{
			set
			{
				AddQueryStringParameter("partytype", value.ToString());
			}
		}

		public string partyname
		{
			set
			{
				AddQueryStringParameter("partyname", value);
			}
		}


		public int pType
		{
			set
			{
				AddQueryStringParameter("ptype", value.ToString());
			}
		}

		public string pName
		{
			set
			{
				AddQueryStringParameter("pName", value);
			}
		}


		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public activities_letter_edit_aspx()
			: base(url)
		{
		}
		public activities_letter_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class activities_phone_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/activities/phone/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString());
			}
		}

		public Guid partyid
		{
			set
			{
				AddQueryStringParameter("partyid", value.ToString());
			}
		}

		public int partytype
		{
			set
			{
				AddQueryStringParameter("partytype", value.ToString());
			}
		}

		public string partyname
		{
			set
			{
				AddQueryStringParameter("partyname", value);
			}
		}


		public int pType
		{
			set
			{
				AddQueryStringParameter("ptype", value.ToString());
			}
		}

		public string pName
		{
			set
			{
				AddQueryStringParameter("pName", value);
			}
		}


		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public activities_phone_edit_aspx()
			: base(url)
		{
		}
		public activities_phone_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class notes_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/notes/edit.aspx";

		// querystring parameters
		public string id
		{
			set
			{
				AddQueryStringParameter("id", value);
			}
		}

		public notes_edit_aspx()
			: base(url)
		{
		}
		public notes_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_home_camps_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/home_camps.aspx";

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public MA_home_camps_aspx()
			: base(url)
		{
		}
		public MA_home_camps_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class ma_camps_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/ma/camps/edit.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public bool fromSave
		{
			set
			{
				AddQueryStringParameter("fromSave", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public ma_camps_edit_aspx()
			: base(url)
		{
		}
		public ma_camps_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class ma_camps_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/ma/camps/areas.aspx";

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());
			}
		}

		public long security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());
			}
		}

		public int createdfromcode
		{
			set
			{
				AddQueryStringParameter("createdfromcode", value.ToString());
			}
		}

		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value);
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public ma_camps_areas_aspx()
			: base(url)
		{
		}
		public ma_camps_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class ma_campaignactivity_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/ma/campaignactivity/edit.aspx";

		// QueryStringParameters
		public int _CreateFromType
		{
			set
			{
				AddQueryStringParameter("_CreateFromType", value.ToString());
			}
		}

		public Guid _CreateFromId
		{
			set
			{
				AddQueryStringParameter("_CreateFromId", value.ToString("B"));
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		//FormDataParameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value);
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public ma_campaignactivity_edit_aspx()
			: base(url)
		{
		}
		public ma_campaignactivity_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class ma_campaignresponse_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/ma/campaignresponse/edit.aspx";

		// QueryStringParameters
		public int _CreateFromType
		{
			set
			{
				AddQueryStringParameter("_CreateFromType", value.ToString());
			}
		}

		public Guid _CreateFromId
		{
			set
			{
				AddQueryStringParameter("_CreateFromId", value.ToString("B"));
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		//FormDataParameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value);
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public ma_campaignresponse_edit_aspx()
			: base(url)
		{
		}
		public ma_campaignresponse_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class ma_lists_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/ma/lists/edit.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		// formbody parameters
		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value);
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public bool fromSave
		{
			set
			{
				AddQueryStringParameter("fromSave", value.ToString());
			}
		}

		public ma_lists_edit_aspx()
			: base(url)
		{
		}
		public ma_lists_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class ma_lists_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/ma/lists/areas.aspx";

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());
			}
		}

		public int createdfromcode
		{
			set
			{
				AddQueryStringParameter("createdfromcode", value.ToString());
			}
		}

		public long security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());
			}
		}

		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value);
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public ma_lists_areas_aspx()
			: base(url)
		{
		}
		public ma_lists_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class biz_teams_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/biz/teams/areas.aspx";

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());
			}
		}

		public int createdfromcode
		{
			set
			{
				AddQueryStringParameter("createdfromcode", value.ToString());
			}
		}

		public long security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());
			}
		}

		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value);
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public biz_teams_areas_aspx()
			: base(url)
		{
		}
		public biz_teams_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class grid_cmds_cmd_adduserteam_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/cmd_adduserteam.aspx";

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}


		public grid_cmds_cmd_adduserteam_aspx()
			: base(url)
		{
		}
		public grid_cmds_cmd_adduserteam_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_lists_ListQualificationDlg_dlg_manage_members_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/lists/ListQualificationDlg/dlg_manage_members.aspx";

		public MA_lists_ListQualificationDlg_dlg_manage_members_aspx()
			: base(url)
		{
		}
		public MA_lists_ListQualificationDlg_dlg_manage_members_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_lists_ListQualificationDlg_dlg_query_build_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/lists/ListQualificationDlg/dlg_query_build.aspx";

		public int ListMemberType
		{
			set
			{
				AddQueryStringParameter("ListMemberType", value.ToString());
			}
		}

		public Guid ListId
		{
			set
			{
				AddQueryStringParameter("ListId", value.ToString("B"));
			}
		}

		public string InvokeType
		{
			set
			{
				AddQueryStringParameter("InvokeType", value);
			}
		}

		public string invoker
		{
			set
			{
				AddQueryStringParameter("invoker", value);
			}
		}

		public int restrictOtherEntities
		{
			set
			{
				AddQueryStringParameter("restrictOtherEntities", value.ToString());
			}
		}

		public MA_lists_ListQualificationDlg_dlg_query_build_aspx()
			: base(url)
		{
		}
		public MA_lists_ListQualificationDlg_dlg_query_build_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_Lists_ListQualificationDlg_dlg_List_qualify_aspx : CrmRequest
	{

		// server URL
		public const string url = "/MA/lists/ListQualificationDlg/dlg_List_qualify.aspx";

		public Guid itemObjectId
		{
			set
			{
				AddQueryStringParameter("itemObjectId", value.ToString("B"));
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int itemObjectTypeCode
		{
			set
			{
				AddQueryStringParameter("itemObjectTypeCode", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public Guid savedQueryId
		{
			set
			{
				AddQueryStringParameter("savedQueryId", value.ToString("B"));
			}
		}

		public int savedQueryType
		{
			set
			{
				AddQueryStringParameter("savedQueryType", value.ToString());
			}
		}

		public bool isDirty
		{
			set
			{
				AddQueryStringParameter("isDirty", value.ToString());
			}
		}

		public string sInvokeType
		{
			set
			{
				AddQueryStringParameter("sInvokeType", value.ToString());
			}
		}

		public int iOption
		{
			set
			{
				AddQueryStringParameter("iOption", value.ToString());
			}
		}

		public int iViewType
		{
			set
			{
				AddQueryStringParameter("iViewType", value.ToString());
			}
		}

		public MA_Lists_ListQualificationDlg_dlg_List_qualify_aspx()
			: base(url)
		{
		}
		public MA_Lists_ListQualificationDlg_dlg_List_qualify_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_Lists_ListQualificationDlg_dlg_DynamicList_query_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/lists/ListQualificationDlg/dlg_dynamiclist_query.aspx";

		public MA_Lists_ListQualificationDlg_dlg_DynamicList_query_aspx()
			: base(url)
		{
		}
		public MA_Lists_ListQualificationDlg_dlg_DynamicList_query_aspx(CRMEntity user)
			: base(url, user)
		{
		}

		public Guid itemObjectId
		{
			set
			{
				AddQueryStringParameter("itemObjectId", value.ToString("B"));
			}
		}
	}

	[Serializable]
	public class MA_MiniCampaign_MiniCampaign_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/MiniCampaign/MiniCampaign.aspx";

		public MA_MiniCampaign_MiniCampaign_aspx()
			: base(url)
		{
		}
		public MA_MiniCampaign_MiniCampaign_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_MiniCampaign_iframes_letterForm_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/MiniCampaign/iframes/letterForm.aspx";

		public MA_MiniCampaign_iframes_letterForm_aspx()
			: base(url)
		{
		}
		public MA_MiniCampaign_iframes_letterForm_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_MiniCampaign_iframes_phonecallForm_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/MiniCampaign/iframes/phonecallForm.aspx";

		public MA_MiniCampaign_iframes_phonecallForm_aspx()
			: base(url)
		{
		}
		public MA_MiniCampaign_iframes_phonecallForm_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_MiniCampaign_iframes_appointmentForm_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/MiniCampaign/iframes/appointmentForm.aspx";

		public MA_MiniCampaign_iframes_appointmentForm_aspx()
			: base(url)
		{
		}
		public MA_MiniCampaign_iframes_appointmentForm_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_MiniCampaign_iframes_faxForm_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/MiniCampaign/iframes/faxForm.aspx";

		public MA_MiniCampaign_iframes_faxForm_aspx()
			: base(url)
		{
		}
		public MA_MiniCampaign_iframes_faxForm_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_MiniCampaign_iframes_emailForm_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/MiniCampaign/iframes/emailForm.aspx";

		public MA_MiniCampaign_iframes_emailForm_aspx()
			: base(url)
		{
		}
		public MA_MiniCampaign_iframes_emailForm_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class MA_CampaignActivity_Dialogs_confirm_propagation_aspx : CrmRequest
	{
		// server URL
		public const string url = "/MA/CampaignActivity/Dialogs/confirm_propagation.aspx";

		//QueryStringParameters
		public int EntityTypeCode
		{
			set
			{
				AddQueryStringParameter("EntityTypeCode", value.ToString());
			}
		}

		public MA_CampaignActivity_Dialogs_confirm_propagation_aspx()
			: base(url)
		{
		}
		public MA_CampaignActivity_Dialogs_confirm_propagation_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_frmassign_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_frmassign.aspx";

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public int iObjtype
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public _grid_cmds_dlg_frmassign_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_frmassign_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_mergemultiple_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_mergemultiple.aspx";

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public string requestType
		{
			set
			{
				AddQueryStringParameter("requestType", value);
			}
		}


		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid masterId
		{
			set
			{
				AddQueryStringParameter("masterId", value.ToString("B"));
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public _grid_cmds_dlg_mergemultiple_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_mergemultiple_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sfa_leads_dialogs_conv_lead_aspx : CrmRequest
	{
		// server URL
		public const string url = "/SFA/leads/dialogs/conv_lead.aspx";

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}
		public bool qualify
		{
			set
			{
				AddQueryStringParameter("qualify", value.ToString());
			}
		}
		public string iId
		{
			set
			{
				AddQueryStringParameter("iId", value);
			}
		}
		public sfa_leads_dialogs_conv_lead_aspx()
			: base(url)
		{
		}
		public sfa_leads_dialogs_conv_lead_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class activities_dlg_create_aspx : CrmRequest
	{
		// server URL
		public const string url = "/Activities/dlg_create.aspx";

		public Guid _CreateFromId
		{
			set
			{
				AddQueryStringParameter("_CreateFromId", value.ToString("B"));
			}
		}

		public int _CreateFromType
		{
			set
			{
				AddQueryStringParameter("_CreateFromType", value.ToString());
			}
		}


		public activities_dlg_create_aspx()
			: base(url)
		{
		}
		public activities_dlg_create_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _controls_htmlbar_htmlbar_css_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_controls/htmlbar/htmlbar.css.aspx";

		// QueryString Parameters

		public int lcid
		{
			set
			{
				AddQueryStringParameter("lcid", value.ToString());
			}
		}

		public _controls_htmlbar_htmlbar_css_aspx()
			: base(url)
		{
		}
		public _controls_htmlbar_htmlbar_css_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _controls_emailbody_msgbody_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_controls/emailbody/msgBody.aspx";

		public _controls_emailbody_msgbody_aspx()
			: base(url)
		{
		}
		public _controls_emailbody_msgbody_aspx(CRMEntity user)
			: base(url, user)
		{
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public string entityType
		{
			set
			{
				AddQueryStringParameter("entityType", value);
			}
		}
	}

	[Serializable]
	public class _controls_lookup_lookupmulti_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_controls/lookup/lookupmulti.aspx";

		public _controls_lookup_lookupmulti_aspx()
			: base(url)
		{
		}
		public _controls_lookup_lookupmulti_aspx(CRMEntity user)
			: base(url, user)
		{
		}

		public string Class
		{
			set
			{
				AddQueryStringParameter("class", value);
			}
		}

		public string objecttypes
		{
			set
			{
				AddQueryStringParameter("objecttypes", value);
			}
		}

		public int browse
		{
			set
			{
				AddQueryStringParameter("browse", value.ToString());
			}
		}

		public int DefaultType
		{
			set
			{
				AddQueryStringParameter("DefaultType", value.ToString());
			}
		}

		public int ObjectType
		{
			set
			{
				AddQueryStringParameter("objectType", value.ToString());
			}
		}

		public int Mode
		{
			set
			{
				AddQueryStringParameter("Mode", value.ToString());
			}
		}

		public int ColumnsOnly
		{
			set
			{
				AddQueryStringParameter("ColumnsOnly", value.ToString());
			}
		}

		public string searchvalue
		{
			set
			{
				AddQueryStringParameter("searchvalue", value);
			}
		}

		public int ShowNewButton
		{
			set
			{
				AddQueryStringParameter("ShowNewButton", value.ToString());
			}
		}

		public int ShowPropButton
		{
			set
			{
				AddQueryStringParameter("ShowPropButton", value.ToString());
			}
		}
	}

	[Serializable]
	public class _controls_lookup_lookupinfo_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_controls/lookup/lookupinfo.aspx";


		public string LookupStyle
		{
			set
			{
				AddQueryStringParameter("LookupStyle", value);
			}
		}

		public int ObjectTypeCode
		{
			set
			{
				AddQueryStringParameter("ObjectTypeCode", value.ToString());
			}
		}

		public Guid ObjectId
		{
			set
			{
				AddQueryStringParameter("ObjectId", value.ToString("B"));
			}
		}

		public Guid ProductId
		{
			set
			{
				AddQueryStringParameter("ProductId", value.ToString("B"));
			}
		}

		public string Class
		{
			set
			{
				AddQueryStringParameter("class", value);
			}
		}

		public string objecttypes
		{
			set
			{
				AddQueryStringParameter("objecttypes", value);
			}
		}

		public int AllowFilterOff
		{
			set
			{
				AddQueryStringParameter("AllowFilterOff", value.ToString());
			}
		}

		public int DisableQuickFind
		{
			set
			{
				AddQueryStringParameter("DisableQuickFind", value.ToString());
			}
		}

		public int DisableViewPicker
		{
			set
			{
				AddQueryStringParameter("DisableViewPicker", value.ToString());
			}
		}

		public int browse
		{
			set
			{
				AddQueryStringParameter("browse", value.ToString());
			}
		}

		public int ShowNewButton
		{
			set
			{
				AddQueryStringParameter("ShowNewButton", value.ToString());
			}
		}

		public int ShowPropButton
		{
			set
			{
				AddQueryStringParameter("ShowPropButton", value.ToString());
			}
		}

		public int DefaultType
		{
			set
			{
				AddQueryStringParameter("DefaultType", value.ToString());
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public int IsInlineMultiLookup
		{
			set
			{
				AddQueryStringParameter("IsInlineMultiLookup", value.ToString());
			}
		}

		public Guid DefaultViewId
		{
			set
			{
				AddQueryStringParameter("DefaultViewId", value.ToString("B"));
			}
		}

		public Guid transactioncurrencyid
		{
			set
			{
				AddQueryStringParameter("transactioncurrencyid", value.ToString());
			}
		}

		public string bindingcolumns
		{
			set
			{
				AddQueryStringParameter("bindingcolumns", value.ToString());
			}
		}

		public Guid businessId
		{
			set
			{
				AddQueryStringParameter("businessid", value.ToString("B"));
			}
		}



		public _controls_lookup_lookupinfo_aspx()
			: base(url)
		{
		}
		public _controls_lookup_lookupinfo_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _controls_lookup_lookupdata_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_controls/lookup/lookupdata.aspx";

		public _controls_lookup_lookupdata_aspx()
			: base(url)
		{
		}
		public _controls_lookup_lookupdata_aspx(CRMEntity user)
			: base(url, user)
		{
		}

		public string Class
		{
			set
			{
				AddQueryStringParameter("class", value);
			}
		}

		public string objecttypes
		{
			set
			{
				AddQueryStringParameter("objecttypes", value);
			}
		}

		public int browse
		{
			set
			{
				AddQueryStringParameter("browse", value.ToString());
			}
		}

		public int DefaultType
		{
			set
			{
				AddQueryStringParameter("DefaultType", value.ToString());
			}
		}

		public int ObjectType
		{
			set
			{
				AddQueryStringParameter("objectType", value.ToString());
			}
		}

		public int Mode
		{
			set
			{
				AddQueryStringParameter("Mode", value.ToString());
			}
		}

		public int ColumnsOnly
		{
			set
			{
				AddQueryStringParameter("ColumnsOnly", value.ToString());
			}
		}

		public string searchvalue
		{
			set
			{
				AddQueryStringParameter("searchvalue", value);
			}
		}

		public int ShowNewButton
		{
			set
			{
				AddQueryStringParameter("ShowNewButton", value.ToString());
			}
		}

		public int ShowPropButton
		{
			set
			{
				AddQueryStringParameter("ShowPropButton", value.ToString());
			}
		}

	}

	[Serializable]
	public class _controls_lookup_lookupsingle_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_controls/lookup/lookupsingle.aspx";

		public _controls_lookup_lookupsingle_aspx()
			: base(url)
		{
		}
		public _controls_lookup_lookupsingle_aspx(CRMEntity user)
			: base(url, user)
		{
		}

		public int DefaultType
		{
			set
			{
				AddQueryStringParameter("DefaultType", value.ToString());
			}
		}

		public string Class
		{
			set
			{
				AddQueryStringParameter("class", value);
			}
		}

		public string objecttypes
		{
			set
			{
				AddQueryStringParameter("objecttypes", value);
			}
		}

		public int browse
		{
			set
			{
				AddQueryStringParameter("browse", value.ToString());
			}
		}

		public Guid businessunitid
		{
			set
			{
				AddQueryStringParameter("businessunitid", value.ToString("B"));
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public int membertypecode
		{
			set
			{
				AddQueryStringParameter("membertypecode", value.ToString());
			}
		}

		public int ShowNewButton
		{
			set
			{
				AddQueryStringParameter("ShowNewButton", value.ToString());
			}
		}

		public int ShowPropButton
		{
			set
			{
				AddQueryStringParameter("ShowPropButton", value.ToString());
			}
		}

		public int ObjectType
		{
			set
			{
				AddQueryStringParameter("ObjectType", value.ToString());
			}
		}

		public int ObjectTypeCode
		{
			set
			{
				AddQueryStringParameter("ObjectTypeCode", value.ToString());
			}
		}

		public int Mode
		{
			set
			{
				AddQueryStringParameter("Mode", value.ToString());
			}
		}

		public int ColumnsOnly
		{
			set
			{
				AddQueryStringParameter("ColumnsOnly", value.ToString());
			}
		}

		public string searchvalue
		{
			set
			{
				AddQueryStringParameter("searchvalue", value);
			}
		}

		public Guid priceLevelId
		{
			set
			{
				AddQueryStringParameter("priceLevelId", value.ToString("B"));
			}
		}

		public Guid ObjectId
		{
			set
			{
				AddQueryStringParameter("ObjectId", value.ToString("B"));
			}
		}

		public Guid ProductId
		{
			set
			{
				AddQueryStringParameter("ProductId", value.ToString("B"));
			}
		}

		public Guid transactioncurrencyid
		{
			set
			{
				AddQueryStringParameter("transactioncurrencyid", value.ToString("B"));
			}
		}

		public int AllowFilterOff
		{
			set
			{
				AddQueryStringParameter("AllowFilterOff", value.ToString());
			}
		}


		public Guid currentid
		{
			set
			{
				AddQueryStringParameter("currentid", value.ToString("B"));
			}
		}

	}

	[Serializable]
	public class sfa_quotes_cmd_getquantitydecimal_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sfa/quotes/cmd_getquantitydecimal.aspx";

		public sfa_quotes_cmd_getquantitydecimal_aspx()
			: base(url)
		{
		}
		public sfa_quotes_cmd_getquantitydecimal_aspx(CRMEntity user)
			: base(url, user)
		{
		}

		public int objectTypeCode
		{
			set
			{
				AddQueryStringParameter("objectTypeCode", value.ToString());
			}
		}

		public Guid objectId
		{
			set
			{
				AddQueryStringParameter("objectId", value.ToString("B"));
			}
		}
		public Guid productId
		{
			set
			{
				AddQueryStringParameter("productId", value.ToString("B"));
			}
		}
		public Guid uomId
		{
			set
			{
				AddQueryStringParameter("uomId", value.ToString("B"));
			}
		}
		public string dummy
		{
			set
			{
				AddFormParameter("dummy", value);
			}
		}
	}

	[Serializable]
	public class sm_home_apptbook_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sm/home_apptbook.aspx";

		public int zoomLevel
		{
			set
			{
				AddQueryStringParameter("zoomLevel", value.ToString());
			}
		}

		public DateTime startDate
		{
			set
			{
				AddQueryStringParameter("startDate", value.ToString("s"));
			}
		}

		public DateTime endDate
		{
			set
			{
				AddQueryStringParameter("endDate", value.ToString("s"));
			}
		}

		public bool showConflict
		{
			set
			{
				AddQueryStringParameter("showConflict", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value);
			}
		}

		public sm_home_apptbook_aspx()
			: base(url)
		{
		}
		public sm_home_apptbook_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sm_ganttcontrolframe_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sm/GanttControlFrame.aspx";

		public DateTime startDate
		{
			set
			{
				AddQueryStringParameter("startDate", value.ToString("s"));
			}
		}

		public DateTime endDate
		{
			set
			{
				AddQueryStringParameter("endDate", value.ToString("s"));
			}
		}

		public string subareatype
		{
			set
			{
				AddQueryStringParameter("subareatype", value);
			}
		}

		public Guid viewID
		{
			set
			{
				AddQueryStringParameter("viewID", value.ToString("B"));
			}
		}

		public int viewType
		{
			set
			{
				AddQueryStringParameter("viewType", value.ToString());
			}
		}

		public int zoomLevel
		{
			set
			{
				AddQueryStringParameter("zoomLevel", value.ToString());
			}
		}

		public string pagingCookie
		{
			set
			{
				AddQueryStringParameter("pagingCookie", value);
			}
		}

		public string selRowID
		{
			set
			{
				AddQueryStringParameter("selRowID", value);
			}
		}

		public string selBlockID
		{
			set
			{
				AddQueryStringParameter("selBlockID", value);
			}
		}

		public sm_ganttcontrolframe_aspx()
			: base(url)
		{
		}
		public sm_ganttcontrolframe_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sm_detailsappointmentpane_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sm/DetailsAppointmentPane.aspx";

		public string subAreaType
		{
			set
			{
				AddQueryStringParameter("subAreaType", value);
			}
		}

		public int rowType
		{
			set
			{
				AddQueryStringParameter("rowType", value.ToString());
			}
		}

		public Guid rowId
		{
			set
			{
				AddQueryStringParameter("rowId", value.ToString("B"));
			}
		}

		public int blockType
		{
			set
			{
				AddQueryStringParameter("blockType", value.ToString());
			}
		}

		public Guid blockId
		{
			set
			{
				AddQueryStringParameter("blockId", value.ToString("B"));
			}
		}

		public sm_detailsappointmentpane_aspx()
			: base(url)
		{
		}
		public sm_detailsappointmentpane_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sm_customizableform_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sm/customizableForm.aspx";

		public int type
		{
			set
			{
				AddQueryStringParameter("type", value.ToString());
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public Guid tabID
		{
			set
			{
				AddQueryStringParameter("tabID", value.ToString("B"));
			}
		}

		public sm_customizableform_aspx()
			: base(url)
		{
		}
		public sm_customizableform_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class activities_serviceappointment_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/activities/serviceappointment/edit.aspx";

		public DateTime _StartTime
		{
			set
			{
				AddQueryStringParameter("_StartTime", value.ToString("s"));
			}
		}

		public bool loadDialog
		{
			set
			{
				AddQueryStringParameter("loadDialog", value.ToString());
			}
		}

		public activities_serviceappointment_edit_aspx()
			: base(url)
		{
		}
		public activities_serviceappointment_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class sm_activityscheduling_schedulingdialog_aspx : CrmRequest
	{
		// server URL
		public const string url = "/sm/activityscheduling/schedulingdialog.aspx";

		public Guid ActivityId
		{
			set
			{
				AddQueryStringParameter("ActivityId", value.ToString("B"));
			}
		}

		public int ActivityTypeCode
		{
			set
			{
				AddQueryStringParameter("ActivityTypeCode", value.ToString());
			}
		}

		public sm_activityscheduling_schedulingdialog_aspx()
			: base(url)
		{
		}
		public sm_activityscheduling_schedulingdialog_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class workplace_home_calendar_aspx : CrmRequest
	{
		// server URL
		public const string url = "/workplace/home_calendar.aspx";

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value.ToString());
			}
		}

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value.ToString());
			}
		}

		public workplace_home_calendar_aspx()
			: base(url)
		{
		}

		public workplace_home_calendar_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class calendar_day_aspx : CrmRequest
	{
		// server URL
		public const string url = "/calendar/Day.aspx";

		public DateTime date
		{
			set
			{
				AddQueryStringParameter("date", value.ToString("s"));
			}
		}

		public calendar_day_aspx()
			: base(url)
		{
		}

		public calendar_day_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class calendar_week_aspx : CrmRequest
	{
		// server URL
		public const string url = "/calendar/Week.aspx";

		public DateTime date
		{
			set
			{
				AddQueryStringParameter("date", value.ToString("s"));
			}
		}

		public calendar_week_aspx()
			: base(url)
		{
		}

		public calendar_week_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class calendar_month_aspx : CrmRequest
	{
		// server URL
		public const string url = "/calendar/monthlycalendardata.aspx";

		public DateTime date
		{
			set
			{
				AddQueryStringParameter("date", value.ToString("s"));
			}
		}

		public calendar_month_aspx()
			: base(url)
		{
		}

		public calendar_month_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class cs_home_cases_aspx : CrmRequest
	{
		// server URL
		public const string url = "/cs/home_cases.aspx";

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public cs_home_cases_aspx()
			: base(url)
		{
		}
		public cs_home_cases_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class cs_cases_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/cs/cases/edit.aspx";

		// querystrings
		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid assignOwnerId
		{
			set
			{
				AddFormParameter("assignOwnerId", value.ToString("B"));
			}
		}

		public int assignOwnerType
		{
			set
			{
				AddFormParameter("assignOwnerType", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rskey
		{
			set
			{
				AddQueryStringParameter("rskey", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public cs_cases_edit_aspx()
			: base(url)
		{
		}
		public cs_cases_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _controls_lookup_lookupsubject_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_controls/lookup/lookupsubject.aspx";

		public _controls_lookup_lookupsubject_aspx()
			: base(url)
		{
		}
		public _controls_lookup_lookupsubject_aspx(CRMEntity user)
			: base(url, user)
		{
		}

		public string Class
		{
			set
			{
				AddQueryStringParameter("class", value);
			}
		}

		public string objecttypes
		{
			set
			{
				AddQueryStringParameter("objecttypes", value);
			}
		}

		public int browse
		{
			set
			{
				AddQueryStringParameter("browse", value.ToString());
			}
		}

		public int ShowNewButton
		{
			set
			{
				AddQueryStringParameter("ShowNewButton", value.ToString());
			}
		}

		public int ShowPropButton
		{
			set
			{
				AddQueryStringParameter("ShowPropButton", value.ToString());
			}
		}

		public int DefaultType
		{
			set
			{
				AddQueryStringParameter("DefaultType", value.ToString());
			}
		}

		public int ObjectType
		{
			set
			{
				AddQueryStringParameter("ObjectType", value.ToString());
			}
		}

		public int ObjectTypeCode
		{
			set
			{
				AddQueryStringParameter("ObjectTypeCode", value.ToString());
			}
		}

		public int Mode
		{
			set
			{
				AddQueryStringParameter("Mode", value.ToString());
			}
		}

		public int ColumnsOnly
		{
			set
			{
				AddQueryStringParameter("ColumnsOnly", value.ToString());
			}
		}

		public string searchvalue
		{
			set
			{
				AddQueryStringParameter("searchvalue", value);
			}
		}

		public Guid priceLevelId
		{
			set
			{
				AddQueryStringParameter("priceLevelId", value.ToString("B"));
			}
		}

		public Guid ObjectId
		{
			set
			{
				AddQueryStringParameter("ObjectId", value.ToString("B"));
			}
		}

		public Guid ProductId
		{
			set
			{
				AddQueryStringParameter("ProductId", value.ToString("B"));
			}
		}

	}

	[Serializable]
	public class _grid_cmds_dlg_assignqueue_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_assignqueue.aspx";

		public Guid uid
		{
			set
			{
				AddQueryStringParameter("uid", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public int sQType
		{
			set
			{
				AddQueryStringParameter("sQType", value.ToString());
			}
		}

		public int FromForm
		{
			set
			{
				AddQueryStringParameter("FromForm", value.ToString());
			}
		}

		public int FromIncidentFrm
		{
			set
			{
				AddQueryStringParameter("FromIncidentFrm", value.ToString());
			}
		}

		public int iObjtype
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public _grid_cmds_dlg_assignqueue_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_assignqueue_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_Admin_admin_aspx : CrmRequest
	{
		public const string url = "/tools/Admin/admin.aspx";

		public int pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value);
			}
		}

		public bool web
		{
			set
			{
				AddQueryStringParameter("web", value.ToString());
			}
		}

		public tools_Admin_admin_aspx()
			: base(url)
		{
		}
		public tools_Admin_admin_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_home_tools_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/home_tools.aspx";

		public int pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString());
			}
		}

		public tools_home_tools_aspx()
			: base(url)
		{
		}
		public tools_home_tools_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_business_home_role_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/business/home_role.aspx";

		public tools_business_home_role_aspx()
			: base(url)
		{
		}
		public tools_business_home_role_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_business_business_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/business/business.aspx";

		//querystring parameters

		public int pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public bool web
		{
			set
			{
				AddQueryStringParameter("web", value.ToString());
			}
		}

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value.ToString());
			}
		}

		public tools_business_business_aspx()
			: base(url)
		{
		}
		public tools_business_business_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_QueuingManager_home_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/QueuingManager/home.aspx";

		//querystring parameters

		public int oid
		{
			set
			{
				AddQueryStringParameter("oid", value.ToString());
			}
		}

		public tools_QueuingManager_home_aspx()
			: base(url)
		{
		}
		public tools_QueuingManager_home_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_QueuingManager_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/QueuingManager/edit.aspx";

		//querystring parameters

		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString());
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public Guid AppSolutionId
		{
			set
			{
				AddFormParameter("AppSolutionId", value.ToString("B"));
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public tools_QueuingManager_edit_aspx()
			: base(url)
		{
		}
		public tools_QueuingManager_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_productcatalog_productcatalog_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/productcatalog/productcatalog.aspx";

		public int pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString());
			}
		}

		public tools_productcatalog_productcatalog_aspx()
			: base(url)
		{
		}
		public tools_productcatalog_productcatalog_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_productcatalog_home_discounttype_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/productcatalog/home_discounttype.aspx";

		public tools_productcatalog_home_discounttype_aspx()
			: base(url)
		{
		}
		public tools_productcatalog_home_discounttype_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_productcatalog_dlg_create_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/ProductCatalog/dlg_create.aspx";

		public int ObjType
		{
			set
			{
				AddQueryStringParameter("ObjType", value.ToString());
			}
		}

		public tools_productcatalog_dlg_create_aspx()
			: base(url)
		{
		}
		public tools_productcatalog_dlg_create_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_audit_auditarea_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/audit/audit_area.aspx";

		//querystring parameters

		public int pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string web
		{
			set
			{
				AddQueryStringParameter("web", value);
			}
		}

		public tools_audit_auditarea_aspx()
			: base(url)
		{
		}
		public tools_audit_auditarea_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_audit_auditsummary_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/audit/audit_summary.aspx";

		public tools_audit_auditsummary_aspx()
			: base(url)
		{
		}
		public tools_audit_auditsummary_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class products_discounttype_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/products/discounttype/edit.aspx";

		public string name
		{
			set
			{
				AddQueryStringParameter("name", value);
			}
		}

		public int isamounttype
		{
			set
			{
				AddQueryStringParameter("isamounttype", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddQueryStringParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddQueryStringParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public products_discounttype_edit_aspx()
			: base(url)
		{
		}
		public products_discounttype_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class biz_roles_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/biz/roles/edit.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}


		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public biz_roles_edit_aspx()
			: base(url)
		{
		}
		public biz_roles_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_business_home_user_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/business/home_user.aspx";

		public int pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString());
			}
		}

		public tools_business_home_user_aspx()
			: base(url)
		{
		}
		public tools_business_home_user_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_business_home_team_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/business/home_team.aspx";

		public int pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString());
			}
		}

		public tools_business_home_team_aspx()
			: base(url)
		{
		}
		public tools_business_home_team_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class biz_users_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/biz/users/edit.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public biz_users_edit_aspx()
			: base(url)
		{
		}
		public biz_users_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class biz_users_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/biz/users/areas.aspx";

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());
			}
		}

		public long security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());
			}
		}

		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value);
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}


		public biz_users_areas_aspx()
			: base(url)
		{
		}
		public biz_users_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class biz_teams_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/biz/teams/edit.aspx";

		public Guid _CreateFromId
		{
			set
			{
				AddQueryStringParameter("_CreateFromId", value.ToString("B"));
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public int _CreateFromType
		{
			set
			{
				AddQueryStringParameter("_CreateFromType", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public string crmFormOriginalXml
		{
			set
			{
				AddFormParameter("crmFormOriginalXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public string crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value);
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public int crmCrmdId
		{
			set
			{
				AddFormParameter("crmCmdId", value.ToString());
			}
		}

		public int rsid
		{
			set
			{
				AddQueryStringParameter("rsid", value.ToString());
			}
		}

		public int rpos
		{
			set
			{
				AddQueryStringParameter("rpos", value.ToString());
			}
		}

		public bool fromSave
		{
			set
			{
				AddQueryStringParameter("fromSave", value.ToString());
			}
		}

		public biz_teams_edit_aspx()
			: base(url)
		{
		}
		public biz_teams_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_systemcustomization_systemcustomization_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/systemcustomization/systemcustomization.aspx";

		public int pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString());
			}
		}

		public string siteMapPath
		{
			set
			{
				AddQueryStringParameter("siteappath", value);
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public tools_systemcustomization_systemcustomization_aspx()
			: base(url)
		{
		}
		public tools_systemcustomization_systemcustomization_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_systemcustomization_solutionsmarketplace_solutionsmarketplace_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/systemcustomization/solutionsmarketplace/solutionsmarketplace.aspx";

		public tools_systemcustomization_solutionsmarketplace_solutionsmarketplace_aspx()
			: base(url)
		{
		}
		public tools_systemcustomization_solutionsmarketplace_solutionsmarketplace_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class WebResources_solution_main_system_library_js : CrmRequest
	{
		// server URL
		public const string url = "/WebResources/Solution_main_system_library.js";

		public string ver
		{
			set
			{
				AddQueryStringParameter("ver", value.ToString());
			}
		}

		public WebResources_solution_main_system_library_js()
			: base(url)
		{
		}
		public WebResources_solution_main_system_library_js(CRMEntity user)
			: base(url, user)
		{
		}
	}


	[Serializable]
	public class tools_Solution_home_solution_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/Solution/home_solution.aspx";

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public tools_Solution_home_solution_aspx()
			: base(url)
		{
		}
		public tools_Solution_home_solution_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_solution_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/solution/edit.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public tools_solution_edit_aspx()
			: base(url)
		{
		}
		public tools_solution_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_systemcustomization_solutionmarketplace_solutioninformation_aspx : CrmRequest
	{
		// server URL
		public const string url = "/Tools/SystemCustomization/SolutionsMarketplace/SolutionInformation.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public int orglcid
		{
			set
			{
				AddQueryStringParameter("orglcid", value.ToString());
			}
		}

		public string orgname
		{
			set
			{
				AddQueryStringParameter("orgname", value.ToString());
			}
		}

		public int type
		{
			set
			{
				AddQueryStringParameter("type", value.ToString());
			}
		}

		public string typename
		{
			set
			{
				AddQueryStringParameter("typename", value.ToString());
			}
		}

		public int userlcid
		{
			set
			{
				AddQueryStringParameter("userlcid", value.ToString());
			}
		}

		public tools_systemcustomization_solutionmarketplace_solutioninformation_aspx()
			: base(url)
		{
		}
		public tools_systemcustomization_solutionmarketplace_solutioninformation_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_solution_areas_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/solution/areas.aspx";

		public Guid oId
		{
			set
			{
				AddQueryStringParameter("oId", value.ToString("B"));
			}
		}

		public Guid appSolutionId
		{
			set
			{
				AddQueryStringParameter("appSolutionId", value.ToString("B"));
			}
		}

		public int oType
		{
			set
			{
				AddQueryStringParameter("oType", value.ToString());
			}
		}

		public int componentTypeFilter
		{
			set
			{
				AddQueryStringParameter("componentTypeFilter", value.ToString());
			}
		}

		public int security
		{
			set
			{
				AddQueryStringParameter("security", value.ToString());
			}
		}

		public string tabSet
		{
			set
			{
				AddQueryStringParameter("tabSet", value.ToString());
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value.ToString());
			}
		}


		public tools_solution_areas_aspx()
			: base(url)
		{
		}
		public tools_solution_areas_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_systemcustomization_entities_entitylist_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/systemcustomization/Entities/entityList.aspx";


		public tools_systemcustomization_entities_entitylist_aspx()
			: base(url)
		{
		}
		public tools_systemcustomization_entities_entitylist_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_systemcustomization_entities_manageentity_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/systemcustomization/Entities/manageEntity.aspx";

		public Guid entityId
		{
			set
			{
				AddQueryStringParameter("entityId", value.ToString("B"));
			}
		}

		public Guid appSolutionId
		{
			set
			{
				AddQueryStringParameter("appSolutionId", value.ToString("B"));
			}
		}

		public Guid appSolutionIdForm
		{
			set
			{
				AddFormParameter("appSolutionId", value.ToString("B"));
			}
		}

		public tools_systemcustomization_entities_manageentity_aspx()
			: base(url)
		{
		}
		public tools_systemcustomization_entities_manageentity_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_systemcustomization_attributes_attributelist_aspx : CrmRequest
	{
		// server URL
		public const string url = "/Tools/SystemCustomization/Attributes/attributeList.aspx";

		public Guid entityId
		{
			set
			{
				AddQueryStringParameter("entityId", value.ToString("B"));
			}
		}

		public Guid appSolutionId
		{
			set
			{
				AddQueryStringParameter("appSolutionId", value.ToString("B"));
			}
		}

		public tools_systemcustomization_attributes_attributelist_aspx()
			: base(url)
		{
		}
		public tools_systemcustomization_attributes_attributelist_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_systemcustomization_attributes_manageattribute_aspx : CrmRequest
	{
		// server URL
		public const string url = "/Tools/SystemCustomization/Attributes/manageAttribute.aspx";

		public Guid entityId
		{
			set
			{
				AddQueryStringParameter("entityId", value.ToString("B"));
			}
		}

		public Guid appSolutionId
		{
			set
			{
				AddQueryStringParameter("appSolutionId", value.ToString("B"));
			}
		}

		public tools_systemcustomization_attributes_manageattribute_aspx()
			: base(url)
		{
		}
		public tools_systemcustomization_attributes_manageattribute_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_relationshiprolemanager_home_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/relationshiprolemanager/home.aspx";

		public tools_relationshiprolemanager_home_aspx()
			: base(url)
		{
		}
		public tools_relationshiprolemanager_home_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_relationshiproleeditor_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/relationshiproleeditor/edit.aspx";

		public Guid entityId
		{
			set
			{
				AddQueryStringParameter("entityId", value.ToString("B"));
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public tools_relationshiproleeditor_edit_aspx()
			: base(url)
		{
		}
		public tools_relationshiproleeditor_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class biz_business_edit_aspx : CrmRequest
	{
		// server URL
		public const string url = "/biz/business/edit.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		// formbody parameters
		public string crmFormSubmitXml
		{
			set
			{
				AddFormParameter("crmFormSubmitXml", value);
			}
		}

		public int crmFormSubmitMode
		{
			set
			{
				AddFormParameter("crmFormSubmitMode", value.ToString());
			}
		}

		public Guid crmFormSubmitId
		{
			set
			{
				AddFormParameter("crmFormSubmitId", value.ToString("B"));
			}
		}

		public bool crmFormUserModified
		{
			set
			{
				AddFormParameter("crmFormUserModified", value.ToString());
			}
		}

		public int crmFormSubmitObjectType
		{
			set
			{
				AddFormParameter("crmFormSubmitObjectType", value.ToString());
			}
		}

		public int crmFormSubmitSecurity
		{
			set
			{
				AddFormParameter("crmFormSubmitSecurity", value.ToString());
			}
		}

		public int crmFormSubmitOnline
		{
			set
			{
				AddFormParameter("crmFormSubmitOnline", value.ToString());
			}
		}


		public string CRMWRPCToken
		{
			set
			{
				AddFormParameter("CRMWRPCToken", value);
			}
		}

		public long CRMWRPCTokenTimeStamp
		{
			set
			{
				AddFormParameter("CRMWRPCTokenTimeStamp", value.ToString());
			}
		}

		public biz_business_edit_aspx()
			: base(url)
		{
		}
		public biz_business_edit_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_business_home_biz_aspx : CrmRequest
	{
		// server URL
		public const string url = "/tools/business/home_biz.aspx";

		public tools_business_home_biz_aspx()
			: base(url)
		{
		}
		public tools_business_home_biz_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _forms_controls_form_css_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_forms/controls/form.css.aspx";

		public int lcid
		{
			set
			{
				AddQueryStringParameter("lcid", value.ToString());
			}
		}

		public _forms_controls_form_css_aspx()
			: base(url)
		{
		}
		public _forms_controls_form_css_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _forms_contols_controls_css_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_forms/controls/controls.css.aspx";

		public _forms_contols_controls_css_aspx()
			: base(url)
		{
		}

		public _forms_contols_controls_css_aspx(string crmServer)
			: base(url)
		{
			this.Url = crmServer + this.Url;
			this.ParseDependentRequests = false;
			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
		}

		public _forms_contols_controls_css_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _common_styles_dialogs_css_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_common/styles/dialogs.css.aspx";

		public int lcid
		{
			set
			{
				AddQueryStringParameter("lcid", value.ToString());
			}
		}

		public _common_styles_dialogs_css_aspx()
			: base(url)
		{
		}
		public _common_styles_dialogs_css_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _controls_lookup_lookupdialogs_css_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_controls/lookup/lookupdialogs.css.aspx";

		public int lcid
		{
			set
			{
				AddQueryStringParameter("lcid", value.ToString());
			}
		}

		public _controls_lookup_lookupdialogs_css_aspx()
			: base(url)
		{
		}
		public _controls_lookup_lookupdialogs_css_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_assign_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_assign.aspx";

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public string routeCode
		{
			set
			{
				AddQueryStringParameter("routeCode", value.ToString());
			}
		}



		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}

		public _grid_cmds_dlg_assign_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_assign_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_copyto_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_copyto.aspx";

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}

		public Guid itemObjectId
		{
			set
			{
				AddQueryStringParameter("itemObjectId", value.ToString("B"));
			}
		}

		public int itemObjectTypeCode
		{
			set
			{
				AddQueryStringParameter("itemObjectTypeCode", value.ToString());
			}
		}

		public _grid_cmds_dlg_copyto_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_copyto_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_share_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_share.aspx";

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}

		public string action
		{
			set
			{
				AddQueryStringParameter("action", value);
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public _grid_cmds_dlg_share_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_share_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_listcaassociation_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_listcaassociation.aspx";

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}

		public string action
		{
			set
			{
				AddQueryStringParameter("action", value);
			}
		}

		public _grid_cmds_dlg_listcaassociation_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_listcaassociation_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_listfax_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_listfax.aspx";

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public bool SendEmail
		{
			set
			{
				AddQueryStringParameter("SendEmail", value.ToString());
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}

		public string action
		{
			set
			{
				AddQueryStringParameter("action", value);
			}
		}

		public int OwnerOption
		{
			set
			{
				AddQueryStringParameter("OwnerOption", value.ToString());
			}
		}

		public _grid_cmds_dlg_listfax_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_listfax_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_getshareaccess_xsl : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/getshareaccess.xsl";

		public _grid_cmds_getshareaccess_xsl(string serverBaseUrl)
			: base(url)
		{
			this.Url = Utils.UrlPathCombine(serverBaseUrl, this.Url);
			this.ParseDependentRequests = false;
			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_changeorg_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_changeorg.aspx";

		//QueryString Parameters

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}


		public _grid_cmds_dlg_changeorg_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_changeorg_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_queueitemrelease_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_queueitemrelease.aspx";

		// Query String Parameters

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid queueId
		{
			set
			{
				AddQueryStringParameter("queueId", value.ToString("B"));
			}
		}

		public int isworkerme
		{
			set
			{
				AddQueryStringParameter("isworkerme", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}


		public _grid_cmds_dlg_queueitemrelease_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_queueitemrelease_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_queueitemworkon_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_queueitemworkon.aspx";

		// Query String Parameters

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid queueId
		{
			set
			{
				AddQueryStringParameter("queueId", value.ToString("B"));
			}
		}

		public int isworkerme
		{
			set
			{
				AddQueryStringParameter("isworkerme", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}


		public _grid_cmds_dlg_queueitemworkon_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_queueitemworkon_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_queueitemremove_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_queueitemremove.aspx";

		// Query String Parameters

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid queueId
		{
			set
			{
				AddQueryStringParameter("queueId", value.ToString("B"));
			}
		}


		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}


		public _grid_cmds_dlg_queueitemremove_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_queueitemremove_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_queueitemroute_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_queueitemroute.aspx";

		// Query String Parameters

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public bool keepexistinguser
		{
			set
			{
				AddQueryStringParameter("keepexistinguser", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid queueId
		{
			set
			{
				AddQueryStringParameter("queueId", value.ToString("B"));
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}


		public _grid_cmds_dlg_queueitemroute_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_queueitemroute_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_addtolist_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_addtolist.aspx";

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}

		public string action
		{
			set
			{
				AddQueryStringParameter("action", value);
			}
		}

		public int autoTrigger
		{
			set
			{
				AddQueryStringParameter("autoTrigger", value.ToString());
			}
		}

		public Guid itemObjectId
		{
			set
			{
				AddQueryStringParameter("itemObjectId", value.ToString("B"));
			}
		}

		public int itemObjectTypeCode
		{
			set
			{
				AddQueryStringParameter("itemObjectTypeCode", value.ToString());
			}
		}

		public _grid_cmds_dlg_addtolist_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_addtolist_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_addtocampaign_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_addtocampaign.aspx";

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}

		public string action
		{
			set
			{
				AddQueryStringParameter("action", value);
			}
		}

		public int autoTrigger
		{
			set
			{
				AddQueryStringParameter("autoTrigger", value.ToString());
			}
		}

		public Guid itemObjectId
		{
			set
			{
				AddQueryStringParameter("itemObjectId", value.ToString("B"));
			}
		}

		public string subtype
		{
			set
			{
				AddQueryStringParameter("subtype", value);
			}
		}

		public int itemObjectTypeCode
		{
			set
			{
				AddQueryStringParameter("itemObjectTypeCode", value.ToString());
			}
		}

		public _grid_cmds_dlg_addtocampaign_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_addtocampaign_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_addtoqueue_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_addtoqueue.aspx";

		public Guid pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString("B"));
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public int iObjType
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public string sIds
		{
			set
			{
				AddQueryStringParameter("sIds", value);
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid queueId
		{
			set
			{
				AddQueryStringParameter("queueId", value.ToString("B"));
			}
		}

		public Guid ownerId
		{
			set
			{
				AddQueryStringParameter("ownerId", value.ToString("B"));
			}
		}

		public int ownerType
		{
			set
			{
				AddQueryStringParameter("ownerType", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}

		public string action
		{
			set
			{
				AddQueryStringParameter("action", value);
			}
		}

		public int autoTrigger
		{
			set
			{
				AddQueryStringParameter("autoTrigger", value.ToString());
			}
		}

		public Guid itemObjectId
		{
			set
			{
				AddQueryStringParameter("itemObjectId", value.ToString("B"));
			}
		}

		public int itemObjectTypeCode
		{
			set
			{
				AddQueryStringParameter("itemObjectTypeCode", value.ToString());
			}
		}

		public _grid_cmds_dlg_addtoqueue_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_addtoqueue_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class CRMReports_home_reports_aspx : CrmRequest
	{
		// server URL
		private const string url = "/CRMReports/home_reports.aspx";

		//QueryStringParameters

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public CRMReports_home_reports_aspx()
			: base(url)
		{
		}
		public CRMReports_home_reports_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class Reserved_ReportViewerWebControl_axd : CrmRequest
	{
		private const string url = "";

		public Reserved_ReportViewerWebControl_axd()
			: base(url)
		{
		}
		public Reserved_ReportViewerWebControl_axd(CRMEntity user)
			: base(url, user)
		{
		}

		public Reserved_ReportViewerWebControl_axd(string crmServer)
			: base(url)
		{
			this.Url = crmServer + this.Url;
			this.ParseDependentRequests = false;
			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}
	}

	[Serializable]
	public class CRMReports_rsviewer_reportviewer_aspx : CrmRequest
	{
		// server URL
		private const string url = "/CRMReports/rsviewer/QuirksReportViewer.aspx";

		public string __EVENTTARGET
		{
			set
			{
				AddFormParameter("__EVENTTARGET", value);
			}
		}

		public string __EVENTARGUMENT
		{
			set
			{
				AddFormParameter("__EVENTARGUMENT", value);
			}
		}

		public string __VIEWSTATE
		{
			set
			{
				AddFormParameter("__VIEWSTATE", value);
			}
		}

		public string __EVENTVALIDATION
		{
			set
			{
				AddFormParameter("__EVENTVALIDATION", value);
			}
		}

		public string uniquename
		{
			set
			{
				AddFormParameter("uniquename", value);
			}
		}

		public string reportnameonsrs
		{
			set
			{
				AddFormParameter("reportnameonsrs", value);
			}
		}

		public Guid id
		{
			set
			{
				AddFormParameter("id", value.ToString("B"));
			}
		}

		public bool isScheduledReport
		{
			set
			{
				AddFormParameter("isScheduledReport", value.ToString());
			}
		}

		public bool iscustomreport
		{
			set
			{
				AddFormParameter("iscustomreport", value.ToString());
			}
		}

		public string CRM_filter
		{
			set
			{
				AddFormParameter("CRM_filter", value);
			}
		}

		public string CRM_filterText
		{
			set
			{
				AddFormParameter("CRM_filterText", value);
			}
		}

		public string reportName
		{
			set
			{
				AddFormParameter("reportName", value);
			}
		}

		public CRMReports_rsviewer_reportviewer_aspx(CRMEntity user)
			: base(url)
		{
			this.Url = Utils.UrlPathCombine(user["OrganizationBaseUrl"], url);
			this.ParseDependentRequests = false;
			if (ConfigSettings.Default.ParseDependentRequests != null)
			{
				try
				{
					this.ParseDependentRequests = bool.Parse(ConfigSettings.Default.ParseDependentRequests);
				}
				catch (Exception e)
				{
					System.Diagnostics.Debug.WriteLine(e.ToString());
				}
			}
			this.ValidateResponse += new EventHandler<ValidationEventArgs>(CrmRequest_ValidateResponse);
		}

	}

	[Serializable]
	public class crmreports_viewer_viewer_aspx : CrmRequest
	{
		// server URL
		public const string url = "/CrmReports/Viewer/viewer.aspx";

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public string helpId
		{
			set
			{
				AddQueryStringParameter("helpid", value.ToString());
			}
		}

		public string action
		{
			set
			{
				AddQueryStringParameter("action", value.ToString());
			}
		}



		public crmreports_viewer_viewer_aspx()
			: base(url)
		{
		}
		public crmreports_viewer_viewer_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _user_summary_report : SqlRequest
	{
		// server URL
		private const string url = "/ReportServer/Pages/ReportViewer.aspx";

		// querystring parameters

		public string UserSummary
		{
			set
			{
				AddQueryStringParameter("", value.ToString());

			}
		}

		public string CRM_FilteredSystemUser
		{
			set
			{
				AddFormParameter("CRM_FilteredSystemUser", value.ToString());
			}
		}

		public string CRM_FilterText
		{
			set
			{
				AddFormParameter("CRM_FilterText", value.ToString());
			}
		}

		public string rsFormat
		{
			set
			{
				AddQueryStringParameter("rs:Format", value.ToString());
			}

		}
		public string rcToolbar
		{
			set
			{
				AddFormParameter("rc:Toolbar", value.ToString());
			}
		}

		public string rcLinkTarget
		{
			set
			{
				AddFormParameter("rc:LinkTarget", value.ToString());
			}
		}

		public string rcReplacementRoot
		{
			set
			{
				AddFormParameter("rc:ReplacementRoot", value.ToString());
			}
		}

		public string rcStylesheet
		{
			set
			{
				AddFormParameter("rc:Stylesheet", value.ToString());
			}
		}

		public string rcJavaScript
		{
			set
			{
				AddQueryStringParameter("rc:JavaScript", value.ToString());
			}
		}

		public string rcArea
		{
			set
			{
				AddQueryStringParameter("rc:Area", value.ToString());
			}
		}
		public _user_summary_report()
			: base(url)
		{
		}

	}

	[Serializable]
	public class _sales_history_report : SqlRequest
	{
		// server URL
		private const string url = "/ReportServer/Pages/ReportViewer.aspx";

		// querystring parameters

		public string SalesHistory
		{
			set
			{
				AddQueryStringParameter("", value.ToString());

			}
		}

		public string rsFormat
		{
			set
			{
				AddQueryStringParameter("rs:Format", value.ToString());
			}

		}

		public string rcToolbar
		{
			set
			{
				AddFormParameter("rc:Toolbar", value);
			}
		}

		public string rcLinkTarget
		{
			set
			{
				AddFormParameter("rc:LinkTarget", value);
			}
		}

		public string rcReplacementRoot
		{
			set
			{
				AddFormParameter("rc:ReplacementRoot", value);
			}
		}

		public string rcStylesheet
		{
			set
			{
				AddFormParameter("rc:Stylesheet", value);
			}
		}

		public string CRMURL
		{
			set
			{
				AddFormParameter("CRM_URL", value);
			}
		}

		public string rcJavaScript
		{
			set
			{
				AddQueryStringParameter("rc:JavaScript", value.ToString());
			}
		}

		public string rcArea
		{
			set
			{
				AddQueryStringParameter("rc:Area", value.ToString());
			}
		}



		public string CRMFilterText
		{
			set
			{
				AddFormParameter("CRM_FilterText", value);
			}
		}

		public string CRMFilterOpp
		{
			set
			{
				AddFormParameter("CRM_FilteredOpportunity", value);
			}
		}

		public string CRMFullName
		{
			set
			{
				AddQueryStringParameter("CRM_FullName", value);
			}
		}

		public string CRMCurrency
		{
			set
			{
				AddQueryStringParameter("CRM_Currency_2", value);
			}
		}

		public string CRMLocate
		{
			set
			{
				AddQueryStringParameter("CRM_Locale", value);
			}
		}

		public _sales_history_report()
			: base(url)
		{
		}

	}

	[Serializable]
	public class _sales_pipeline_report : SqlRequest
	{
		// server URL
		private const string url = "/ReportServer/Pages/ReportViewer.aspx";

		// querystring parameters

		public string SalesHistory
		{
			set
			{
				AddQueryStringParameter("", value.ToString());

			}
		}


		public string rsFormat
		{
			set
			{
				AddQueryStringParameter("rs:Format", value.ToString());
			}

		}

		public string rcToolbar
		{
			set
			{
				AddFormParameter("rc:Toolbar", value);
			}
		}

		public string rcLinkTarget
		{
			set
			{
				AddFormParameter("rc:LinkTarget", value);
			}
		}

		public string rcReplacementRoot
		{
			set
			{
				AddFormParameter("rc:ReplacementRoot", value);
			}
		}

		public string rcStylesheet
		{
			set
			{
				AddFormParameter("rc:Stylesheet", value);
			}
		}

		public string CRMURL
		{
			set
			{
				AddFormParameter("CRM_URL", value);
			}
		}

		public string rcJavaScript
		{
			set
			{
				AddQueryStringParameter("rc:JavaScript", value.ToString());
			}
		}

		public string rcArea
		{
			set
			{
				AddQueryStringParameter("rc:Area", value.ToString());
			}
		}

		public string CRMFilterText
		{
			set
			{
				AddFormParameter("CRM_FilterText", value);
			}
		}

		public string CRMFilterOpp
		{
			set
			{
				AddFormParameter("CRM_FilteredOpportunity", value);
			}
		}

		public string CRMFormatDate
		{
			set
			{
				AddQueryStringParameter("CRM_FormatDate", value);
			}
		}
		public string CRMFormatTime
		{
			set
			{
				AddQueryStringParameter("CRM_FormatTime", value);
			}
		}
		public string CRMNotSpecified
		{
			set
			{
				AddQueryStringParameter("CRM_NotSpecified", value);
			}
		}
		public string CRMSortField
		{
			set
			{
				AddQueryStringParameter("CRM_SortField", value);
			}
		}
		public string GroupBySales
		{
			set
			{
				AddQueryStringParameter("GroupBySales", value);
			}
		}
		public string GroupBy
		{
			set
			{
				AddQueryStringParameter("GroupBy", value);
			}
		}
		public string SelectRevenue
		{
			set
			{
				AddQueryStringParameter("SelectRevenue", value);
			}
		}
		public string CRMShowAll
		{
			set
			{
				AddQueryStringParameter("CRM_ShowAll:isnull", value);
			}
		}
		public string CRMStage
		{
			set
			{
				AddQueryStringParameter("CRM_Stage:isnull", value);
			}
		}
		public string CRMSalesProcess
		{
			set
			{
				AddQueryStringParameter("CRM_SalesProcess:isnull", value);
			}
		}
		public string CRMFilteredOppProduct
		{
			set
			{
				AddQueryStringParameter("CRM_xxxfilteredopportunityproduct", value);
			}
		}
		public string CRMSortDirections
		{
			set
			{
				AddQueryStringParameter("CRM_SortDirection", value);
			}
		}
		public string CRMFullName
		{
			set
			{
				AddQueryStringParameter("CRM_FullName", value);
			}
		}

		public string CRMCurrency
		{
			set
			{
				AddQueryStringParameter("CRM_Currency_2", value);
			}
		}

		public string CRMLocate
		{
			set
			{
				AddQueryStringParameter("CRM_Locale", value);
			}
		}

		public _sales_pipeline_report()
			: base(url)
		{
		}

	}

	[Serializable]
	public class _campaign_activity_status_report : SqlRequest
	{
		// server URL
		private const string url = "/ReportServer/Pages/ReportViewer.aspx";

		// querystring parameters

		public string CampaignActivityStatus
		{
			set
			{
				AddQueryStringParameter("", value.ToString());

			}
		}


		public string rsFormat
		{
			set
			{
				AddQueryStringParameter("rs:Format", value.ToString());
			}

		}

		public string rcToolbar
		{
			set
			{
				AddFormParameter("rc:Toolbar", value);
			}
		}

		public string rcLinkTarget
		{
			set
			{
				AddFormParameter("rc:LinkTarget", value);
			}
		}

		public string rcReplacementRoot
		{
			set
			{
				AddFormParameter("rc:ReplacementRoot", value);
			}
		}

		public string rcStylesheet
		{
			set
			{
				AddFormParameter("rc:Stylesheet", value);
			}
		}

		public string CRMURL
		{
			set
			{
				AddFormParameter("CRM_URL", value);
			}
		}

		public string rcJavaScript
		{
			set
			{
				AddQueryStringParameter("rc:JavaScript", value.ToString());
			}
		}

		public string rcArea
		{
			set
			{
				AddQueryStringParameter("rc:Area", value.ToString());
			}
		}

		public string CRMFilterText
		{
			set
			{
				AddFormParameter("CRM_FilterText", value);
			}
		}

		public string CRMFilterCamp
		{
			set
			{
				AddQueryStringParameter("CRM_FilteredCampaignActivity", value);
			}
		}


		public _campaign_activity_status_report()
			: base(url)
		{
		}

	}

	[Serializable]
	public class tools_bulkimport_importwizard_aspx : CrmRequest
	{
		// server URL
		private const string url = "/Tools/BulkImport/ImportWizard.aspx";

		public tools_bulkimport_importwizard_aspx()
			: base(url)
		{
		}
		public tools_bulkimport_importwizard_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_bulkimport_importfilechoose_aspx : CrmRequest
	{
		// server URL
		private const string url = "/Tools/BulkImport/ImportFileChoose.aspx";

		public tools_bulkimport_importfilechoose_aspx()
			: base(url)
		{
		}
		public tools_bulkimport_importfilechoose_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class tools_bulkimport_importfieldmap_aspx : CrmRequest
	{
		// server URL
		public const string url = "/Tools/BulkImport/importFieldMap.aspx";

		public string action
		{
			set
			{
				AddQueryStringParameter("action", value);
			}
		}

		public int EntityType
		{
			set
			{
				AddQueryStringParameter("EntityType", value.ToString());
			}
		}

		public Guid BulkImportId
		{
			set
			{
				AddQueryStringParameter("BulkImportId", value.ToString("B"));
			}
		}

		public Guid ObjectId
		{
			set
			{
				AddQueryStringParameter("ObjectId", value.ToString("B"));
			}
		}

		public int ObjectTypeCode
		{
			set
			{
				AddQueryStringParameter("ObjectTypeCode", value.ToString());
			}
		}

		public tools_bulkimport_importfieldmap_aspx()
			: base(url)
		{
		}
		public tools_bulkimport_importfieldmap_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}


	[Serializable]
	public class Inpage_help_proxy_aspx : CrmRequest
	{
		// server URL
		private const string url = "/Tools/InPageHelpProxy/InPageHelpProxy.aspx";

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value);
			}
		}

		public Inpage_help_proxy_aspx()
			: base(url)
		{
		}

		public Inpage_help_proxy_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}


	[Serializable]
	public class home_HomepageLive_ttv_home_aspx : CrmRequest
	{
		// server URL
		private const string url = "/Home/Homepage/TTV_Home.aspx";

		public string sitemappath
		{
			set
			{
				AddQueryStringParameter("sitemappath", value.ToString());
			}
		}

		public home_HomepageLive_ttv_home_aspx()
			: base(url)
		{
		}
		public home_HomepageLive_ttv_home_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class portal_orgpicker_aspx : CrmRequest
	{
		private const string url = "/portal/orgpicker.aspx";
		public portal_orgpicker_aspx()
			: base(url)
		{
			this.Url = "https://signin.crm.crmliveperf.com/portal/orgpicker.aspx";
		}

		public portal_orgpicker_aspx(CRMEntity user)
			: base(url, user)
		{
			this.Url = "https://signin.crm.crmliveperf.com/portal/orgpicker.aspx";
		}
	}

	[Serializable]
	public class _cs_cases_dlg_closecase_aspx : CrmRequest
	{
		// server URL
		public const string url = "/CS/cases/dlg_closecase.aspx";

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}
		public string pId
		{
			set
			{
				AddQueryStringParameter("pId", value.ToString(), false);
			}
		}

		public int pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}
		public _cs_cases_dlg_closecase_aspx()
			: base(url)
		{
		}
		public _cs_cases_dlg_closecase_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class xrmservices_IncidentResolution : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string m_regardingObjectId = "";


		public xrmservices_IncidentResolution()
			: base(url)
		{
		}

		public xrmservices_IncidentResolution(CRMEntity user, String recordId)
			: base(url, user)
		{

			m_regardingObjectId = recordId;
		}



		public string RegardingObjectId
		{
			get
			{
				return m_regardingObjectId;
			}
			set
			{
				m_regardingObjectId = value;
			}
		}



		public void getIncidenResolutionBody()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();

			// Envelope body
			string envelope =
			@"<soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
						<soap:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:OrganizationRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);

			// record id and regarding id logical name

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>IncidentResolution</b:key><b:value i:type=\"a:Entity\"><a:Attributes xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"><a:KeyValuePairOfstringanyType><b:key>incidentid</b:key><b:value i:type=\"a:EntityReference\"><a:Id>");
			sbParams.Append(m_regardingObjectId);
			sbParams.Append("</a:Id><a:LogicalName>");
			sbParams.Append("incident");
			sbParams.Append("</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>timespent</b:key><b:value i:type=\"c:int\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append("0");
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>description</b:key><b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append("");
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>subject</b:key><b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append("d");
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType></a:Attributes><a:EntityState i:nil=\"true\"/><a:FormattedValues xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"/><a:LogicalName>incidentresolution</a:LogicalName><a:RelatedEntities xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"></a:RelatedEntities></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>Status</b:key><b:value i:type=\"a:OptionSetValue\"><a:Value>5</a:Value></b:value></a:KeyValuePairOfstringanyType></a:Parameters>");

			// append request id
			sbParams.Append("<a:RequestId i:nil=\"true\"/><a:RequestName>CloseIncident</a:RequestName></request>");

			// append execute and ending
			sbParams.Append("</Execute></soap:Body></soap:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();

			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);

		}
	}

	[Serializable]
	public class xrmservices_activityfeed : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private int m_recordWallPageSize = 10; // default record wall page size
		private int m_personalWallPageSize = 20;
		private int m_pageNum = 1; // defaulting to first page (newest record)
		private int m_commentPerPost = 2;
		private string m_regardingObjectId = "";
		private string m_regardingObjectLogicalName = "";
		private string m_postString = "";
		private string m_commentString = "";


		public xrmservices_activityfeed()
			: base(url)
		{
		}

		public xrmservices_activityfeed(CRMEntity user, String entityName, String recordId)
			: base(url, user)
		{
			m_regardingObjectLogicalName = entityName;
			m_regardingObjectId = recordId;
		}

		public int PageNumber
		{
			get
			{
				return m_pageNum;
			}
			set
			{
				m_pageNum = value;
			}
		}

		public int RecordWallPageSize
		{
			get
			{
				return m_recordWallPageSize;
			}
			set
			{
				m_recordWallPageSize = value;
			}
		}

		public int PersonalWallPageSize
		{
			get
			{
				return m_personalWallPageSize;
			}
			set
			{
				m_personalWallPageSize = value;
			}
		}


		public string RegardingObjectId
		{
			get
			{
				return m_regardingObjectId;
			}
			set
			{
				m_regardingObjectId = value;
			}
		}

		public string PostString
		{
			get
			{
				return m_postString;
			}
			set
			{
				m_postString = value;
			}
		}

		public string CommentString
		{
			get
			{
				return m_commentString;
			}
			set
			{
				m_commentString = value;
			}
		}

		public string RegardingObjectLogicalName
		{
			get
			{
				return m_regardingObjectLogicalName;
			}
			set
			{
				m_regardingObjectLogicalName = value;
			}
		}


		public int CommentPerPost
		{
			get
			{
				return m_commentPerPost;
			}
			set
			{
				m_commentPerPost = value;
			}
		}

		public void getRetriveRecordWallBody()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();

			// Envelope body
			string envelope =
			@"<soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
						<soap:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:OrganizationRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);

			// record id and regarding id logical name

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>Entity</b:key><b:value i:type=\"a:EntityReference\"><a:Id>");
			sbParams.Append(m_regardingObjectId);
			sbParams.Append("</a:Id><a:LogicalName>");
			sbParams.Append(m_regardingObjectLogicalName);
			sbParams.Append("</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>PageNumber</b:key><b:value i:type=\"d:int\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append(m_pageNum.ToString());
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>PageSize</b:key><b:value i:type=\"d:int\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append(m_recordWallPageSize.ToString());
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>CommentsPerPost</b:key><b:value i:type=\"d:int\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append(m_commentPerPost.ToString());
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType></a:Parameters>");

			// append request id
			sbParams.Append("<a:RequestId i:nil=\"true\"/><a:RequestName>RetrieveRecordWall</a:RequestName></request>");

			// append execute and ending
			sbParams.Append("</Execute></soap:Body></soap:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();

			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);

		}

		public void getCreatePostOnRecordWallBody()
		{
			StringBuilder sbParams = new StringBuilder();

			string envelope =
			@"<soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
						<soap:Body><Create xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><entity xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>text</b:key><b:value i:type=""c:string"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">";

			sbParams.Append(envelope);
			sbParams.Append(m_postString);
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>source</b:key><b:value i:type=\"a:OptionSetValue\" ><a:Value>2</a:Value></b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>regardingobjectid</b:key><b:value i:type=\"a:EntityReference\" ><a:Id>");
			sbParams.Append(m_regardingObjectId);
			sbParams.Append("</a:Id><a:LogicalName>");
			sbParams.Append(m_regardingObjectLogicalName);
			sbParams.Append("</a:LogicalName></b:value></a:KeyValuePairOfstringanyType></a:Attributes>");
			// append req id
			sbParams.Append("<a:EntityState i:nil=\"true\"/><a:FormattedValues xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"/><a:LogicalName>post</a:LogicalName><a:RelatedEntities xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"></a:RelatedEntities></entity>");

			// append execute and ending
			sbParams.Append("</Create></soap:Body></soap:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForCreate = new WebTestRequestHeader();
			addSoapToHeaderForCreate.Name = "SOAPAction";
			addSoapToHeaderForCreate.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Create";
			Headers.Add(addSoapToHeaderForCreate);
		}

		public void getRetrivePersonalWallBody()
		{
			StringBuilder sbParams = new StringBuilder();

			string envelope =
			@"<soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/""> 
						<soap:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:OrganizationRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";
			// xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">

			sbParams.Append(envelope);
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>PageNumber</b:key><b:value i:type=\"d:int\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append(m_pageNum.ToString());
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>PageSize</b:key><b:value i:type=\"d:int\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append(m_personalWallPageSize.ToString());
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>CommentsPerPost</b:key><b:value i:type=\"d:int\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append(m_commentPerPost.ToString());
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType></a:Parameters>");
			sbParams.Append("<a:RequestId i:nil=\"true\"/><a:RequestName>RetrievePersonalWall</a:RequestName></request>");

			// append execute and ending
			sbParams.Append("</Execute></soap:Body></soap:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeader = new WebTestRequestHeader();
			addSoapToHeader.Name = "SOAPAction";
			addSoapToHeader.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeader);

		}

		public void getCreatePostOnPersonalWallBody()
		{
			StringBuilder sbParams = new StringBuilder();

			string envelope =
			@"<soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
						<soap:Body><Create xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><entity xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>text</b:key><b:value i:type=""c:string"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">";

			sbParams.Append(envelope);
			sbParams.Append(m_postString);
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>source</b:key><b:value i:type=\"a:OptionSetValue\" ><a:Value>2</a:Value></b:value></a:KeyValuePairOfstringanyType>");

			// user id
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>regardingobjectid</b:key><b:value i:type=\"a:EntityReference\" ><a:Id>");
			sbParams.Append(m_regardingObjectId);
			sbParams.Append("</a:Id><a:LogicalName>systemuser</a:LogicalName></b:value></a:KeyValuePairOfstringanyType></a:Attributes>");
			sbParams.Append("<a:EntityState i:nil=\"true\"/><a:FormattedValues xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"/><a:LogicalName>post</a:LogicalName><a:RelatedEntities xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"></a:RelatedEntities></entity>");

			// append execute and ending
			sbParams.Append("</Create");
			sbParams.Append(">");
			sbParams.Append("</soap:Body>");
			sbParams.Append("</soap:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForCreate = new WebTestRequestHeader();
			addSoapToHeaderForCreate.Name = "SOAPAction";
			addSoapToHeaderForCreate.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Create";
			Headers.Add(addSoapToHeaderForCreate);

		}

		public void getCreateCommentBody(string postId)
		{
			StringBuilder sbParams = new StringBuilder();
			string envelope =
			@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Body><Create xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><entity xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>postid</b:key><b:value i:type=\"a:EntityReference\" ><a:Id>");
			sbParams.Append(postId);
			sbParams.Append("</a:Id><a:LogicalName>post</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>text</b:key><b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">");
			sbParams.Append(m_commentString); // {94FD1D60-D893-E011-8EB4-00155DB572BE}
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append("</a:Attributes><a:EntityState i:nil=\"true\"/><a:FormattedValues xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"/><a:LogicalName>postcomment</a:LogicalName><a:RelatedEntities xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"></a:RelatedEntities></entity>");

			// append execute and ending
			sbParams.Append("</Create");
			sbParams.Append(">");
			sbParams.Append("</s:Body>");
			sbParams.Append("</s:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;
		}

		public void getSeeAllCommentBody(string postId)
		{

			string seeAllCommentStr = @"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:RetrieveMultipleRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>Query</b:key><b:value i:type=""a:FetchExpression""><a:Query>&lt;fetch version=""1.0"" output-format=""xml-platform"" mapping=""logical"" distinct=""false""  page='1' returntotalrecordcount='true' &gt;&lt;entity name=""postcomment""&gt;&lt;attribute name=""postcommentid"" /&gt;&lt;attribute name=""text"" /&gt;&lt;attribute name=""createdon"" /&gt;&lt;attribute name=""postid"" /&gt;&lt;attribute name=""createdby"" /&gt;&lt;order attribute=""createdon"" descending=""true"" /&gt;&lt;filter type=""and""&gt;&lt;condition attribute=""postid"" operator=""eq"" value=""" +
				postId + "\" /&gt;&lt;/filter&gt;&lt;/entity&gt;&lt;/fetch&gt;</a:Query></b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil=\"true\"/><a:RequestName>RetrieveMultiple</a:RequestName></request></Execute></s:Body></s:Envelope>";

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = seeAllCommentStr;
			Body = reqBod;
		}

		public WebTestRequestHeader getRetrieveSystemUser(string userId)
		{

			string getRetrieveMultipleRequestStr = @"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:RetrieveMultipleRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>Query</b:key><b:value i:type=""a:FetchExpression""><a:Query>&lt;fetch version=""1.0"" output-format=""xml-platform"" mapping=""logical"" distinct=""true""  &gt;&lt;entity name=""systemuser""&gt;&lt;filter type=""or""&gt;&lt;condition attribute=""systemuserid"" operator=""eq"" value=""" +
				userId + "\" /&gt;&lt;/filter&gt; &lt;attribute name=\"systemuserid\"/&gt;&lt;attribute name=\"internalemailaddress\"/&gt;&lt;attribute name=\"personalemailaddress\"/&gt;&lt;attribute name=\"firstname\"/&gt;&lt;attribute name=\"lastname\"/&gt;&lt;attribute name=\"fullname\"/&gt;	 &lt;/entity&gt;&lt;/fetch&gt;</a:Query></b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil=\"true\"/><a:RequestName>RetrieveMultiple</a:RequestName></request></Execute></s:Body></s:Envelope>";

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = getRetrieveMultipleRequestStr;
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForExecute = new WebTestRequestHeader();
			addSoapToHeaderForExecute.Name = "SOAPAction";
			addSoapToHeaderForExecute.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			return addSoapToHeaderForExecute;

		}

		public WebTestRequestHeader getRetrieveUserSettings()
		{

			string getRetrieveMultipleRequestStr = @"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:RetrieveMultipleRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>Query</b:key><b:value i:type=""a:FetchExpression""><a:Query>&lt;fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'&gt;&lt;entity name='msdyn_wallsavedqueryusersettings'&gt;&lt;attribute name='msdyn_wallsavedqueryusersettingsid' /&gt;&lt;attribute name='msdyn_wallsavedqueryid' /&gt;&lt;attribute name='msdyn_savedqueryname' /&gt;&lt;attribute name='msdyn_entityname' /&gt;&lt;attribute name='msdyn_otc' /&gt;&lt;attribute name='msdyn_entitydisplayname' /&gt;&lt;attribute name='msdyn_isvisible' /&gt;&lt;attribute name='msdyn_isvirtual' /&gt;&lt;attribute name='msdyn_default' /&gt;&lt;filter type='and'&gt;&lt;condition attribute='msdyn_userid' operator='eq-userid' /&gt;&lt;condition attribute='msdyn_isvirtual' operator='eq' value='1' /&gt;&lt;condition attribute='msdyn_isvisible' operator='eq' value='1' /&gt;&lt;condition attribute='msdyn_isfollowing' operator='eq' value='1' /&gt;&lt;condition attribute='msdyn_includewallinresponse' operator='eq' value='1' /&gt;&lt;/filter&gt;&lt;/entity&gt;&lt;/fetch&gt;</a:Query></b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil=""true""/><a:RequestName>RetrieveMultiple</a:RequestName></request></Execute></s:Body></s:Envelope>";

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = getRetrieveMultipleRequestStr;
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForExecute = new WebTestRequestHeader();
			addSoapToHeaderForExecute.Name = "SOAPAction";
			addSoapToHeaderForExecute.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			return addSoapToHeaderForExecute;

		}

		public WebTestRequestHeader getRetrieveRecordWall(string incidentId, string incidentName)
		{

			string getRetrieveMultipleRequestStr = @"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:OrganizationRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>Entity</b:key><b:value i:type=""a:EntityReference""><a:Id>" + incidentId + "</a:Id><a:LogicalName>incident</a:LogicalName><a:Name>" + incidentName + "</a:Name></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>PageSize</b:key><b:value i:type=\"d:int\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">10</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>PageNumber</b:key><b:value i:type=\"d:int\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">1</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>CommentsPerPost</b:key><b:value i:type=\"d:int\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">2</b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil=\"true\"/><a:RequestName>RetrieveRecordWall</a:RequestName></request></Execute></s:Body></s:Envelope>";

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = getRetrieveMultipleRequestStr;
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForExecute = new WebTestRequestHeader();
			addSoapToHeaderForExecute.Name = "SOAPAction";
			addSoapToHeaderForExecute.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			return addSoapToHeaderForExecute;

		}

		public WebTestRequestHeader getRetrievePostWall(string incidentId)
		{

			string getRetrieveRequestStr = @"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:RetrieveMultipleRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>Query</b:key><b:value i:type=""a:FetchExpression""><a:Query>&#60;fetch version&#61;&#34;1.0&#34; output-format&#61;&#34;xml-platform&#34; mapping&#61;&#34;logical&#34; distinct&#61;&#34;false&#34; &#62;&#60;entity name&#61;&#34;postfollow&#34;&#62;&#60;attribute name&#61;&#34;regardingobjectid&#34; alias&#61;&#34;regardingobjectid&#34;&#47;&#62;&#60;attribute name&#61;&#34;postfollowid&#34; alias&#61;&#34;postfollowid&#34;&#47;&#62;&#60;attribute name&#61;&#34;createdon&#34; alias&#61;&#34;createdon&#34;&#47;&#62;&#60;attribute name&#61;&#34;regardingobjectid&#34; alias&#61;&#34;a50279b8902c4afe8d1f05635fcac03f&#34;&#47;&#62;&#60;link-entity name&#61;&#34;systemuser&#34; from&#61;&#34;systemuserid&#34; to&#61;&#34;ownerid&#34; alias&#61;&#34;systemuser&#34;&#62;&#60;attribute name&#61;&#34;fullname&#34;  alias&#61;&#34;fullname&#34;&#47;&#62;&#60;attribute name&#61;&#34;systemuserid&#34; alias&#61;&#34;systemuserid&#34;&#47;&#62;&#60;&#47;link-entity&#62;&#60;filter type&#61;&#34;and&#34;&#62;&#60;condition attribute&#61;&#34;regardingobjectid&#34; operator&#61;&#34;eq&#34; value&#61;&#34;" + incidentId + "&#34; &#47;&#62;&#60;&#47;filter&#62;&#60;order attribute&#61;&#34;createdon&#34; descending&#61;&#34;true&#34; &#47;&#62;&#60;&#47;entity&#62;&#60;&#47;fetch&#62;</a:Query></b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil=\"true\"/><a:RequestName>RetrieveMultiple</a:RequestName></request></Execute></s:Body></s:Envelope>";

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = getRetrieveRequestStr;
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForExecute = new WebTestRequestHeader();
			addSoapToHeaderForExecute.Name = "SOAPAction";
			addSoapToHeaderForExecute.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			return addSoapToHeaderForExecute;

		}

		public WebTestRequestHeader getRetrieveAnnotation(string userId)
		{

			string getRetrieveRequestStr = @"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:RetrieveMultipleRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>Query</b:key><b:value i:type=""a:FetchExpression""><a:Query>&#60;fetch version&#61;&#39;1.0&#39; output-format&#61;&#39;xml-platform&#39; mapping&#61;&#39;logical&#39; distinct&#61;&#39;true&#39;&#62;&#60;entity name&#61;&#39;annotation&#39;&#62;&#60;order descending&#61;&#39;true&#39; attribute&#61;&#39;createdon&#39; &#47;&#62;&#60;filter type&#61;&#39;and&#39;&#62;&#60;condition attribute&#61;&#39;mimetype&#39; operator&#61;&#39;like&#39; value&#61;&#39;image&#37;&#39;&#47;&#62;&#60;&#47;filter&#62;&#60;attribute name&#61;&#39;annotationid&#39;&#47;&#62;&#60;attribute name&#61;&#39;objectid&#39;&#47;&#62;&#60;link-entity name&#61;&#39;msdyn_postalbum&#39; from&#61;&#39;msdyn_postalbumid&#39; to&#61;&#39;objectid&#39; alias&#61;&#39;album&#39;&#62;&#60;filter type&#61;&#39;and&#39;&#62;&#60;filter type&#61;&#39;or&#39;&#62;&#60;condition attribute&#61;&#39;ownerid&#39; operator&#61;&#39;eq&#39; value&#61;&#39;" + userId + "&#39; &#47;&#62;&#60;condition attribute&#61;&#39;ownerid&#39; operator&#61;&#39;eq&#39; value&#61;&#39;" + userId + "&#39; &#47;&#62;&#60;&#47;filter&#62;&#60;&#47;filter&#62;&#60;attribute name&#61;&#39;owninguser&#39;&#47;&#62;&#60;&#47;link-entity&#62;&#60;&#47;entity&#62;&#60;&#47;fetch&#62;</a:Query></b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil=\"true\"/><a:RequestName>RetrieveMultiple</a:RequestName></request></Execute></s:Body></s:Envelope>";

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = getRetrieveRequestStr;
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForExecute = new WebTestRequestHeader();
			addSoapToHeaderForExecute.Name = "SOAPAction";
			addSoapToHeaderForExecute.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			return addSoapToHeaderForExecute;

		}

		public void FollowRecord()
		{
			StringBuilder sbParams = new StringBuilder();

			string envelope =
			@"<soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
						<soap:Body><Create xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><entity xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);
			sbParams.Append(m_postString);

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>regardingobjectid</b:key><b:value i:type=\"a:EntityReference\" ><a:Id>");
			sbParams.Append(m_regardingObjectId);
			sbParams.Append("</a:Id><a:LogicalName>" + m_regardingObjectLogicalName + "</a:LogicalName></b:value></a:KeyValuePairOfstringanyType></a:Attributes>");
			sbParams.Append("<a:EntityState i:nil=\"true\"/><a:FormattedValues xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"/><a:LogicalName>postfollow</a:LogicalName><a:RelatedEntities xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\"></a:RelatedEntities></entity>");

			// append execute and ending
			sbParams.Append("</Create");
			sbParams.Append(">");
			sbParams.Append("</soap:Body>");
			sbParams.Append("</soap:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForCreate = new WebTestRequestHeader();
			addSoapToHeaderForCreate.Name = "SOAPAction";
			addSoapToHeaderForCreate.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Create";
			Headers.Add(addSoapToHeaderForCreate);
		}
	}

	[Serializable]
	public class RetrieveMultipleQuery : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string _query;



		public RetrieveMultipleQuery()
			: base(url)
		{
		}

		public RetrieveMultipleQuery(CRMEntity user, string query)
			: base(url, user)
		{
			_query = query;
		}



		public void getRetriveMultipleQuery()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();

			// Envelope body
			string envelope =
			@"<soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema""><soap:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services""><request i:type=""a:OrganizationRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);

			// record id and regarding id logical name

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>Query</b:key><b:value i:type=\"a:FetchExpression\"><a:Query>");
			sbParams.Append(_query);
			sbParams.Append("</a:Query>");
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");


			sbParams.Append("</a:Parameters>");

			// append request id
			sbParams.Append("<a:RequestId i:nil=\"true\"/><a:RequestName>RetrieveMultiple</a:RequestName></request>");

			// append execute and ending
			sbParams.Append("</Execute></soap:Body></soap:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();

			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);

		}



	}
	[Serializable]
	public class _forms_read_page_aspx : CrmRequest
	{
		private const string url = "/_forms/read/page.aspx";
		// querystring parameters
		public int lcId
		{
			set
			{
				AddQueryStringParameter("lcid", value.ToString());
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public string pagemode
		{
			set
			{
				AddQueryStringParameter("pagemode", value);
			}
		}

		public string theme
		{
			set
			{
				AddQueryStringParameter("theme", value);
			}

		}

		public Guid orgid
		{
			set
			{
				AddQueryStringParameter("orgid", value.ToString("B"));
			}
		}


		public bool outlook
		{
			set
			{
				AddQueryStringParameter("outlook", value.ToString());
			}
		}

		public string partyid
		{
			set
			{
				AddQueryStringParameter("partyid", value.ToString());
			}
		}
		public string partyname
		{
			set
			{
				AddQueryStringParameter("partyname", value);
			}
		}
		public int partytype
		{
			set
			{
				AddQueryStringParameter("partytype", value.ToString());
			}
		}
		public string regardingobjectid
		{
			set
			{
				AddQueryStringParameter("regardingobjectid", value.ToString());
			}
		}
		public string regardingobjectidname
		{
			set
			{
				AddQueryStringParameter("regardingobjectidname", value);
			}
		}
		public string regardingobjecttypecode
		{
			set
			{
				AddQueryStringParameter("regardingobjecttypecode", value);
			}
		}

		public string customerid
		{
			set
			{
				AddQueryStringParameter("customerid", value);
			}
		}

		public string customeridname
		{
			set
			{
				AddQueryStringParameter("customeridname", value);
			}
		}
		public string customeridtype
		{
			set
			{
				AddQueryStringParameter("customeridtype", value);
			}
		}

		public _forms_read_page_aspx()
			: base(url)
		{
		}
		public _forms_read_page_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _forms_read_grid__aspx : CrmRequest
	{
		private const string url = "/_forms/read/grid.aspx";
		// querystring parameters
		public string GridId
		{
			set
			{
				AddQueryStringParameter("GridId", value);
			}
		}

		public Guid id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public int etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString());
			}
		}

		public string formId
		{
			set
			{
				AddQueryStringParameter("formId", value);
			}
		}


		public _forms_read_grid__aspx()
			: base(url)
		{
		}
		public _forms_read_grid__aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class xrmservices_CreateRequest : CrmRequest
	{
		// server URL

		public const string url = "/XRMServices/2011/Organization.svc";
		private int uii_activityid;
		private string uii_machinename;
		private int uii_clienttimezone;
		private DateTime uii_currenttime;
		private Guid uii_applicationid;
		private bool uii_hostedapplication;
		private string uii_customerid;
		private string uii_audit;

		public xrmservices_CreateRequest()
			: base(url)
		{
		}


		public xrmservices_CreateRequest(int activityid, string machinename, int clienttimezone, DateTime currenttime, Guid applicationid, bool hostedapplication, string customerid, string audit)
			: base(url)
		{
			uii_activityid = activityid;
			uii_machinename = machinename;
			uii_clienttimezone = clienttimezone;
			uii_currenttime = currenttime;
			uii_applicationid = applicationid;
			uii_hostedapplication = hostedapplication;
			uii_customerid = customerid;
			uii_audit = audit;

		}

		public void CreateRequest()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();


			// Envelope body
			string envelope =
			@"<s:Envelope xmlns:s=""http://www.w3.org/2003/05/soap-envelope""><s:Header><SdkClientVersion xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts"">6.1.0000.0542</SdkClientVersion></s:Header><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><request i:type=""b:CreateRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:b=""http://schemas.microsoft.com/crm/2011/Contracts""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>Target</b:key><b:value i:type=\"a:Entity\"><a:Attributes>");
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>");
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>");
			sbParams.Append(uii_activityid);
			sbParams.Append("</b:key><b:value i:type=\"c:int\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">3</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>");
			sbParams.Append(uii_machinename);
			sbParams.Append("</b:key><b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">LOADUSDCLT</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>");
			sbParams.Append(uii_clienttimezone);
			sbParams.Append("</b:key><b:value i:type=\"c:int\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">-25200</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>");
			sbParams.Append(uii_currenttime);
			sbParams.Append("</b:key><b:value i:type=\"c:dateTime\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">2014-07-30T14:25:04.3181133Z</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>");
			sbParams.Append(uii_applicationid);
			sbParams.Append("</b:key><b:value i:type=\"a:EntityReference\"><a:Id>5aa001d8-de30-e311-87f2-00155dd8d60b</a:Id><a:LogicalName>");
			sbParams.Append(uii_hostedapplication);
			sbParams.Append("</a:LogicalName><a:Name i:nil=\"true\"></a:Name></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>");
			sbParams.Append(uii_customerid);
			sbParams.Append("</b:key><b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">52fcac8d-2503-44ae-967c-d6556fc0aedc</b:value></a:KeyValuePairOfstringanyType></a:Attributes><a:EntityState i:nil=\"true\"></a:EntityState><a:FormattedValues></a:FormattedValues><a:Id>00000000-0000-0000-0000-000000000000</a:Id><a:LogicalName>");
			sbParams.Append(uii_audit);
			sbParams.Append("</a:LogicalName><a:RelatedEntities></a:RelatedEntities></b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil=\"true\"></a:RequestId><a:RequestName>Create</a:RequestName></request></Execute></s:Body></s:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();

			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);
		}
	}


	[Serializable]
	public class xrmservices_QualifyLead : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string m_leadId = "";
		private string m_leadLogicalName = "";
		private string m_currencyId = "";

		public xrmservices_QualifyLead()
			: base(url)
		{
		}

		public xrmservices_QualifyLead(CRMEntity user, string leadId, String entityName, String currencyId)
			: base(url, user)
		{
			m_leadId = leadId;
			m_leadLogicalName = entityName;
			m_currencyId = currencyId;
		}


		public void QualifyLead()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();

			// Envelope body
			string envelope =
			@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Header><SdkClientVersion xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts"">6.0.0.0</SdkClientVersion></s:Header><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><request i:type=""b:QualifyLeadRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:b=""http://schemas.microsoft.com/crm/2011/Contracts""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);

			// record id and regarding id logical name
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>LeadId</b:key><b:value i:type=\"a:EntityReference\"><a:Id>");
			sbParams.Append(m_leadId);
			sbParams.Append("</a:Id><a:LogicalName>");
			sbParams.Append(m_leadLogicalName);
			sbParams.Append("</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>CreateAccount</b:key><b:value i:type=\"c:boolean\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">true</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>CreateContact</b:key><b:value i:type=\"c:boolean\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">true</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>CreateOpportunity</b:key><b:value i:type=\"c:boolean\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">true</b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>OpportunityCurrencyId</b:key><b:value i:type=\"a:EntityReference\"><a:Id>");
			sbParams.Append(m_currencyId);
			sbParams.Append("</a:Id><a:LogicalName>lead</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>OpportunityCustomerId</b:key><b:value i:nil=\"true\" /></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>SourceCampaignId</b:key><b:value i:nil=\"true\" /></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>Status</b:key><b:value i:type=\"a:OptionSetValue\"><a:Value>-1</a:Value></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>SuppressDuplicateDetection</b:key><b:value i:type=\"c:boolean\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">true</b:value></a:KeyValuePairOfstringanyType></a:Parameters>");

			// append request id
			sbParams.Append("<a:RequestId i:nil=\"true\"/><a:RequestName>QualifyLead</a:RequestName></request>");

			// append execute and ending
			sbParams.Append("</Execute></s:Body></s:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();

			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);

		}
	}
	[Serializable]
	public class xrmservices_CloseOppasWon : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string opportunityid;

		public xrmservices_CloseOppasWon()
			: base(url)
		{
		}

		public xrmservices_CloseOppasWon(CRMEntity user, string OpportunityID)
			: base(url, user)
		{
			opportunityid = OpportunityID;
		}


		public void CloseOpportunityasWon()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();
			// Envelope body
			string envelope =
			@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Header><SdkClientVersion xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts"">6.0.0.0</SdkClientVersion></s:Header><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><request i:type=""b:WinOpportunityRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:b=""http://schemas.microsoft.com/crm/2011/Contracts""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">
			<a:KeyValuePairOfstringanyType><b:key>OpportunityClose</b:key><b:value i:type=""a:Entity""><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">
			<a:KeyValuePairOfstringanyType><b:key>opportunityid</b:key><b:value i:type=""a:EntityReference""><a:Id>";
			sbParams.Append(envelope);
			sbParams.Append(opportunityid);
			sbParams.Append(@"</a:Id><a:LogicalName>opportunity</a:LogicalName></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType>
			<b:key>actualrevenue</b:key><b:value i:type=""a:Money""><a:Value>0</a:Value></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType>
			<b:key>description</b:key><b:value i:nil=""true"" /></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>actualend</b:key><b:value i:type=""c:dateTime"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">2014-04-01T00:00:00</b:value>
			</a:KeyValuePairOfstringanyType></a:Attributes><a:EntityState i:nil=""true""/><a:FormattedValues xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""/>
			<a:LogicalName>opportunityclose</a:LogicalName><a:RelatedEntities xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:RelatedEntities>
			</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>Status</b:key><b:value i:type=""a:OptionSetValue""><a:Value>3</a:Value>
			</b:value></a:KeyValuePairOfstringanyType></a:Parameters>");
			// append request id
			sbParams.Append(@" <a:RequestId i:nil=""true"" /><a:RequestName>WinOpportunity</a:RequestName></request></Execute></s:Body></s:Envelope>");
			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;
			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);
		}
	}

	[Serializable]
	public class xrmservices_CreateProduct : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string[] productpricelevelid = new string[3];
		private string parentopportunityid;

		public xrmservices_CreateProduct()
			: base(url)
		{
		}

		public xrmservices_CreateProduct(CRMEntity user, string[] colProductPriceLevelId, string ParentOpportunityID)
			: base(url, user)
		{
			int i = 0;
			parentopportunityid = ParentOpportunityID;
			while (i < 3)
			{
				productpricelevelid[i] = colProductPriceLevelId[i];
				i++;
			}
		}


		public void CreateProduct()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();

			// Envelope body
			string envelope =
			@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Header><SdkClientVersion xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts"">6.0.0.0</SdkClientVersion></s:Header><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><request i:type=""b:CreateProductsRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:b=""http://schemas.microsoft.com/crm/2011/Contracts""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>Entities</b:key><b:value i:type=""a:EntityCollection""><a:Entities><a:Entity><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);

			// record id and regarding id logical name
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>productid</b:key><b:value i:type=\"a:EntityReference\"><a:Id>");
			sbParams.Append(productpricelevelid[0]);
			sbParams.Append("</a:Id><a:LogicalName>productpricelevel</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append(@"</a:Attributes><a:EntityState i:nil=""true""/><a:FormattedValues xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""/><a:LogicalName>opportunityproduct</a:LogicalName><a:RelatedEntities xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:RelatedEntities></a:Entity><a:Entity><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>productid</b:key><b:value i:type=""a:EntityReference""><a:Id>");

			sbParams.Append(productpricelevelid[1]);
			sbParams.Append("</a:Id><a:LogicalName>productpricelevel</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append(@"</a:Attributes><a:EntityState i:nil=""true""/><a:FormattedValues xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""/><a:LogicalName>opportunityproduct</a:LogicalName><a:RelatedEntities xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:RelatedEntities></a:Entity><a:Entity><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>productid</b:key><b:value i:type=""a:EntityReference""><a:Id>");
			sbParams.Append(productpricelevelid[2]);
			sbParams.Append("</a:Id><a:LogicalName>productpricelevel</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append(@"</a:Attributes><a:EntityState i:nil=""true""/><a:FormattedValues xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""/><a:LogicalName>opportunityproduct</a:LogicalName><a:RelatedEntities xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:RelatedEntities></a:Entity></a:Entities></b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append(@"<a:KeyValuePairOfstringanyType><b:key>ParentEntity</b:key><b:value i:type=""a:Entity""><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:Attributes><a:EntityState i:nil=""true""/><a:FormattedValues xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""/><a:Id>");
			sbParams.Append(parentopportunityid);
			sbParams.Append(@"</a:Id><a:LogicalName>opportunity</a:LogicalName><a:RelatedEntities xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:RelatedEntities></b:value></a:KeyValuePairOfstringanyType></a:Parameters>");
			// append request id
			sbParams.Append(@"<a:RequestId i:nil=""true"" /><a:RequestName>CreateProducts</a:RequestName></request></Execute></s:Body></s:Envelope>");
			StringHttpBody reqBod = new StringHttpBody();

			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);
		}
	}

	[Serializable]
	public class xrmservices_CreateQuoteProduct : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string[] productpricelevelid = new string[3];
		private string parentquoteid;

		public xrmservices_CreateQuoteProduct()
			: base(url)
		{
		}

		public xrmservices_CreateQuoteProduct(CRMEntity user, string[] colProductPriceLevelId, string ParentquoteID)
			: base(url, user)
		{
			int i = 0;
			parentquoteid = ParentquoteID;
			while (i < colProductPriceLevelId.Length)
			{
				productpricelevelid[i] = colProductPriceLevelId[i];
				i++;
			}
		}

		public void CreateQuoteProduct()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();

			// Envelope body
			string envelope =
			@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Header><SdkClientVersion xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts"">6.0.0.0</SdkClientVersion></s:Header><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><request i:type=""b:CreateProductsRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:b=""http://schemas.microsoft.com/crm/2011/Contracts""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>Entities</b:key><b:value i:type=""a:EntityCollection""><a:Entities><a:Entity><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";
			sbParams.Append(envelope);
			sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>productid</b:key><b:value i:type=\"a:EntityReference\"><a:Id>");
			sbParams.Append(productpricelevelid[0]);
			sbParams.Append("</a:Id><a:LogicalName>productpricelevel</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append(@"</a:Attributes><a:EntityState i:nil=""true""/><a:FormattedValues xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""/><a:LogicalName>quotedetail</a:LogicalName><a:RelatedEntities xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:RelatedEntities></a:Entity></a:Entities></b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append(@"<a:KeyValuePairOfstringanyType><b:key>ParentEntity</b:key><b:value i:type=""a:Entity""><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:Attributes><a:EntityState i:nil=""true""/><a:FormattedValues xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""/><a:Id>");
			sbParams.Append(parentquoteid);
			sbParams.Append(@"</a:Id><a:LogicalName>quote</a:LogicalName><a:RelatedEntities xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:RelatedEntities></b:value></a:KeyValuePairOfstringanyType></a:Parameters>");
			// append request id
			sbParams.Append(@"<a:RequestId i:nil=""true"" /><a:RequestName>CreateProducts</a:RequestName></request></Execute></s:Body></s:Envelope>");
			StringHttpBody reqBod = new StringHttpBody();

			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);
		}

	}

	//Dynaimc Property retreive
	[Serializable]
	public class xrmservices_RetrieveDynamicProperty : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string OppProductID;
		//private string parentopportunityid;

		public xrmservices_RetrieveDynamicProperty()
			: base(url)
		{
		}

		public xrmservices_RetrieveDynamicProperty(CRMEntity user, string OpportunityProdId)
			: base(url, user)
		{
			OppProductID = OpportunityProdId;
		}

		public void RetrieveDynamicProperty()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();
			// Envelope body
			string envelope =
			@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Header><SdkClientVersion xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts""></SdkClientVersion></s:Header><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><request i:type=""b:RetrieveProductPropertiesRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:b=""http://schemas.microsoft.com/crm/2011/Contracts""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""><a:KeyValuePairOfstringanyType><b:key>ParentObject</b:key><b:value i:type=""a:EntityReference""><a:Id>";
			sbParams.Append(envelope);
			sbParams.Append(OppProductID);
			sbParams.Append("</a:Id><a:LogicalName>opportunityproduct</a:LogicalName></b:value></a:KeyValuePairOfstringanyType></a:Parameters>");
			// append request id
			sbParams.Append(@"<a:RequestId i:nil=""true"" /><a:RequestName>RetrieveProductProperties</a:RequestName></request></Execute></s:Body></s:Envelope>");
			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;
			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);
		}
	}

	//Update DynamicProperty Product
	[Serializable]
	public class xrmservices_UpdateProductDynamicProperty : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string dynamicproprtyid;
		private string dynamicpropertyinstanceid;
		private string opportunityproductid;
		private string updatedValue;
		//private string parentopportunityid;

		public xrmservices_UpdateProductDynamicProperty()
			: base(url)
		{
		}

		public xrmservices_UpdateProductDynamicProperty(CRMEntity user, string OpportunityProdId, string DynamicPropertyID, string DynamicPropertyInstanceID, string UpdatedValue)
			: base(url, user)
		{
			dynamicpropertyinstanceid = DynamicPropertyInstanceID;
			dynamicproprtyid = DynamicPropertyID;
			opportunityproductid = OpportunityProdId;
			updatedValue = UpdatedValue;
		}

		public void UpdateProductDynamicProperty(string EntityName)
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();

			// Envelope body
			string envelope =
			@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Header><SdkClientVersion xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts"">6.0.0.0</SdkClientVersion></s:Header><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><request i:type=""b:UpdateProductPropertiesRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:b=""http://schemas.microsoft.com/crm/2011/Contracts""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">
			<a:KeyValuePairOfstringanyType><b:key>PropertyInstanceList</b:key><b:value i:type=""a:EntityCollection""><a:Entities><a:Entity><a:Attributes xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">
			<a:KeyValuePairOfstringanyType><b:key>regardingobjectid</b:key><b:value i:type=""a:EntityReference""><a:Id>";
			sbParams.Append(envelope);
			// record id and regarding id logical name
			//sbParams.Append("<a:KeyValuePairOfstringanyType><b:key>RegardingObject</b:key><b:value i:type=\"a:EntityReference\"><a:Id>");
			sbParams.Append(opportunityproductid);
			sbParams.Append(@"</a:Id><a:LogicalName>" + EntityName.ToLower() + @"</a:LogicalName></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>dynamicpropertyid</b:key>
							<b:value i:type=""a:EntityReference""><a:Id>");
			sbParams.Append(dynamicproprtyid);
			sbParams.Append(@"</a:Id><a:LogicalName>dynamicproperty</a:LogicalName></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType>
							<b:key>dynamicpropertyinstanceid</b:key>
							<b:value i:type=""c:guid"" xmlns:c=""http://schemas.microsoft.com/2003/10/Serialization/"">");
			sbParams.Append(dynamicpropertyinstanceid);
			sbParams.Append(@"</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>valuedecimal</b:key><b:value i:type=""c:decimal"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">");
			sbParams.Append(updatedValue);
			sbParams.Append(@"</b:value></a:KeyValuePairOfstringanyType></a:Attributes><a:EntityState i:nil=""true""/><a:FormattedValues xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""/><a:Id>");
			sbParams.Append(dynamicpropertyinstanceid);
			sbParams.Append(@"</a:Id><a:LogicalName>dynamicpropertyinstance</a:LogicalName><a:RelatedEntities xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic""></a:RelatedEntities></a:Entity>
							</a:Entities></b:value></a:KeyValuePairOfstringanyType></a:Parameters>");
			// append request id
			sbParams.Append(@"<a:RequestId i:nil=""true"" /><a:RequestName>UpdateProductProperties</a:RequestName></request></Execute></s:Body></s:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();
			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;
			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);
		}
	}

	[Serializable]
	public class xrmservices_SharePointQuickFind : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string _regardingObjectTypeCode = "";
		private string _regardingObjectId = "";

		public xrmservices_SharePointQuickFind()
			: base(url)
		{
		}

		public xrmservices_SharePointQuickFind(CRMEntity user, string regardingObjectId, string regardingObjectTypeCode)
			: base(url, user)
		{
			_regardingObjectTypeCode = regardingObjectTypeCode;
			_regardingObjectId = regardingObjectId;
		}


		public void QuickFind()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();

			// Envelope body
			string envelope =
			@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Header><SdkClientVersion xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts"">6.0.0.0</SdkClientVersion></s:Header><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><request i:type=""b:SearchDocumentRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:b=""http://schemas.microsoft.com/crm/2011/Contracts""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);

			// record id and regarding id logical name
			sbParams.Append(@"<a:KeyValuePairOfstringanyType><b:key>RegardingObjectType</b:key><b:value i:type=""c:int"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">");
			sbParams.Append(_regardingObjectTypeCode);
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append(@"<a:KeyValuePairOfstringanyType><b:key>RegardingObjectId</b:key><b:value i:type=""c:string"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">&#123;");
			sbParams.Append(_regardingObjectId);
			sbParams.Append("&#125;</b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append(@"<a:KeyValuePairOfstringanyType><b:key>DocumentId</b:key><b:value i:type=""c:string"" xmlns:c=""http://www.w3.org/2001/XMLSchema""></b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append(@"</a:Parameters><a:RequestId i:nil=""true"" /><a:RequestName>SearchDocument</a:RequestName></request></Execute></s:Body></s:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();

			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);

		}
	}

	[Serializable]
	public class xrmservices_NewDocument : CrmRequest
	{
		// server URL
		public const string url = "/XRMServices/2011/Organization.svc/web";
		private string _filename = "";
		private string _regardingObjectId = "";
		private string _regardingObjectTypeCode = "";

		public xrmservices_NewDocument()
			: base(url)
		{
		}

		public xrmservices_NewDocument(CRMEntity user, string filename, string regardingObjectId, string regardingObjectTypeCode)
			: base(url, user)
		{
			_filename = filename;
			_regardingObjectTypeCode = regardingObjectTypeCode;
			_regardingObjectId = regardingObjectId;
		}


		public void UploadNewDocument()
		{
			DateTime now = DateTime.Now;
			StringBuilder sbParams = new StringBuilder();

			// Envelope body
			string envelope =
			@"<s:Envelope xmlns:s=""http://schemas.xmlsoap.org/soap/envelope/""><s:Header><SdkClientVersion xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts"">6.0.0.0</SdkClientVersion></s:Header><s:Body><Execute xmlns=""http://schemas.microsoft.com/xrm/2011/Contracts/Services"" xmlns:i=""http://www.w3.org/2001/XMLSchema-instance""><request i:type=""b:NewDocumentRequest"" xmlns:a=""http://schemas.microsoft.com/xrm/2011/Contracts"" xmlns:b=""http://schemas.microsoft.com/crm/2011/Contracts""><a:Parameters xmlns:b=""http://schemas.datacontract.org/2004/07/System.Collections.Generic"">";

			sbParams.Append(envelope);

			// record id and regarding id logical name
			sbParams.Append(@"<a:KeyValuePairOfstringanyType><b:key>FileName</b:key><b:value i:type=""c:string"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">");
			sbParams.Append(_filename);
			sbParams.Append("</b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append(@"<a:KeyValuePairOfstringanyType><b:key>RegardingObjectId</b:key><b:value i:type=""c:string"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">&#123;");
			sbParams.Append(_regardingObjectId);
			sbParams.Append("&#125;</b:value></a:KeyValuePairOfstringanyType>");

			sbParams.Append(@"<a:KeyValuePairOfstringanyType><b:key>RegardingObjectTypeCode</b:key><b:value i:type=""c:string"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">");
			sbParams.Append(_regardingObjectTypeCode);

			sbParams.Append(@"</b:value></a:KeyValuePairOfstringanyType>");
			sbParams.Append(@"<a:KeyValuePairOfstringanyType><b:key>LocationId</b:key><b:value i:type=""c:string"" xmlns:c=""http://www.w3.org/2001/XMLSchema"">00000000-0000-0000-0000-000000000000</b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil=""true"" /><a:RequestName>NewDocument</a:RequestName></request></Execute></s:Body></s:Envelope>");

			StringHttpBody reqBod = new StringHttpBody();

			reqBod.ContentType = "text/xml; charset=utf-8";
			reqBod.BodyString = sbParams.ToString();
			Body = reqBod;

			WebTestRequestHeader addSoapToHeaderForRequest = new WebTestRequestHeader();
			addSoapToHeaderForRequest.Name = "SOAPAction";
			addSoapToHeaderForRequest.Value = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute";
			Headers.Add(addSoapToHeaderForRequest);

		}
	}

	[Serializable]
	public class _grid_cmds_dlg_SP_upload_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_sp_upload.aspx";

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public string locationId
		{
			set
			{
				AddQueryStringParameter("locationId", value.ToString());
			}
		}

		public string pType
		{
			set
			{
				AddQueryStringParameter("pType", value.ToString());
			}
		}

		public Guid pid
		{
			set
			{
				AddQueryStringParameter("pid", value.ToString("B"));
			}
		}

		public _grid_cmds_dlg_SP_upload_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_SP_upload_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _grid_cmds_dlg_routecase_aspx : CrmRequest
	{
		// server URL
		public const string url = "/_grid/cmds/dlg_routecase.aspx";

		public int dType
		{
			set
			{
				AddQueryStringParameter("dType", value.ToString());
			}
		}

		public int iTotal
		{
			set
			{
				AddQueryStringParameter("iTotal", value.ToString());
			}
		}

		public int iIndex
		{
			set
			{
				AddQueryStringParameter("iIndex", value.ToString());
			}
		}

		public Guid iId
		{
			set
			{
				AddQueryStringParameter("iId", value.ToString("B"));
			}
		}
		public int iObjtype
		{
			set
			{
				AddQueryStringParameter("iObjType", value.ToString());
			}
		}

		public _grid_cmds_dlg_routecase_aspx()
			: base(url)
		{
		}
		public _grid_cmds_dlg_routecase_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}


}