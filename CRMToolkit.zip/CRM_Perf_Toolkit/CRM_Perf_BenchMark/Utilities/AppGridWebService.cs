﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CRM_Perf_BenchMark;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace AppGridWebService
{
	/// <summary>
	/// A class to replace the WSDL auto-generated AppGridWebService class
	/// 
	/// </summary>
	class AppGridWebService
	{
		string Url;
		string contentType;

		/// <summary>
		/// class constructor
		/// </summary>
		public AppGridWebService(CRMEntity user)
		{
			this.Url = Utils.UrlPathCombine(user["organizationbaseurl"], "AppWebServices/AppGridWebService.ashx");
			this.contentType = "text/xml; charset=utf-8";
		}

		public WebTestRequest Reset(string gridXml, string id)
		{
			WebTestRequest wtr = new CrmRequest(Url);
			wtr.Method = "Post";
			wtr.Cache = false;

			StringHttpBody body = new StringHttpBody();
			body.BodyString = gridXml;
			body.ContentType = contentType;
			wtr.Body = body;
			wtr.Url += "?operation=Reset&id=" + id;
			return wtr;
		}

		public WebTestRequest Refresh(string gridXml)
		{
			WebTestRequest wtr = new CrmRequest(Url);
			wtr.Method = "Post";
			wtr.Cache = false;
 
			StringHttpBody body = new StringHttpBody();
			body.BodyString = gridXml;
			body.ContentType = contentType;
			wtr.Body = body;
			wtr.Url += "?operation=Refresh";
			return wtr;
		}

		public WebTestRequest RefreshData(string gridXml)
		{
			WebTestRequest wtr = new CrmRequest(Url);
			wtr.Method = "Post";
			wtr.Cache = false;

			StringHttpBody body = new StringHttpBody();
			body.BodyString = gridXml;
			body.ContentType = contentType;
			wtr.Body = body;
			wtr.Url += "?operation=RefreshData";
			return wtr;
		}

		public WebTestRequest GetSearchRequest(string gridXml)
		{
			WebTestRequest wtr = new CrmRequest(Url);
			wtr.Method = "Post";
			wtr.Cache = false;
 
			StringHttpBody body = new StringHttpBody();
			body.BodyString = gridXml;
			body.ContentType = contentType;
			wtr.Body = body;
			wtr.Url += "?id=crmGrid&operation=Reset";
			return wtr;
		}
	}
}
