﻿using System;
using System.Globalization;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace CRM_Perf_BenchMark.Espresso
{
	public static class EspressoTransactionNames
	{
		public const string HomePage = "Espresso_Page_Homepage";
		public const string EntityGrid = "Espresso_Page_EntityGrid";
		public const string EntityReadPage = "Espresso_Page_{0}ReadForm";
		public const string EntityEditPage = "Espresso_Page_{0}EntityEditForm";
		public const string EntityCreatePage = "Espresso_Page_{0}EntityCreateForm";
		public const string EntitySubmit = "Espresso_{0}EntitySubmitForm";
		public const string EntitySearchPage = "Espresso_Page_NonDefaultEntityGrid";
		public const string EntityRelatedGridPage = "Espresso_Page_EntityRelatedGrid";
		public const string WebService_AddAttachment = "Espresso_WebService_AddAttachment";
		public const string WebService_DeleteRecord = "Espresso_{0}DeleteRecord";
		public const string WebService_MarkAsComplete = "Espresso_WebService_MarkAsComplete";
		public const string WebService_SaveNote = "Espresso_WebService_SaveNote";
		public const string WebService_GetRelatedEntities = "Espresso_WebService_GetRelatedEntities";
		public const string WebService_GetRelatedEntityRecords = "Espresso_WebService_GetRelatedEntityRecords";
		public const string WebService_GetDefaultCommandBarDefinitions = "Espresso_WebService_GetDefaultCommandBarDefinitions";
		public const string WebService_GetCommandBarDefinition = "Espresso_WebService_GetCommandBarDefinition";
	}

	[Serializable]
	public abstract class EspressoPage : CrmRequest
	{
		private const string UrlFormatString = "{0}?client_type=MobileClient&user_lcid={1}";

		protected EspressoPage(string url)
			: base(GetShimUrl(url))
		{
		}

		protected EspressoPage(string url, CRMEntity user)
			: base(GetShimUrl(url), user)
		{
		}

		private static string GetShimUrl(string url)
		{
			return String.Format(CultureInfo.InvariantCulture,
						UrlFormatString,
						url,
						GetUserLcid());
		}

		private static string GetUserLcid()
		{
			return "1033";
		}
	}

	[Serializable]
	public class _m_default_aspx : EspressoPage
	{
		private const string url = "/M/default.aspx";
		public _m_default_aspx()
			: base(url)
		{
		}

		public _m_default_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _m_eh_aspx : EspressoPage
	{
		private const string url = "/M/eh.aspx";
		// querystring parameters
		public string etn
		{
			set
			{
				AddQueryStringParameter("etn", value);
			}
		}

		public Guid viewSel
		{
			set
			{
				AddFormParameter("viewSel", value.ToString("B").ToUpper());
			}
		}

		public Guid origViewSel
		{
			set
			{
				AddFormParameter("origViewSel", value.ToString("B").ToUpper());
			}
		}

		public string goBtn
		{
			set
			{
				AddFormParameter("goBtn", value);
			}
		}

		public string txtSearch
		{
			set
			{
				AddFormParameter("txtSearch", value);
			}
		}

		public string origSearch
		{
			set
			{
				AddFormParameter("origSearch", value);
			}
		}

		public _m_eh_aspx()
			: base(url)
		{
		}
		public _m_eh_aspx(CRMEntity user)
			: base(url, user)
		{
		}
	}

	[Serializable]
	public class _m_forms_page_aspx : EspressoPage
	{
		private const string PageUrl = "/_forms/mobilerefresh/page.aspx";

		private string EpochTime
		{
			get
			{
				return
					((DateTime.Now.ToUniversalTime().Ticks - 621355968000000000) / 10000000).ToString(
						CultureInfo.InvariantCulture);
			}
		}

		// querystring parameters
		public int Etc
		{
			set
			{
				AddQueryStringParameter("etc", value.ToString(CultureInfo.InvariantCulture));
			}
		}

		public Guid Id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString());
			}
		}

		public _m_forms_page_aspx()
			: base(PageUrl)
		{
			AddQueryStringParameter("theme", "Outlook15White");
			AddQueryStringParameter("LoadStartTime", EpochTime);
		}

		public _m_forms_page_aspx(CRMEntity user)
			: base(PageUrl, user)
		{
			AddQueryStringParameter("theme", "Outlook15White");
			AddQueryStringParameter("LoadStartTime", EpochTime);
		}

	}
	[Serializable]
	public class _m_ef_aspx : EspressoPage
	{
		private const string PageUrl = "/m/ef.aspx";

		private string EpochTime
		{
			get
			{
				return
					((DateTime.Now.ToUniversalTime().Ticks - 621355968000000000) / 10000000).ToString(
						CultureInfo.InvariantCulture);
			}
		}

		public string Etn
		{
			set
			{
				AddQueryStringParameter("etn", value);
			}
		}

		public Guid Id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public _m_ef_aspx()
			: base(PageUrl)
		{
			AddQueryStringParameter("LoadStartTime", EpochTime);
		}

		public _m_ef_aspx(CRMEntity user)
			: base(PageUrl, user)
		{
			AddQueryStringParameter("LoadStartTime", EpochTime);
		}
	}

	[Serializable]
	public class _m_re_aspx : EspressoPage
	{
		private const string PageUrl = "/m/re.aspx";

		private string EpochTime
		{
			get
			{
				return
					((DateTime.Now.ToUniversalTime().Ticks - 621355968000000000) / 10000000).ToString(
						CultureInfo.InvariantCulture);
			}
		}

		public string Etn
		{
			set
			{
				AddQueryStringParameter("etn", value);
			}
		}

		public Guid Id
		{
			set
			{
				AddQueryStringParameter("id", value.ToString("B"));
			}
		}

		public Guid Rid
		{
			set
			{
				AddQueryStringParameter("rid", value.ToString("D"));
			}
		}

		public _m_re_aspx()
			: base(PageUrl)
		{
			AddQueryStringParameter("LoadStartTime", EpochTime);
		}

		public _m_re_aspx(CRMEntity user)
			: base(PageUrl, user)
		{
			AddQueryStringParameter("LoadStartTime", EpochTime);
		}
	}
}
