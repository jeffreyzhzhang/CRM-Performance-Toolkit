﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Web.Services.Protocols;
using System.Diagnostics;
using System.Globalization;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using ServiceCreator;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System.Collections;
using System.Data.SqlClient;

namespace CRM_Perf_BenchMark.UnitTests
{
	[TestClass]
	public class HierarchicalOperatorsUnitTest : UnitTestBase
	{
		const string HIERARCHICAL_ATTRIBUTE = "new_hierarchynodelevel";
		Dictionary<int, Hierarchy> dictionary = new Dictionary<int, Hierarchy>();

		#region Initialize
		[TestInitialize]
		public override void Initialize()
		{
			base.Initialize();
			InitializeHierarchyNodes();
		}

		#endregion

		#region Test cases
		[TestMethod()]
		public void UnitTest_Hierarchy_RetrieveAccountsUnderRoot()
		{
			//Test case Id : 126872
			int treeId = GetRandomTreeId();
			Hierarchy tree = dictionary[treeId];
			string root = GetAccount(tree.Root);
			string fetch = string.Format(@"
			<fetch mapping='logical'>
				  <entity name='account'>
						<attribute name = 'accountid'/>
						<attribute name = 'name'/>
						<attribute name = 'parentaccountid'/>
						<filter type='and'>
        						<condition attribute = 'accountid' operator='under' value='{0}' />
						</filter>
				  </entity>
			 </fetch>", root);

			TestContext.BeginTimer("RetrieveAccountsUnderRoot Unit Test");
			try
			{
				var results = Proxy.RetrieveMultiple(new FetchExpression(fetch));
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveAccountsUnderRoot Unit Test");
		}

		[TestMethod()]
		public void UnitTest_Hierarchy_RetrieveAccountsUnderRootNotUnderSubtree()
		{
			//Test case Id : 126873
			int treeId = GetRandomTreeId();
			Hierarchy tree = dictionary[treeId];
			string root = GetAccount(tree.Root);
			string subtree = GetAccount(tree.Subtree);

			string fetch = string.Format(@"
			<fetch mapping='logical'>
				  <entity name='account'>
						<attribute name = 'accountid'/>
						<attribute name = 'name'/>
						<attribute name = 'parentaccountid'/>
						<filter type='and'>
        						<condition attribute = 'accountid' operator='under' value='{0}' />
								<condition attribute = 'accountid' operator='not-under' value='{1}' />
						</filter>
				  </entity>
			 </fetch>", root, subtree);

			TestContext.BeginTimer("RetrieveAccountsUnderRootNotUnderSubtree Unit Test");
			try
			{
				var results = Proxy.RetrieveMultiple(new FetchExpression(fetch));
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveAccountsUnderRootNotUnderSubtree Unit Test");
		}

		[TestMethod()]
		public void UnitTest_Hierarchy_RetrieveAccountsAboveLeafNode()
		{
			//Test case Id : 126874
			int treeId = GetRandomTreeId();
			Hierarchy tree = dictionary[treeId];
			string leaf = GetAccount(tree.Leaf);
			string fetch = string.Format(@"
			<fetch mapping='logical'>
				  <entity name='account'>
						<attribute name = 'accountid'/>
						<attribute name = 'name'/>
						<attribute name = 'parentaccountid'/>
						<filter type='and'>
        						<condition attribute = 'accountid' operator='above' value='{0}' />
						</filter>
				  </entity>
			 </fetch>", leaf);

			TestContext.BeginTimer("RetrieveAccountsAboveLeafNode Unit Test");
			try
			{
				var results = Proxy.RetrieveMultiple(new FetchExpression(fetch));
			}
			catch (FaultException fe)
			{
				Trace.WriteLine(fe.Message);
				Trace.WriteLine(fe.StackTrace);
				throw;
			}
			TestContext.EndTimer("RetrieveAccountsAboveLeafNode Unit Test");
		}

		#endregion

		#region helper methods

		private string GetAccount(string nodeId)
		{
			string accountId = string.Empty;
			try
			{
				string query = string.Format("SELECT a.AccountId FROM dbo.Account a WHERE a.new_HierarchyNodeLevel='{0}' ORDER BY NEWID()", nodeId);
				using (SqlConnection sqlconn = new SqlConnection(ConfigSettings.Default.EMSQLCNN))
				{
					sqlconn.Open();
					SqlCommand sqlcmd = new SqlCommand(query, sqlconn);
					Guid accountGuid = (Guid)sqlcmd.ExecuteScalar();
					accountId = accountGuid.ToString();
					sqlconn.Close();
				}
			}
			catch (SqlException sqlEx)
			{
				FileWriter.Instance.WriteToFile(sqlEx.ToString());
			}
			catch (Exception ex)
			{
				FileWriter.Instance.WriteToFile(ex.ToString());
			}
			
			return accountId;
		}

		private void InitializeHierarchyNodes()
		{
			//Initialize hierarchy nodes
			for (int id = 1; id <= 15; id++)
			{
				Hierarchy node = new Hierarchy();
				node.Root = string.Format("HIERARCHY{0} - LEVEL1", id);
				node.Subtree = string.Format("HIERARCHY{0} - LEVEL2", id);
				node.Leaf = string.Format("HIERARCHY{0} - LEVEL7", id);
				dictionary.Add(id, node);
			}
		}

		private int GetRandomTreeId()
		{
			Random r = new Random();
			return r.Next(1, 15);
		}

		private class Hierarchy
		{
			public string Root { get; set; }
			public string Subtree { get; set; }
			public string Leaf { get; set; }
		}

		#endregion
	}
}
