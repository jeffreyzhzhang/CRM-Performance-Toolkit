These Lite version of DBPop xml files have designed to target on Server-Side-Synchronization test purpose.
They are containing only COLAC(Contact, Opportunity, Lead, Account and Case) DBPop by excluding unnecessary dbpop such as annotation,post and so on.


